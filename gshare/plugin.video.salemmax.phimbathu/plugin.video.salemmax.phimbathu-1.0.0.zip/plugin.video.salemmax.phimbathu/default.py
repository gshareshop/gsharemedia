#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.salemmax.phimbathu"
oOOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
O0 = "https://raw.githubusercontent.com/chikhang/chikhang.github.io/master/quancaophim.srt"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
iI11I1II1I1I = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
oooo = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img class="img-film" src="(.+?)"[^>]*/>.+?<div class="name-real"><span>(.*?)</span></div></a></li>'
iIIii1IIi = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img[^>]*data-original="(.+?)"[^>]*/>.*?<div class="name-real"><span>(.*?)</span></div></a></li>'
o0OO00 = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
oo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
i1iII1IiiIiI1 = '&file=/xml.php\?id=(\d+)'
iIiiiI1IiI1I1 = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 87 - 87: OoOoOO00
I11i = 24
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
@ oo000 . route ( '/' )
def I11iIi1I ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
@ oo000 . route ( '/search' )
def O0oOO0o0 ( ) :
 i1ii1iIII = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if i1ii1iIII :
  Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( i1ii1iIII ) + '&p=%s'
  with open ( i111I , "a" ) as II1Ii1iI1i :
   II1Ii1iI1i . write ( i1ii1iIII + "\n" )
  iiI1iIiI = {
 "title" : "Search: %s" % i1ii1iIII ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
  OOo = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  oo000 . redirect ( OOo )
  if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ oo000 . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo (
 '[Search List]' ,
 '/searchlist/'
 )
 oO000OoOoo00o = [ ]
 iiiI11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOooO = [ ]
 if os . path . exists ( i111I ) :
  with open ( i111I , "r" ) as II1Ii1iI1i :
   OOooO = II1Ii1iI1i . read ( ) . strip ( ) . split ( "\n" )
  for OOoO00o in reversed ( OOooO ) :
   Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( OOoO00o ) + '&p=%s'
   iiI1iIiI = {
 "title" : "Search: %s" % OOoO00o ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
   II111iiii = { }
   II111iiii [ "label" ] = OOoO00o
   II111iiii [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oO000OoOoo00o . append ( II111iiii )
 oO000OoOoo00o = iiiI11 + oO000OoOoo00o
 return oo000 . finish ( oO000OoOoo00o )
 if 48 - 48: I1Ii . IiIi1Iii1I1 - O0O0O0O00OooO % Ooooo % i1iIIIiI1I - I11i1i11i1I
@ oo000 . route ( '/list_media/<args_json>' )
def OoO000 ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Media of] %s - Page %s" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1"
 ) ,
 '/list_media/%s/%s' % (
 IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1" ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] )
 if "Search: " in IIiiIiI1 [ "title" ] :
  OooO0 = re . compile ( iIIii1IIi ) . findall ( iiIiIIi )
 else :
  OooO0 = re . compile ( oooo ) . findall ( iiIiIIi )
 for II11iiii1Ii , OO0o , Ooo , O0o0Oo , Oo00OOOOO in OooO0 :
  if "://" not in O0o0Oo :
   O0o0Oo = "http://phimbathu.com/" + O0o0Oo
  Oo0oO0oo0oO00 = "http://phimbathu.com/xem-phim/phim---%s" % Ooo
  O0O = "%s - %s" % ( OO0o , Oo00OOOOO )
  iiI1iIiI = {
 "title" : O0O ,
 "quality_label" : II11iiii1Ii ,
 "url" : Oo0oO0oo0oO00
 }
  II111iiii = { }
  II111iiii [ "label" ] = "%s (%s)" % (
 iiI1iIiI [ "title" ] ,
 iiI1iIiI [ "quality_label" ]
 )
  II111iiii [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  II111iiii [ "thumbnail" ] = O0o0Oo
  if "HD" in II11iiii1Ii :
   II111iiii [ "label" ] = "[COLOR yellow]%s[/COLOR]" % II111iiii [ "label" ]
  oO000OoOoo00o . append ( II111iiii )
 if len ( oO000OoOoo00o ) == I11i :
  O00o0OO = int ( IIiiIiI1 [ "page" ] ) + 1
  IIiiIiI1 [ "page" ] = O00o0OO
  oO000OoOoo00o . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( IIiiIiI1 ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( oO000OoOoo00o )
 if 44 - 44: O0O0O0O00OooO / OOooo000oo0 % IIIiiIIii * i1IIi11111i + I1Ii111
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1I ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Mirrors of] %s (%s)" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIiiIiI1 [ "url" ]
 }
 Oo0o0 = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
 oo000 . redirect ( Oo0o0 )
 return oo000 . finish ( oO000OoOoo00o )
 if 49 - 49: i1IIi11111i % I1Ii + IIIiiIIii . IiII % i1111
@ oo000 . route ( '/list_eps/<args_json>' )
def I1i1iii ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] )
 i1iiI11I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiIiIIi )
 if len ( i1iiI11I ) > 0 :
  for iiii , oO0o0O0OOOoo0 in i1iiI11I :
   if "_HD2" not in iiii :
    iiii = iiii . replace ( ".html" , "_HD2.html" )
   IiIiiI = "http://phimbathu.com/xem-phim/phim---%s" % iiii
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "label" ]
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
 else :
  try :
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IIiiIiI1 [ "url" ] ,
 "eps" : "Full"
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 "Full" ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
  except :
   pass
 return oo000 . finish ( oO000OoOoo00o )
 if 31 - 31: I1Ii . I1Ii - IIii11I1 / ooOoO0o + i1iIIIiI1I * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Play] %s (%s) - Part %s [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "eps" ] if "eps" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/play/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 o00O = xbmcgui . DialogProgress ( )
 o00O . create ( 'PhimBatHu' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( OOO0OOO00oo ( IIiiIiI1 [ "url" ] ) )
 o00O . close ( )
 del o00O
 if 31 - 31: iII111i - I11i1i11i1I . Ooooo % o00O0oo - OOooo000oo0
def Ii ( args_json = { } ) :
 ii11iIi1I = json . loads ( args_json )
 O0Oo (
 "[Play] %s (%s) - Part %s [%s]" % (
 ii11iIi1I [ "title" ] if "title" in ii11iIi1I else "Unknow Title" ,
 ii11iIi1I [ "quality_label" ] if "quality_label" in ii11iIi1I else "" ,
 ii11iIi1I [ "eps" ] if "eps" in ii11iIi1I else "" ,
 ii11iIi1I [ "mirror" ] if "mirror" in ii11iIi1I else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 ii11iIi1I [ "url" ] ,
 json . dumps ( ii11iIi1I [ "payloads" ] ) if "payloads" in ii11iIi1I else "{}"
 )
 )
 oo000 . set_resolved_url ( oo0O0oOOO00oO ( ii11iIi1I [ "url" ] ) , subtitles = "https://docs.google.com/spreadsheets/d/16l-nMNyOvrtu4FKLm-ctGDNClCjI09XKp3lcOKPOXMk/export?format=tsv&gid=0" )
 if 61 - 61: Ooo00oOo00o * i111IiI / IiIIi1I1Iiii . O0O0OO0O0O0 . ii1II11I1ii1I 
def OOO0OOO00oo ( url ) :
 iiIiIIi = ooOoo0O ( url )
 iii11 = None
 OooO0 = re . compile ( 'playerSetting = (\{.+?\})\;' ) . findall ( iiIiIIi )
 try :
  O0oo0OO0oOOOo = json . loads ( OooO0 [ 0 ] )
  i1i1i11IIi = "phimbathu.com4590481877" + O0oo0OO0oOOOo [ "modelId" ]
  II1III = "http://phimbathu.com" + re . search ( 'linkPlay = "(.+?)"' , iiIiIIi ) . group ( 1 )
  O0oo0OO0oOOOo = requests . get ( II1III ) . json ( )
  for iI1iI1I1i1I in O0oo0OO0oOOOo :
   try :
    iI1iI1I1i1I [ 0 ] [ "file" ] = iIi11Ii1 ( iI1iI1I1i1I [ 0 ] [ "file" ] , i1i1i11IIi )
    return Ii11iII1 ( iI1iI1I1i1I [ 0 ] [ "file" ] . replace ( "/preview" , "/view" ) , oo000 . get_setting ( 'HQ' , bool ) )
   except : pass
 except : pass
 return iii11
 if 51 - 51: iII111i * ooOoO0o % IIii11I1 * iII111i % i1111 / i1iIIIiI1I
 if 49 - 49: IIii11I1
def ooOoo0O ( url , data = { } ) :
 IIii1Ii1 = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 'Content-Type' : 'text/html; charset=utf-8' ,
 }
 if data == { } :
  I1II11IiII = requests . get (
 url ,
 headers = IIii1Ii1 )
 else :
  IIii1Ii1 [ "Content-Type" ] = "application/x-www-form-urlencoded"
  I1II11IiII = requests . post (
 url ,
 headers = IIii1Ii1 ,
 data = data )
  return I1II11IiII . json ( )
 I1II11IiII . encoding = "utf-8"
 iiIiIIi = OOO0OOo ( I1II11IiII . text . encode ( "utf8" ) )
 return iiIiIIi
 if 47 - 47: I11i1i11i1I + O0O0O0O00OooO - O0O0O0O00OooO * IiII + I1Ii % O0O0O0O00OooO
def Ii11iII1 ( url , hq ) :
 IIii1Ii1 = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 I1II11IiII = requests . get ( url , headers = IIii1Ii1 )
 i111IiI1I = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( I1II11IiII . text ) [ 0 ]
 O0iII = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : O0iII . reverse ( )
 o0 = json . loads ( i111IiI1I ) [ 1 ] . split ( "," )
 for ooOooo000oOO in O0iII :
  for Oo0oOOo in o0 :
   if Oo0oOOo . startswith ( ooOooo000oOO + "|" ) :
    url = Oo0oOOo . split ( "|" ) [ 1 ]
    Oo0OoO00oOO0o = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( o0O ) , urllib . quote ( I1II11IiII . headers [ 'set-cookie' ] ) )
    return url + Oo0OoO00oOO0o
    if 80 - 80: i1IIi11111i + I11i1i11i1I - I11i1i11i1I % IiIi1Iii1I1
def OoOO0oo0o ( url , data = { } ) :
 IIii1Ii1 = {
 'User-Agent' : iI11I1II1I1I ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  I1II11IiII = requests . get (
 url ,
 headers = IIii1Ii1 )
 else :
  IIii1Ii1 [ "Content-Type" ] = "application/x-www-form-urlencoded"
  I1II11IiII = requests . post (
 url ,
 headers = IIii1Ii1 ,
 data = data )
 I1II11IiII . encoding = "utf-8"
 iiIiIIi = OOO0OOo ( I1II11IiII . text . encode ( "utf8" ) )
 return iiIiIIi
 if 14 - 14: IIii11I1 * IiIi1Iii1I1 * IiIi1Iii1I1 / o00O0oo
def OOO0OOo ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 81 - 81: i1 + i1 * O0O0O0O00OooO * i1iIIIiI1I % i1iIIIiI1I
def ooOO00O00oo ( s ) :
 ooOooo000oOO = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( ooOooo000oOO , '' , s )
 return s . strip ( )
 if 3 - 3: Ooooo - OOooo000oo0 / Ooooo % ooOoO0o / Ooooo . IiII
def oo0ooO0oOOOOo ( title = "Home" , page = "/" ) :
 try :
  iiI111I1iIiI = "http://www.google-analytics.com/collect"
  II = open ( Ii1I1IIii1II ) . read ( )
  O0ii1ii1ii = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : II ,
 't' : 'pageview' ,
 'dp' : "PhimBatHu%s" % page ,
 'dt' : "[PhimBatHu] - %s" % title . encode ( "utf8" )
 }
  requests . post ( iiI111I1iIiI , data = urllib . urlencode ( O0ii1ii1ii ) )
 except :
  pass
  if 91 - 91: O0O0O0O00OooO
def iiIii ( pattern , string , group = 1 , flags = 0 , result = '' ) :
 try : iiIiIIi = re . search ( pattern , string , flags ) . group ( group )
 except : iiIiIIi = result
 return iiIiIIi
 if 79 - 79: ii1IiI1i / OOooo000oo0
def iIi11Ii1 ( string , key = '' ) :
 import ctypes
 def OO0OoO0o00 ( l , s = 4 ) :
  ooOO0O0ooOooO = [ ]
  for oOOOo00O00oOo in range ( 0 , len ( l ) , s ) : ooOO0O0ooOooO . append ( ( l [ oOOOo00O00oOo : oOOOo00O00oOo + s ] ) )
  return ooOO0O0ooOooO
  if 34 - 34: OOooo000oo0 + I11i1i11i1I + I1Ii111
 def I1 ( v ) : return ctypes . c_int ( v ) . value
 def i1IIIiiII1 ( val , n ) : return ( val % 0x100000000 ) >> n
 if 87 - 87: i1IIi11111i * i1111 + I11i1i11i1I / i1 / IiIi1Iii1I1
 I1111IIi = 14
 Oo0oO = 8
 IIiIi1iI = False
 if 35 - 35: I1Ii % OOooo000oo0 - OOooo000oo0
 def II1Ii1iI1i ( e ) :
  if 16 - 16: iII111i % o00O0oo - iII111i + I1Ii
  if 12 - 12: I11i1i11i1I / I11i1i11i1I + OoOoOO00
  return str ( e )
  if 40 - 40: IiII . i1 / IiII / OoOoOO00
 def o0O00o ( e ) :
  if 87 - 87: OoOoOO00
  if 93 - 93: i1111 - ooOoO0o % OoOoOO00 . IiIi1Iii1I1 / IiIi1Iii1I1 - Ooooo
  return str ( e )
  if 9 - 9: i1111 / I1Ii111 - IiII / ii1IiI1i / i1 - IIii11I1
 def o00oooO0Oo ( e ) :
  II1Ii1iI1i = [ 0 ] * len ( e )
  if 16 > len ( e ) :
   Oo0oO = 16 - len ( e )
   II1Ii1iI1i = [ Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO , Oo0oO ]
  for IIiIi1iI in range ( len ( e ) ) : II1Ii1iI1i [ IIiIi1iI ] = e [ IIiIi1iI ]
  return II1Ii1iI1i
  if 78 - 78: I1Ii % Ooooo + i1111
 def OOooOoooOoOo ( e ) :
  IIiIi1iI = ""
  for Oo0oO in len ( e ) : IIiIi1iI += ( "0" if 16 > e [ Oo0oO ] else "" ) + format ( e [ Oo0oO ] , 'x' )
  return IIiIi1iI
  if 84 - 84: O0O0O0O00OooO
 def OOO00O0O ( e , r ) :
  o0O00o = [ ]
  if not r : e = II1Ii1iI1i ( e )
  for IIiIi1iI in range ( len ( e ) ) : o0O00o . append ( ord ( e [ IIiIi1iI ] ) )
  return o0O00o
  if 33 - 33: OOooo000oo0 . O0O0O0O00OooO . IiII
 def oOOOo00O00oOo ( n ) :
  if n == 128 : I1111IIi = 10 ; Oo0oO = 4
  elif n == 192 : I1111IIi = 12 ; Oo0oO = 6
  elif n == 256 : I1111IIi = 14 ; Oo0oO = 8
  if 72 - 72: IIIiiIIii / ooOoO0o + ii1IiI1i - I1Ii111
 def iI1Iii ( e ) :
  IIiIi1iI = [ ]
  for Oo0oO in range ( e ) : IIiIi1iI . append ( 256 )
  return IIiIi1iI
  if 68 - 68: I11i1i11i1I % Ooooo
 def ooO00OO0 ( n , f ) :
  i11111IIIII = [ ] ; o00oooO0Oo = 3 if I1111IIi >= 12 else 2 ; oOOOo00O00oOo = n + f ; i11111IIIII . append ( iIiii1i111iI1 ( oOOOo00O00oOo ) ) ; OOO00O0O = [ o0O00o for o0O00o in i11111IIIII [ 0 ] ]
  for o0O00o in range ( 1 , o00oooO0Oo ) : i11111IIIII . append ( iIiii1i111iI1 ( i11111IIIII [ o0O00o - 1 ] + oOOOo00O00oOo ) ) ; OOO00O0O += i11111IIIII [ o0O00o ]
  return { 'key' : OOO00O0O [ 0 : 4 * Oo0oO ] , 'iv' : OOO00O0O [ 4 * Oo0oO : 4 * Oo0oO + 16 ] }
  if 14 - 14: IiIi1Iii1I1 . IiIi1Iii1I1 % ii1IiI1i
 def iiIi1IIi1I ( e , r = False ) :
  o0O00o = ""
  if ( r ) :
   IIiIi1iI = e [ 15 ]
   if 84 - 84: i1iIIIiI1I * iII111i + I1Ii111
   if 16 != IIiIi1iI :
    for II1Ii1iI1i in range ( 16 - IIiIi1iI ) : o0O00o += chr ( e [ II1Ii1iI1i ] )
  else :
   for II1Ii1iI1i in range ( 16 ) : o0O00o += chr ( e [ II1Ii1iI1i ] )
  return o0O00o
  if 53 - 53: IiIi1Iii1I1 % iII111i . O0O0O0O00OooO - i1 - O0O0O0O00OooO * iII111i
 def ooOO0O0ooOooO ( e , r = False ) :
  if not r : o0O00o = '' . join ( chr ( e [ f ] ) for f in range ( 16 ) )
  elif 16 != e [ 15 ] : o0O00o = '' . join ( chr ( e [ f ] ) for f in range ( 16 - e [ 15 ] ) )
  else : o0O00o = ''
  return o0O00o
  if 77 - 77: i1 * ooOoO0o
 def oOooOo0 ( e , r , n , f = '' ) :
  r = i1I1ii11i1Iii ( r ) ; OOooOoooOoOo = len ( e ) / 16 ; OOO00O0O = [ 0 ] * OOooOoooOoOo
  i11111IIIII = [ e [ 16 * o00oooO0Oo : 16 * ( o00oooO0Oo + 1 ) ] for o00oooO0Oo in range ( OOooOoooOoOo ) ]
  for o00oooO0Oo in range ( len ( i11111IIIII ) - 1 , - 1 , - 1 ) :
   OOO00O0O [ o00oooO0Oo ] = I1IiiiiI ( i11111IIIII [ o00oooO0Oo ] , r )
   OOO00O0O [ o00oooO0Oo ] = o0OIiII ( OOO00O0O [ o00oooO0Oo ] , n ) if 0 == o00oooO0Oo else o0OIiII ( OOO00O0O [ o00oooO0Oo ] , i11111IIIII [ o00oooO0Oo - 1 ] )
   if 25 - 25: OOooo000oo0 - OOooo000oo0 * IIii11I1
  oOOOo00O00oOo = '' . join ( ooOO0O0ooOooO ( OOO00O0O [ o00oooO0Oo ] ) for o00oooO0Oo in range ( OOooOoooOoOo - 1 ) )
  oOOOo00O00oOo += ooOO0O0ooOooO ( OOO00O0O [ OOooOoooOoOo - 1 ] , True )
  return oOOOo00O00oOo if f else o0O00o ( oOOOo00O00oOo )
  if 51 - 51: I1Ii111 - i1IIi11111i + iII111i * I1Ii . Iiii + i1IIi11111i
 def iiIiIIi ( r , f ) :
  IIiIi1iI = False
  o00oooO0Oo = OoO0o ( r , f , 0 )
  for o0O00o in ( 1 , I1111IIi + 1 , 1 ) :
   o00oooO0Oo = oO0o0Ooooo ( o00oooO0Oo )
   o00oooO0Oo = OOo0oO00ooO00 ( o00oooO0Oo )
   if I1111IIi > o0O00o : o00oooO0Oo = oOO0O00oO0Ooo ( o00oooO0Oo )
   o00oooO0Oo = OoO0o ( o00oooO0Oo , f , o0O00o )
  return o00oooO0Oo
  if 67 - 67: ooOoO0o - I11i1i11i1I
 def I1IiiiiI ( r , f ) :
  IIiIi1iI = True
  o00oooO0Oo = OoO0o ( r , f , I1111IIi )
  for o0O00o in range ( I1111IIi - 1 , - 1 , - 1 ) :
   o00oooO0Oo = OOo0oO00ooO00 ( o00oooO0Oo , IIiIi1iI )
   o00oooO0Oo = oO0o0Ooooo ( o00oooO0Oo , IIiIi1iI )
   o00oooO0Oo = OoO0o ( o00oooO0Oo , f , o0O00o )
   if o0O00o > 0 : o00oooO0Oo = oOO0O00oO0Ooo ( o00oooO0Oo , IIiIi1iI )
  return o00oooO0Oo
  if 36 - 36: O0O0O0O00OooO
 def oO0o0Ooooo ( e , n = True ) :
  II1Ii1iI1i = I11iI if n else I1iI1ii1II ; o0O00o = [ 0 ] * 16
  for Oo0oO in range ( 16 ) : o0O00o [ Oo0oO ] = II1Ii1iI1i [ e [ Oo0oO ] ]
  return o0O00o
  if 57 - 57: Ooooo % I1Ii + IIii11I1 - I1Ii111
 def OOo0oO00ooO00 ( e , n = True ) :
  II1Ii1iI1i = [ ]
  if n : o0O00o = [ 0 , 13 , 10 , 7 , 4 , 1 , 14 , 11 , 8 , 5 , 2 , 15 , 12 , 9 , 6 , 3 ]
  else : o0O00o = [ 0 , 5 , 10 , 15 , 4 , 9 , 14 , 3 , 8 , 13 , 2 , 7 , 12 , 1 , 6 , 11 ]
  for Oo0oO in range ( 16 ) : II1Ii1iI1i . append ( e [ o0O00o [ Oo0oO ] ] )
  return II1Ii1iI1i
  if 65 - 65: Iiii . o00O0oo
 def oOO0O00oO0Ooo ( e , n = True ) :
  II1Ii1iI1i = [ 0 ] * 16
  if ( n ) :
   for Oo0oO in range ( 4 ) :
    II1Ii1iI1i [ 4 * Oo0oO ] = IiI1i [ e [ 4 * Oo0oO ] ] ^ o0Oo00 [ e [ 1 + 4 * Oo0oO ] ] ^ iI [ e [ 2 + 4 * Oo0oO ] ] ^ O0O0Oooo0o [ e [ 3 + 4 * Oo0oO ] ]
    II1Ii1iI1i [ 1 + 4 * Oo0oO ] = O0O0Oooo0o [ e [ 4 * Oo0oO ] ] ^ IiI1i [ e [ 1 + 4 * Oo0oO ] ] ^ o0Oo00 [ e [ 2 + 4 * Oo0oO ] ] ^ iI [ e [ 3 + 4 * Oo0oO ] ]
    II1Ii1iI1i [ 2 + 4 * Oo0oO ] = iI [ e [ 4 * Oo0oO ] ] ^ O0O0Oooo0o [ e [ 1 + 4 * Oo0oO ] ] ^ IiI1i [ e [ 2 + 4 * Oo0oO ] ] ^ o0Oo00 [ e [ 3 + 4 * Oo0oO ] ]
    II1Ii1iI1i [ 3 + 4 * Oo0oO ] = o0Oo00 [ e [ 4 * Oo0oO ] ] ^ iI [ e [ 1 + 4 * Oo0oO ] ] ^ O0O0Oooo0o [ e [ 2 + 4 * Oo0oO ] ] ^ IiI1i [ e [ 3 + 4 * Oo0oO ] ]
  else :
   for Oo0oO in range ( 4 ) :
    II1Ii1iI1i [ 4 * Oo0oO ] = oOOoo00O00o [ e [ 4 * Oo0oO ] ] ^ O0O00Oo [ e [ 1 + 4 * Oo0oO ] ] ^ e [ 2 + 4 * Oo0oO ] ^ e [ 3 + 4 * Oo0oO ]
    II1Ii1iI1i [ 1 + 4 * Oo0oO ] = e [ 4 * Oo0oO ] ^ oOOoo00O00o [ e [ 1 + 4 * Oo0oO ] ] ^ O0O00Oo [ e [ 2 + 4 * Oo0oO ] ] ^ e [ 3 + 4 * Oo0oO ]
    II1Ii1iI1i [ 2 + 4 * Oo0oO ] = e [ 4 * Oo0oO ] ^ e [ 1 + 4 * Oo0oO ] ^ oOOoo00O00o [ e [ 2 + 4 * Oo0oO ] ] ^ O0O00Oo [ e [ 3 + 4 * Oo0oO ] ]
    II1Ii1iI1i [ 3 + 4 * Oo0oO ] = O0O00Oo [ e [ 4 * Oo0oO ] ] ^ e [ 1 + 4 * Oo0oO ] ^ e [ 2 + 4 * Oo0oO ] ^ oOOoo00O00o [ e [ 3 + 4 * Oo0oO ] ]
  return II1Ii1iI1i
  if 97 - 97: OOooo000oo0 * ii1IiI1i . ii1IiI1i
 def OoO0o ( e , r , n ) :
  o0O00o = [ 0 ] * 16
  for II1Ii1iI1i in range ( 16 ) : o0O00o [ II1Ii1iI1i ] = e [ II1Ii1iI1i ] ^ r [ n ] [ II1Ii1iI1i ]
  return o0O00o
  if 33 - 33: Ooooo + IiIi1Iii1I1 * i1IIi11111i / i1 - IiII
 def o0OIiII ( e , r ) :
  II1Ii1iI1i = [ 0 ] * 16
  for IIiIi1iI in range ( 16 ) : II1Ii1iI1i [ IIiIi1iI ] = e [ IIiIi1iI ] ^ r [ IIiIi1iI ]
  return II1Ii1iI1i
  if 54 - 54: Ooooo / I11i1i11i1I . i1IIi11111i % IiIi1Iii1I1
 def i1I1ii11i1Iii ( n ) :
  OOooOoooOoOo = [ [ n [ 4 * II1Ii1iI1i + oOOOo00O00oOo ] for oOOOo00O00oOo in range ( 4 ) ] for II1Ii1iI1i in range ( Oo0oO ) ]
  if 57 - 57: OoOoOO00 . i1111 - I1Ii - i1IIi11111i + o00O0oo
  for II1Ii1iI1i in range ( Oo0oO , 4 * ( I1111IIi + 1 ) ) :
   i11111IIIII = [ o00oooO0Oo for o00oooO0Oo in OOooOoooOoOo [ II1Ii1iI1i - 1 ] ]
   if 0 == II1Ii1iI1i % Oo0oO : i11111IIIII = oO00oooOOoOo0 ( OoOOoOooooOOo ( i11111IIIII ) ) ; i11111IIIII [ 0 ] ^= oOo0O [ II1Ii1iI1i / Oo0oO - 1 ]
   elif Oo0oO > 6 and 4 == II1Ii1iI1i % Oo0oO : i11111IIIII = oO00oooOOoOo0 ( i11111IIIII )
   OOooOoooOoOo . append ( [ OOooOoooOoOo [ II1Ii1iI1i - Oo0oO ] [ o00oooO0Oo ] ^ i11111IIIII [ o00oooO0Oo ] for o00oooO0Oo in range ( 4 ) ] )
   if 52 - 52: OoOoOO00 / IIii11I1 * i1iIIIiI1I
  OOO00O0O = [ ]
  for II1Ii1iI1i in range ( I1111IIi + 1 ) :
   OOO00O0O . append ( [ ] )
   for ooOO0O0ooOooO in range ( 4 ) : OOO00O0O [ II1Ii1iI1i ] += OOooOoooOoOo [ 4 * II1Ii1iI1i + ooOO0O0ooOooO ]
  return OOO00O0O
  if 22 - 22: o00O0oo . I11i1i11i1I * o00O0oo
 def oO00oooOOoOo0 ( e ) :
  return [ I1iI1ii1II [ e [ Oo0oO ] ] for Oo0oO in range ( 4 ) ]
  if 54 - 54: O0O0O0O00OooO + I1Ii % ooOoO0o + ii1IiI1i - OOooo000oo0 - IIii11I1
 def OoOOoOooooOOo ( e ) :
  e . insert ( 4 , e [ 0 ] )
  e . remove ( e [ 4 ] )
  return e
  if 77 - 77: I11i1i11i1I * i1
 def oO00oOOoooO ( e , r ) : return [ int ( e [ IIiIi1iI : IIiIi1iI + r ] , 16 ) for IIiIi1iI in range ( 0 , len ( e ) , r ) ]
 if 46 - 46: IiII - ii1IiI1i - Iiii * iII111i
 def I1i1I11I ( e ) :
  IIiIi1iI = [ 0 ] * len ( e )
  for Oo0oO in range ( len ( e ) ) : IIiIi1iI [ e [ Oo0oO ] ] = Oo0oO
  return IIiIi1iI
  if 80 - 80: OoOoOO00 % i1iIIIiI1I + I1Ii % Iiii - i1111
 def I1i1i1iii ( e , r ) :
  II1Ii1iI1i = 0
  for IIiIi1iI in range ( 8 ) :
   II1Ii1iI1i = II1Ii1iI1i ^ e if 1 == ( 1 & r ) else II1Ii1iI1i
   e = I1 ( 283 ^ e << 1 ) if e > 127 else I1 ( e << 1 )
   r >>= 1
  return II1Ii1iI1i
  if 16 - 16: I1Ii + O0O0O0O00OooO * OOooo000oo0 % IIIiiIIii . IiII
 def Oo0OO ( e ) :
  IIiIi1iI = [ 0 ] * 256
  for Oo0oO in range ( 256 ) : IIiIi1iI [ Oo0oO ] = I1i1i1iii ( e , Oo0oO )
  return IIiIi1iI
  if 78 - 78: I11i1i11i1I - ii1IiI1i - i1111 / i1iIIIiI1I / iII111i
 I1iI1ii1II = oO00oOOoooO ( "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16" , 2 )
 I11iI = I1i1I11I ( I1iI1ii1II )
 oOo0O = oO00oOOoooO ( "01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591" , 2 )
 oOOoo00O00o = Oo0OO ( 2 )
 O0O00Oo = Oo0OO ( 3 )
 O0O0Oooo0o = Oo0OO ( 9 )
 o0Oo00 = Oo0OO ( 11 )
 iI = Oo0OO ( 13 )
 IiI1i = Oo0OO ( 14 )
 if 29 - 29: IiII % IiII
 def Oo0O0 ( e , r , n = '' ) :
  II1Ii1iI1i = Ooo0OOoOoO0 ( e )
  o0O00o = II1Ii1iI1i [ 8 : 16 ]
  o00oooO0Oo = ooO00OO0 ( OOO00O0O ( r , n ) , o0O00o )
  ooOO0O0ooOooO = o00oooO0Oo [ 'key' ]
  OOooOoooOoOo = o00oooO0Oo [ 'iv' ]
  II1Ii1iI1i = II1Ii1iI1i [ 16 : len ( II1Ii1iI1i ) ]
  return oOooOo0 ( II1Ii1iI1i , ooOO0O0ooOooO , OOooOoooOoOo , n )
  if 70 - 70: i1IIi11111i
 def Ooo0OOoOoO0 ( r ) :
  def oOOoO0o0oO ( n ) :
   try : ooOO0O0ooOooO = I1111IIi . index ( r [ n ] )
   except : ooOO0O0ooOooO = - 1
   return ooOO0O0ooOooO
   if 93 - 93: O0O0O0O00OooO * ii1IiI1i + i1iIIIiI1I
  I1111IIi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  r = r . replace ( '\n' , '' ) ; II1Ii1iI1i = [ ] ; o0O00o = [ 0 ] * 4
  for IIiIi1iI in range ( 0 , len ( r ) , 4 ) :
   for oOOOo00O00oOo in range ( len ( o0O00o ) ) : o0O00o [ oOOOo00O00oOo ] = oOOoO0o0oO ( IIiIi1iI + oOOOo00O00oOo )
   II1Ii1iI1i . append ( I1 ( o0O00o [ 0 ] << 2 | o0O00o [ 1 ] >> 4 ) )
   II1Ii1iI1i . append ( I1 ( ( 15 & o0O00o [ 1 ] ) << 4 | o0O00o [ 2 ] >> 2 ) )
   II1Ii1iI1i . append ( I1 ( ( 3 & o0O00o [ 2 ] ) << 6 | o0O00o [ 3 ] ) )
  return II1Ii1iI1i [ 0 : len ( II1Ii1iI1i ) - len ( II1Ii1iI1i ) % 16 ]
  if 33 - 33: OOooo000oo0 * IIii11I1 - Ooooo % Ooooo
 def iIiii1i111iI1 ( e ) :
  def Oo0oO ( e , r ) : return I1 ( e << r ) | I1 ( i1IIIiiII1 ( e , 32 - r ) )
  if 18 - 18: Ooooo / I1Ii111 * Ooooo + Ooooo * OoOoOO00 * i1111
  def IIiIi1iI ( e , r ) :
   o0O00o = 2147483648 & e
   o00oooO0Oo = 2147483648 & r
   IIiIi1iI = 1073741824 & e
   II1Ii1iI1i = 1073741824 & r
   ooOO0O0ooOooO = ( 1073741823 & e ) + ( 1073741823 & r )
   oOOOo00O00oOo = 2147483648 ^ ooOO0O0ooOooO ^ o0O00o ^ o00oooO0Oo
   iI = 3221225472 ^ ooOO0O0ooOooO ^ o0O00o ^ o00oooO0Oo
   oOO0O00oO0Ooo = 1073741824 ^ ooOO0O0ooOooO ^ o0O00o ^ o00oooO0Oo
   return I1 ( oOOOo00O00oOo if IIiIi1iI & II1Ii1iI1i else ( ( iI if 1073741824 & ooOO0O0ooOooO else oOO0O00oO0Ooo ) if IIiIi1iI | II1Ii1iI1i else ooOO0O0ooOooO ^ o0O00o ^ o00oooO0Oo ) )
   if 11 - 11: i1iIIIiI1I / o00O0oo - O0O0O0O00OooO * ii1IiI1i + ii1IiI1i . o00O0oo
  def II1Ii1iI1i ( e , r , n ) : return I1 ( e & r ) | I1 ( ~ e & n )
  if 26 - 26: I1Ii % i1111
  def o0O00o ( e , r , n ) : return I1 ( e & n ) | I1 ( r & ~ n )
  if 76 - 76: O0O0O0O00OooO * IiIi1Iii1I1
  def o00oooO0Oo ( e , r , n ) : return e ^ r ^ n
  if 52 - 52: I11i1i11i1I
  def ooOO0O0ooOooO ( e , r , n ) : return r ^ ( e | ~ n )
  if 19 - 19: IiII
  def OOooOoooOoOo ( e , c , t , a , o , d , u ) :
   e = IIiIi1iI ( e , IIiIi1iI ( IIiIi1iI ( II1Ii1iI1i ( c , t , a ) , o ) , u ) )
   return IIiIi1iI ( Oo0oO ( e , d ) , c )
   if 25 - 25: I1Ii / i1iIIIiI1I
  def i11111IIIII ( e , f , t , a , o , d , u ) :
   e = IIiIi1iI ( e , IIiIi1iI ( IIiIi1iI ( o0O00o ( f , t , a ) , o ) , u ) )
   return IIiIi1iI ( Oo0oO ( e , d ) , f )
   if 31 - 31: I11i1i11i1I . OOooo000oo0 % IiII . IIii11I1 + O0O0O0O00OooO
  def OOO00O0O ( e , f , c , a , o , d , u ) :
   e = IIiIi1iI ( e , IIiIi1iI ( IIiIi1iI ( o00oooO0Oo ( f , c , a ) , o ) , u ) )
   return IIiIi1iI ( Oo0oO ( e , d ) , f )
   if 71 - 71: Ooooo . iII111i
  def oOOOo00O00oOo ( e , f , c , t , o , d , u ) :
   e = IIiIi1iI ( e , IIiIi1iI ( IIiIi1iI ( ooOO0O0ooOooO ( f , c , t ) , o ) , u ) )
   return IIiIi1iI ( Oo0oO ( e , d ) , f )
   if 62 - 62: ii1IiI1i . Iiii
  def iI1Iii ( e ) :
   IIiIi1iI = len ( e ) ; II1Ii1iI1i = IIiIi1iI + 8 ; o0O00o = ( II1Ii1iI1i - II1Ii1iI1i % 64 ) / 64 ; o00oooO0Oo = 16 * ( o0O00o + 1 ) ; ooOO0O0ooOooO = [ 0 ] * o00oooO0Oo ; OOooOoooOoOo = 0
   for i11111IIIII in range ( IIiIi1iI ) : Oo0oO = ( i11111IIIII - i11111IIIII % 4 ) / 4 ; OOooOoooOoOo = 8 * ( i11111IIIII % 4 ) ; ooOO0O0ooOooO [ Oo0oO ] = ooOO0O0ooOooO [ Oo0oO ] | I1 ( e [ i11111IIIII ] << OOooOoooOoOo )
   i11111IIIII += 1
   Oo0oO = ( i11111IIIII - i11111IIIII % 4 ) / 4
   OOooOoooOoOo = 8 * ( i11111IIIII % 4 )
   ooOO0O0ooOooO [ Oo0oO ] = ooOO0O0ooOooO [ Oo0oO ] | I1 ( 128 << OOooOoooOoOo )
   ooOO0O0ooOooO [ o00oooO0Oo - 2 ] = I1 ( IIiIi1iI << 3 )
   ooOO0O0ooOooO [ o00oooO0Oo - 1 ] = I1 ( i1IIIiiII1 ( IIiIi1iI , 29 ) )
   return ooOO0O0ooOooO
   if 61 - 61: o00O0oo - I11i1i11i1I - IIIiiIIii
  def ooO00OO0 ( e ) :
   II1Ii1iI1i = [ ]
   for IIiIi1iI in range ( 4 ) :
    Oo0oO = I1 ( 255 & i1IIIiiII1 ( e , 8 * IIiIi1iI ) )
    II1Ii1iI1i . append ( Oo0oO )
   return II1Ii1iI1i
   if 25 - 25: OOooo000oo0 * Iiii + i1111 . IIii11I1 . IIii11I1
  oO00oooOOoOo0 = oO00oOOoooO ( "67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391" , 8 )
  i1I1ii11i1Iii = [ ] ; i1I1ii11i1Iii = iI1Iii ( e ) ; OOo0oO00ooO00 = oO00oooOOoOo0 [ 0 ] ; oOO0O00oO0Ooo = oO00oooOOoOo0 [ 1 ] ; OoO0o = oO00oooOOoOo0 [ 2 ] ; o0OIiII = oO00oooOOoOo0 [ 3 ] ; oOooO = 0
  for oOooO in range ( 0 , len ( i1I1ii11i1Iii ) , 16 ) :
   oOooOo0 = OOo0oO00ooO00
   iiIiIIi = oOO0O00oO0Ooo
   I1IiiiiI = OoO0o
   oO0o0Ooooo = o0OIiII
   OOo0oO00ooO00 = OOooOoooOoOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 0 ] , 7 , oO00oooOOoOo0 [ 4 ] )
   o0OIiII = OOooOoooOoOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 1 ] , 12 , oO00oooOOoOo0 [ 5 ] )
   OoO0o = OOooOoooOoOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 2 ] , 17 , oO00oooOOoOo0 [ 6 ] )
   oOO0O00oO0Ooo = OOooOoooOoOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 3 ] , 22 , oO00oooOOoOo0 [ 7 ] )
   OOo0oO00ooO00 = OOooOoooOoOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 4 ] , 7 , oO00oooOOoOo0 [ 8 ] )
   o0OIiII = OOooOoooOoOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 5 ] , 12 , oO00oooOOoOo0 [ 9 ] )
   OoO0o = OOooOoooOoOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 6 ] , 17 , oO00oooOOoOo0 [ 10 ] )
   oOO0O00oO0Ooo = OOooOoooOoOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 7 ] , 22 , oO00oooOOoOo0 [ 11 ] )
   OOo0oO00ooO00 = OOooOoooOoOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 8 ] , 7 , oO00oooOOoOo0 [ 12 ] )
   o0OIiII = OOooOoooOoOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 9 ] , 12 , oO00oooOOoOo0 [ 13 ] )
   OoO0o = OOooOoooOoOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 10 ] , 17 , oO00oooOOoOo0 [ 14 ] )
   oOO0O00oO0Ooo = OOooOoooOoOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 11 ] , 22 , oO00oooOOoOo0 [ 15 ] )
   OOo0oO00ooO00 = OOooOoooOoOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 12 ] , 7 , oO00oooOOoOo0 [ 16 ] )
   o0OIiII = OOooOoooOoOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 13 ] , 12 , oO00oooOOoOo0 [ 17 ] )
   OoO0o = OOooOoooOoOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 14 ] , 17 , oO00oooOOoOo0 [ 18 ] )
   oOO0O00oO0Ooo = OOooOoooOoOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 15 ] , 22 , oO00oooOOoOo0 [ 19 ] )
   OOo0oO00ooO00 = i11111IIIII ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 1 ] , 5 , oO00oooOOoOo0 [ 20 ] )
   o0OIiII = i11111IIIII ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 6 ] , 9 , oO00oooOOoOo0 [ 21 ] )
   OoO0o = i11111IIIII ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 11 ] , 14 , oO00oooOOoOo0 [ 22 ] )
   oOO0O00oO0Ooo = i11111IIIII ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 0 ] , 20 , oO00oooOOoOo0 [ 23 ] )
   OOo0oO00ooO00 = i11111IIIII ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 5 ] , 5 , oO00oooOOoOo0 [ 24 ] )
   o0OIiII = i11111IIIII ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 10 ] , 9 , oO00oooOOoOo0 [ 25 ] )
   OoO0o = i11111IIIII ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 15 ] , 14 , oO00oooOOoOo0 [ 26 ] )
   oOO0O00oO0Ooo = i11111IIIII ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 4 ] , 20 , oO00oooOOoOo0 [ 27 ] )
   OOo0oO00ooO00 = i11111IIIII ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 9 ] , 5 , oO00oooOOoOo0 [ 28 ] )
   o0OIiII = i11111IIIII ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 14 ] , 9 , oO00oooOOoOo0 [ 29 ] )
   OoO0o = i11111IIIII ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 3 ] , 14 , oO00oooOOoOo0 [ 30 ] )
   oOO0O00oO0Ooo = i11111IIIII ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 8 ] , 20 , oO00oooOOoOo0 [ 31 ] )
   OOo0oO00ooO00 = i11111IIIII ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 13 ] , 5 , oO00oooOOoOo0 [ 32 ] )
   o0OIiII = i11111IIIII ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 2 ] , 9 , oO00oooOOoOo0 [ 33 ] )
   OoO0o = i11111IIIII ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 7 ] , 14 , oO00oooOOoOo0 [ 34 ] )
   oOO0O00oO0Ooo = i11111IIIII ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 12 ] , 20 , oO00oooOOoOo0 [ 35 ] )
   OOo0oO00ooO00 = OOO00O0O ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 5 ] , 4 , oO00oooOOoOo0 [ 36 ] )
   o0OIiII = OOO00O0O ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 8 ] , 11 , oO00oooOOoOo0 [ 37 ] )
   OoO0o = OOO00O0O ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 11 ] , 16 , oO00oooOOoOo0 [ 38 ] )
   oOO0O00oO0Ooo = OOO00O0O ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 14 ] , 23 , oO00oooOOoOo0 [ 39 ] )
   OOo0oO00ooO00 = OOO00O0O ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 1 ] , 4 , oO00oooOOoOo0 [ 40 ] )
   o0OIiII = OOO00O0O ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 4 ] , 11 , oO00oooOOoOo0 [ 41 ] )
   OoO0o = OOO00O0O ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 7 ] , 16 , oO00oooOOoOo0 [ 42 ] )
   oOO0O00oO0Ooo = OOO00O0O ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 10 ] , 23 , oO00oooOOoOo0 [ 43 ] )
   OOo0oO00ooO00 = OOO00O0O ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 13 ] , 4 , oO00oooOOoOo0 [ 44 ] )
   o0OIiII = OOO00O0O ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 0 ] , 11 , oO00oooOOoOo0 [ 45 ] )
   OoO0o = OOO00O0O ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 3 ] , 16 , oO00oooOOoOo0 [ 46 ] )
   oOO0O00oO0Ooo = OOO00O0O ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 6 ] , 23 , oO00oooOOoOo0 [ 47 ] )
   OOo0oO00ooO00 = OOO00O0O ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 9 ] , 4 , oO00oooOOoOo0 [ 48 ] )
   o0OIiII = OOO00O0O ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 12 ] , 11 , oO00oooOOoOo0 [ 49 ] )
   OoO0o = OOO00O0O ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 15 ] , 16 , oO00oooOOoOo0 [ 50 ] )
   oOO0O00oO0Ooo = OOO00O0O ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 2 ] , 23 , oO00oooOOoOo0 [ 51 ] )
   OOo0oO00ooO00 = oOOOo00O00oOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 0 ] , 6 , oO00oooOOoOo0 [ 52 ] )
   o0OIiII = oOOOo00O00oOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 7 ] , 10 , oO00oooOOoOo0 [ 53 ] )
   OoO0o = oOOOo00O00oOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 14 ] , 15 , oO00oooOOoOo0 [ 54 ] )
   oOO0O00oO0Ooo = oOOOo00O00oOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 5 ] , 21 , oO00oooOOoOo0 [ 55 ] )
   OOo0oO00ooO00 = oOOOo00O00oOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 12 ] , 6 , oO00oooOOoOo0 [ 56 ] )
   o0OIiII = oOOOo00O00oOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 3 ] , 10 , oO00oooOOoOo0 [ 57 ] )
   OoO0o = oOOOo00O00oOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 10 ] , 15 , oO00oooOOoOo0 [ 58 ] )
   oOO0O00oO0Ooo = oOOOo00O00oOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 1 ] , 21 , oO00oooOOoOo0 [ 59 ] )
   OOo0oO00ooO00 = oOOOo00O00oOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 8 ] , 6 , oO00oooOOoOo0 [ 60 ] )
   o0OIiII = oOOOo00O00oOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 15 ] , 10 , oO00oooOOoOo0 [ 61 ] )
   OoO0o = oOOOo00O00oOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 6 ] , 15 , oO00oooOOoOo0 [ 62 ] )
   oOO0O00oO0Ooo = oOOOo00O00oOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 13 ] , 21 , oO00oooOOoOo0 [ 63 ] )
   OOo0oO00ooO00 = oOOOo00O00oOo ( OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , o0OIiII , i1I1ii11i1Iii [ oOooO + 4 ] , 6 , oO00oooOOoOo0 [ 64 ] )
   o0OIiII = oOOOo00O00oOo ( o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , OoO0o , i1I1ii11i1Iii [ oOooO + 11 ] , 10 , oO00oooOOoOo0 [ 65 ] )
   OoO0o = oOOOo00O00oOo ( OoO0o , o0OIiII , OOo0oO00ooO00 , oOO0O00oO0Ooo , i1I1ii11i1Iii [ oOooO + 2 ] , 15 , oO00oooOOoOo0 [ 66 ] )
   oOO0O00oO0Ooo = oOOOo00O00oOo ( oOO0O00oO0Ooo , OoO0o , o0OIiII , OOo0oO00ooO00 , i1I1ii11i1Iii [ oOooO + 9 ] , 21 , oO00oooOOoOo0 [ 67 ] )
   OOo0oO00ooO00 = IIiIi1iI ( OOo0oO00ooO00 , oOooOo0 )
   oOO0O00oO0Ooo = IIiIi1iI ( oOO0O00oO0Ooo , iiIiIIi )
   OoO0o = IIiIi1iI ( OoO0o , I1IiiiiI )
   o0OIiII = IIiIi1iI ( o0OIiII , oO0o0Ooooo )
  return ooO00OO0 ( OOo0oO00ooO00 ) + ooO00OO0 ( oOO0O00oO0Ooo ) + ooO00OO0 ( OoO0o ) + ooO00OO0 ( o0OIiII )
  if 10 - 10: o00O0oo % o00O0oo - o00O0oo . IiIi1Iii1I1
  if 73 - 73: Iiii % OoOoOO00 - IiII
 def Ii1iI111II1I1 ( b ) :
  def oOOOOoOO0o ( s ) :
   OoOOoOooooOOo , oOOOo00O00oOo , s , I1111IIi = s . split ( ',' )
   ooOO0O0ooOooO = iI1Iii = o0O00o = 0 ; i11111IIIII = [ ] ; II1Ii1iI1i = [ ]
   while True :
    if ooOO0O0ooOooO < 5 : II1Ii1iI1i . append ( OoOOoOooooOOo [ ooOO0O0ooOooO ] )
    elif ooOO0O0ooOooO < len ( OoOOoOooooOOo ) : i11111IIIII . append ( OoOOoOooooOOo [ ooOO0O0ooOooO ] )
    ooOO0O0ooOooO += 1
    if 1 - 1: iII111i
    if iI1Iii < 5 : II1Ii1iI1i . append ( oOOOo00O00oOo [ iI1Iii ] )
    elif iI1Iii < len ( oOOOo00O00oOo ) : i11111IIIII . append ( oOOOo00O00oOo [ iI1Iii ] )
    iI1Iii += 1
    if 68 - 68: IiIi1Iii1I1 - IiII / Ooooo / Iiii
    if o0O00o < 5 : II1Ii1iI1i . append ( s [ o0O00o ] )
    elif o0O00o < len ( s ) : i11111IIIII . append ( s [ o0O00o ] )
    o0O00o += 1
    if 12 - 12: I1Ii + OoOoOO00 * i1 / i1111 . Iiii
    if len ( OoOOoOooooOOo ) + len ( oOOOo00O00oOo ) + len ( s ) + len ( I1111IIi ) == len ( i11111IIIII ) + len ( II1Ii1iI1i ) + len ( I1111IIi ) : break
    if 5 - 5: IIIiiIIii + O0O0O0O00OooO / IIii11I1 . IiIi1Iii1I1 / Iiii
   oOO0O00oO0Ooo = '' . join ( s for s in i11111IIIII ) ; oO00oooOOoOo0 = '' . join ( s for s in II1Ii1iI1i ) ; iI1Iii = 0 ; OOooOoooOoOo = [ ]
   for ooOO0O0ooOooO in range ( 0 , len ( i11111IIIII ) , 2 ) :
    IIiIi1iI = - 1
    if ord ( oO00oooOOoOo0 [ iI1Iii ] ) % 2 : IIiIi1iI = 1
    OOooOoooOoOo . append ( chr ( int ( oOO0O00oO0Ooo [ ooOO0O0ooOooO : ooOO0O0ooOooO + 2 ] , 36 ) - IIiIi1iI ) )
    iI1Iii += 1
    if iI1Iii >= len ( II1Ii1iI1i ) : iI1Iii = 0
   return '' . join ( s for s in OOooOoooOoOo )
  oOooO = 0
  while oOooO < 5 or 'decodeLink' not in b :
   try : b = oOOOOoOO0o ( iiIii ( "(\w{100,},\w+,\w+,\w+)" , b . replace ( "'" , '' ) ) ) ; oOooO += 1
   except : break
  return b
  if 32 - 32: IiII % i1 / IIIiiIIii - IiII
 return Oo0O0 ( string , key ) if key else Ii1iI111II1I1 ( string )
 if 7 - 7: Ooooo * ooOoO0o - i1iIIIiI1I + I11i1i11i1I * IiII % ooOoO0o
iI1i111I1Ii = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( iI1i111I1Ii ) == False :
 os . mkdir ( iI1i111I1Ii )
Ii1I1IIii1II = os . path . join ( iI1i111I1Ii , 'cid' )
i111I = os . path . join ( iI1i111I1Ii , 'search.p' )
if 25 - 25: Ooooo - IiIi1Iii1I1
if os . path . exists ( Ii1I1IIii1II ) == False :
 with open ( Ii1I1IIii1II , "w" ) as II1Ii1iI1i :
  II1Ii1iI1i . write ( str ( uuid . uuid1 ( ) ) )
  if 10 - 10: iII111i / i1IIi11111i % ii1IiI1i * Iiii % i1111
if __name__ == '__main__' :
 oo000 . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
