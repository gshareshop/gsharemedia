#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.salemmax.phimbathu"
oOOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
O0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
iI11I1II1I1I = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
oooo = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img class="img-film" src="(.+?)"[^>]*/>.+?<div class="name-real"><span>(.*?)</span></div></a></li>'
iIIii1IIi = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img[^>]*data-original="(.+?)"[^>]*/>.*?<div class="name-real"><span>(.*?)</span></div></a></li>'
o0OO00 = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
oo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
i1iII1IiiIiI1 = '&file=/xml.php\?id=(\d+)'
iIiiiI1IiI1I1 = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 87 - 87: OoOoOO00
I11i = 24
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
@ oo000 . route ( '/' )
def I11iIi1I ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
@ oo000 . route ( '/search' )
def O0oOO0o0 ( ) :
 i1ii1iIII = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if i1ii1iIII :
  Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( i1ii1iIII ) + '&p=%s'
  with open ( i111I , "a" ) as II1Ii1iI1i :
   II1Ii1iI1i . write ( i1ii1iIII + "\n" )
  iiI1iIiI = {
 "title" : "Search: %s" % i1ii1iIII ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
  OOo = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  oo000 . redirect ( OOo )
  if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ oo000 . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo (
 '[Search List]' ,
 '/searchlist/'
 )
 oO000OoOoo00o = [ ]
 iiiI11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 OOooO = [ ]
 if os . path . exists ( i111I ) :
  with open ( i111I , "r" ) as II1Ii1iI1i :
   OOooO = II1Ii1iI1i . read ( ) . strip ( ) . split ( "\n" )
  for OOoO00o in reversed ( OOooO ) :
   Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( OOoO00o ) + '&p=%s'
   iiI1iIiI = {
 "title" : "Search: %s" % OOoO00o ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
   II111iiii = { }
   II111iiii [ "label" ] = OOoO00o
   II111iiii [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oO000OoOoo00o . append ( II111iiii )
 oO000OoOoo00o = iiiI11 + oO000OoOoo00o
 return oo000 . finish ( oO000OoOoo00o )
 if 48 - 48: I1Ii . IiIi1Iii1I1 - O0O0O0O00OooO % Ooooo % i1iIIIiI1I - I11i1i11i1I
@ oo000 . route ( '/list_media/<args_json>' )
def OoO000 ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Media of] %s - Page %s" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1"
 ) ,
 '/list_media/%s/%s' % (
 IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1" ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] )
 if "Search: " in IIiiIiI1 [ "title" ] :
  OooO0 = re . compile ( iIIii1IIi ) . findall ( iiIiIIi )
 else :
  OooO0 = re . compile ( oooo ) . findall ( iiIiIIi )
 for II11iiii1Ii , OO0o , Ooo , O0o0Oo , Oo00OOOOO in OooO0 :
  if "://" not in O0o0Oo :
   O0o0Oo = "http://phimbathu.com/" + O0o0Oo
  Oo0oO0oo0oO00 = "http://phimbathu.com/xem-phim/phim---%s" % Ooo
  O0O = "%s - %s" % ( OO0o , Oo00OOOOO )
  iiI1iIiI = {
 "title" : O0O ,
 "quality_label" : II11iiii1Ii ,
 "url" : Oo0oO0oo0oO00
 }
  II111iiii = { }
  II111iiii [ "label" ] = "%s (%s)" % (
 iiI1iIiI [ "title" ] ,
 iiI1iIiI [ "quality_label" ]
 )
  II111iiii [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  II111iiii [ "thumbnail" ] = O0o0Oo
  if "HD" in II11iiii1Ii :
   II111iiii [ "label" ] = "[COLOR yellow]%s[/COLOR]" % II111iiii [ "label" ]
  oO000OoOoo00o . append ( II111iiii )
 if len ( oO000OoOoo00o ) == I11i :
  O00o0OO = int ( IIiiIiI1 [ "page" ] ) + 1
  IIiiIiI1 [ "page" ] = O00o0OO
  oO000OoOoo00o . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( IIiiIiI1 ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( oO000OoOoo00o )
 if 44 - 44: O0O0O0O00OooO / OOooo000oo0 % IIIiiIIii * i1IIi11111i + I1Ii111
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1I ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Mirrors of] %s (%s)" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIiiIiI1 [ "url" ]
 }
 Oo0o0 = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
 oo000 . redirect ( Oo0o0 )
 return oo000 . finish ( oO000OoOoo00o )
 if 49 - 49: i1IIi11111i % I1Ii + IIIiiIIii . IiII % i1111
@ oo000 . route ( '/list_eps/<args_json>' )
def I1i1iii ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] )
 i1iiI11I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiIiIIi )
 if len ( i1iiI11I ) > 0 :
  for iiii , oO0o0O0OOOoo0 in i1iiI11I :
   if "_HD2" not in iiii :
    iiii = iiii . replace ( ".html" , "_HD2.html" )
   IiIiiI = "http://phimbathu.com/xem-phim/phim---%s" % iiii
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "label" ]
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
 else :
  try :
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IIiiIiI1 [ "url" ] ,
 "eps" : "Full"
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 "Full" ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
  except :
   pass
 return oo000 . finish ( oO000OoOoo00o )
 if 31 - 31: I1Ii . I1Ii - IIii11I1 / ooOoO0o + i1iIIIiI1I * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Play] %s (%s) - Part %s [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "eps" ] if "eps" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/play/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 o00O = xbmcgui . DialogProgress ( )
 o00O . create ( 'PhimBatHu' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( OOO0OOO00oo ( IIiiIiI1 [ "url" ] ) )
 o00O . close ( )
 del o00O
 if 31 - 31: iII111i - I11i1i11i1I . Ooooo % o00O0oo - OOooo000oo0
def OOO0OOO00oo ( url ) :
 iiIiIIi = ooOoo0O ( url )
 iii11 = None
 OooO0 = re . search ( 'playerSetting = (\{.+?\})\;' , iiIiIIi ) . group ( 1 )
 O0oo0OO0oOOOo = json . loads ( OooO0 )
 i1i1i11IIi = "phimbathu.com4590481877" + O0oo0OO0oOOOo [ "modelId" ]
 II1III = [ "sourcesVs" , "sourcesTm" ]
 for iI1iI1I1i1I in II1III :
  if iI1iI1I1i1I in O0oo0OO0oOOOo :
   for iIi11Ii1 in O0oo0OO0oOOOo [ iI1iI1I1i1I ] :
    for Ii11iII1 in iIi11Ii1 [ "links" ] :
     try :
      II1Ii1iI1i = Oo0O0O0ooO0O ( Ii11iII1 [ "file" ] , i1i1i11IIi )
      if Ii11iII1 [ "type" ] != "mp4" and iIi11Ii1 [ "server" ] == "gd" :
       return IIIIii ( II1Ii1iI1i . replace ( "/preview" , "/view" ) , oo000 . get_setting ( 'HQ' , bool ) )
     except : pass
   for iIi11Ii1 in O0oo0OO0oOOOo [ iI1iI1I1i1I ] :
    for Ii11iII1 in iIi11Ii1 [ "links" ] :
     II1Ii1iI1i = Oo0O0O0ooO0O ( Ii11iII1 [ "file" ] , i1i1i11IIi )
     if Ii11iII1 [ "type" ] == "mp4" :
      return II1Ii1iI1i
 return iii11
 if 70 - 70: I1Ii / Iiii . IiIi1Iii1I1 % I1Ii111
 if 67 - 67: o00O0oo * IIii11I1 . O0O0O0O00OooO - ooOoO0o * IIii11I1
def ooOoo0O ( url , data = { } ) :
 IIiI1I = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 'Content-Type' : 'text/html; charset=utf-8' ,
 }
 if data == { } :
  O00Oo000ooO0 = requests . get (
 url ,
 headers = IIiI1I )
 else :
  IIiI1I [ "Content-Type" ] = "application/x-www-form-urlencoded"
  O00Oo000ooO0 = requests . post (
 url ,
 headers = IIiI1I ,
 data = data )
  return O00Oo000ooO0 . json ( )
 O00Oo000ooO0 . encoding = "utf-8"
 iiIiIIi = OoO0O00 ( O00Oo000ooO0 . text . encode ( "utf8" ) )
 return iiIiIIi
 if 5 - 5: I1Ii111 / IIii11I1 . I1Ii - OOooo000oo0 / O0O0O0O00OooO
def IIIIii ( url , hq ) :
 IIiI1I = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 O00Oo000ooO0 = requests . get ( url , headers = IIiI1I )
 ooOooo000oOO = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( O00Oo000ooO0 . text ) [ 0 ]
 Oo0oOOo = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : Oo0oOOo . reverse ( )
 Oo0OoO00oOO0o = json . loads ( ooOooo000oOO ) [ 1 ] . split ( "," )
 for OOO00O in Oo0oOOo :
  for OOoOO0oo0ooO in Oo0OoO00oOO0o :
   if OOoOO0oo0ooO . startswith ( OOO00O + "|" ) :
    url = OOoOO0oo0ooO . split ( "|" ) [ 1 ]
    O0o0O00Oo0o0 = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( o0O ) , urllib . quote ( O00Oo000ooO0 . headers [ 'set-cookie' ] ) )
    return url + O0o0O00Oo0o0
    if 87 - 87: i1iIIIiI1I * I1Ii111 % OoOoOO00 % o00O0oo - I11i1i11i1I
def O0ooo0O0oo0 ( url , data = { } ) :
 IIiI1I = {
 'User-Agent' : iI11I1II1I1I ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  O00Oo000ooO0 = requests . get (
 url ,
 headers = IIiI1I )
 else :
  IIiI1I [ "Content-Type" ] = "application/x-www-form-urlencoded"
  O00Oo000ooO0 = requests . post (
 url ,
 headers = IIiI1I ,
 data = data )
 O00Oo000ooO0 . encoding = "utf-8"
 iiIiIIi = OoO0O00 ( O00Oo000ooO0 . text . encode ( "utf8" ) )
 return iiIiIIi
 if 91 - 91: i1 + Ooooo
def OoO0O00 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 31 - 31: O0O0O0O00OooO . o00O0oo . I11i1i11i1I
def O0oOoOO ( s ) :
 OOO00O = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( OOO00O , '' , s )
 return s . strip ( )
 if 96 - 96: I1Ii111
def oo0ooO0oOOOOo ( title = "Home" , page = "/" ) :
 try :
  Ii1I1IIii1II = "http://www.google-analytics.com/collect"
  O0ii1ii1ii = open ( oooooOoo0ooo ) . read ( )
  I1I1IiI1 = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : O0ii1ii1ii ,
 't' : 'pageview' ,
 'dp' : "PhimBatHu%s" % page ,
 'dt' : "[PhimBatHu] - %s" % title . encode ( "utf8" )
 }
  requests . post ( Ii1I1IIii1II , data = urllib . urlencode ( I1I1IiI1 ) )
 except :
  pass
  if 5 - 5: IIii11I1 * i1iIIIiI1I + o00O0oo . I11i1i11i1I + o00O0oo
def oO ( pattern , string , group = 1 , flags = 0 , result = '' ) :
 try : iiIiIIi = re . search ( pattern , string , flags ) . group ( group )
 except : iiIiIIi = result
 return iiIiIIi
 if 7 - 7: IIii11I1 - IiII
def Oo0O0O0ooO0O ( string , key = '' ) :
 import ctypes
 def OOo00O0 ( l , s = 4 ) :
  ooOOOoO = [ ]
  for o0o in range ( 0 , len ( l ) , s ) : ooOOOoO . append ( ( l [ o0o : o0o + s ] ) )
  return ooOOOoO
  if 84 - 84: OOooo000oo0
 def OOOooOO0 ( v ) : return ctypes . c_int ( v ) . value
 def OOOOoOoo0O0O0 ( val , n ) : return ( val % 0x100000000 ) >> n
 if 85 - 85: i1IIi11111i % OoOoOO00 - IiIi1Iii1I1 * ii1IiI1i / IiII % IiII
 IIiIi1iI = 14
 i1IiiiI1iI = 8
 i1iIi = False
 if 68 - 68: OoOoOO00 % i1111 + OoOoOO00
 def II1Ii1iI1i ( e ) :
  if 31 - 31: iII111i . IiII
  if 1 - 1: I1Ii111 / IIii11I1 % IiIi1Iii1I1 * O0O0O0O00OooO . OoOoOO00
  return str ( e )
  if 2 - 2: i1111 * Iiii - i1 + IiII . i1IIi11111i % IiIi1Iii1I1
 def ooOOOoOooOoO ( e ) :
  if 91 - 91: IiIi1Iii1I1 % IIIiiIIii % i1
  if 20 - 20: I11i1i11i1I % I1Ii / I1Ii + I1Ii
  return str ( e )
  if 45 - 45: i1IIi11111i - O0O0O0O00OooO - ii1IiI1i - ooOoO0o . iII111i / OOooo000oo0
 def oo0o00O ( e ) :
  II1Ii1iI1i = [ 0 ] * len ( e )
  if 16 > len ( e ) :
   i1IiiiI1iI = 16 - len ( e )
   II1Ii1iI1i = [ i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI , i1IiiiI1iI ]
  for i1iIi in range ( len ( e ) ) : II1Ii1iI1i [ i1iIi ] = e [ i1iIi ]
  return II1Ii1iI1i
  if 51 - 51: I1Ii - ooOoO0o * IiIi1Iii1I1
 def oooo0O0 ( e ) :
  i1iIi = ""
  for i1IiiiI1iI in len ( e ) : i1iIi += ( "0" if 16 > e [ i1IiiiI1iI ] else "" ) + format ( e [ i1IiiiI1iI ] , 'x' )
  return i1iIi
  if 51 - 51: ooOoO0o / ooOoO0o
 def ooOOO0 ( e , r ) :
  ooOOOoOooOoO = [ ]
  if not r : e = II1Ii1iI1i ( e )
  for i1iIi in range ( len ( e ) ) : ooOOOoOooOoO . append ( ord ( e [ i1iIi ] ) )
  return ooOOOoOooOoO
  if 65 - 65: OOooo000oo0
 def o0o ( n ) :
  if n == 128 : IIiIi1iI = 10 ; i1IiiiI1iI = 4
  elif n == 192 : IIiIi1iI = 12 ; i1IiiiI1iI = 6
  elif n == 256 : IIiIi1iI = 14 ; i1IiiiI1iI = 8
  if 68 - 68: I11i1i11i1I % Ooooo
 def ooO00OO0 ( e ) :
  i1iIi = [ ]
  for i1IiiiI1iI in range ( e ) : i1iIi . append ( 256 )
  return i1iIi
  if 31 - 31: IiIi1Iii1I1 % IiIi1Iii1I1 % Iiii
 def OOOOoo0Oo ( n , f ) :
  ii111iI1iIi1 = [ ] ; oo0o00O = 3 if IIiIi1iI >= 12 else 2 ; o0o = n + f ; ii111iI1iIi1 . append ( OOO ( o0o ) ) ; ooOOO0 = [ ooOOOoOooOoO for ooOOOoOooOoO in ii111iI1iIi1 [ 0 ] ]
  for ooOOOoOooOoO in range ( 1 , oo0o00O ) : ii111iI1iIi1 . append ( OOO ( ii111iI1iIi1 [ ooOOOoOooOoO - 1 ] + o0o ) ) ; ooOOO0 += ii111iI1iIi1 [ ooOOOoOooOoO ]
  return { 'key' : ooOOO0 [ 0 : 4 * i1IiiiI1iI ] , 'iv' : ooOOO0 [ 4 * i1IiiiI1iI : 4 * i1IiiiI1iI + 16 ] }
  if 68 - 68: iII111i + Iiii
 def I1I1I ( e , r = False ) :
  ooOOOoOooOoO = ""
  if ( r ) :
   i1iIi = e [ 15 ]
   if 95 - 95: iII111i + IIii11I1 + IiIi1Iii1I1 * i1 % i1IIi11111i / O0O0O0O00OooO
   if 16 != i1iIi :
    for II1Ii1iI1i in range ( 16 - i1iIi ) : ooOOOoOooOoO += chr ( e [ II1Ii1iI1i ] )
  else :
   for II1Ii1iI1i in range ( 16 ) : ooOOOoOooOoO += chr ( e [ II1Ii1iI1i ] )
  return ooOOOoOooOoO
  if 56 - 56: IiIi1Iii1I1
 def ooOOOoO ( e , r = False ) :
  if not r : ooOOOoOooOoO = '' . join ( chr ( e [ f ] ) for f in range ( 16 ) )
  elif 16 != e [ 15 ] : ooOOOoOooOoO = '' . join ( chr ( e [ f ] ) for f in range ( 16 - e [ 15 ] ) )
  else : ooOOOoOooOoO = ''
  return ooOOOoOooOoO
  if 86 - 86: iII111i % Ooooo
 def iiIIiiIi1Ii11 ( e , r , n , f = '' ) :
  r = Oo0 ( r ) ; oooo0O0 = len ( e ) / 16 ; ooOOO0 = [ 0 ] * oooo0O0
  ii111iI1iIi1 = [ e [ 16 * oo0o00O : 16 * ( oo0o00O + 1 ) ] for oo0o00O in range ( oooo0O0 ) ]
  for oo0o00O in range ( len ( ii111iI1iIi1 ) - 1 , - 1 , - 1 ) :
   ooOOO0 [ oo0o00O ] = oOooo0O0Oo ( ii111iI1iIi1 [ oo0o00O ] , r )
   ooOOO0 [ oo0o00O ] = iI ( ooOOO0 [ oo0o00O ] , n ) if 0 == oo0o00O else iI ( ooOOO0 [ oo0o00O ] , ii111iI1iIi1 [ oo0o00O - 1 ] )
   if 80 - 80: Ooooo . OoOoOO00 - IIii11I1
  o0o = '' . join ( ooOOOoO ( ooOOO0 [ oo0o00O ] ) for oo0o00O in range ( oooo0O0 - 1 ) )
  o0o += ooOOOoO ( ooOOO0 [ oooo0O0 - 1 ] , True )
  return o0o if f else ooOOOoOooOoO ( o0o )
  if 25 - 25: ooOoO0o
 def iiIiIIi ( r , f ) :
  i1iIi = False
  oo0o00O = oOo0oO ( r , f , 0 )
  for ooOOOoOooOoO in ( 1 , IIiIi1iI + 1 , 1 ) :
   oo0o00O = OOOO0oo0 ( oo0o00O )
   oo0o00O = I11iiI1i1 ( oo0o00O )
   if IIiIi1iI > ooOOOoOooOoO : oo0o00O = I1i1Iiiii ( oo0o00O )
   oo0o00O = oOo0oO ( oo0o00O , f , ooOOOoOooOoO )
  return oo0o00O
  if 94 - 94: IIii11I1 * I1Ii / I1Ii111 / I1Ii
 def oOooo0O0Oo ( r , f ) :
  i1iIi = True
  oo0o00O = oOo0oO ( r , f , IIiIi1iI )
  for ooOOOoOooOoO in range ( IIiIi1iI - 1 , - 1 , - 1 ) :
   oo0o00O = I11iiI1i1 ( oo0o00O , i1iIi )
   oo0o00O = OOOO0oo0 ( oo0o00O , i1iIi )
   oo0o00O = oOo0oO ( oo0o00O , f , ooOOOoOooOoO )
   if ooOOOoOooOoO > 0 : oo0o00O = I1i1Iiiii ( oo0o00O , i1iIi )
  return oo0o00O
  if 87 - 87: I1Ii111 . O0O0O0O00OooO
 def OOOO0oo0 ( e , n = True ) :
  II1Ii1iI1i = O0OO0O if n else OO ; ooOOOoOooOoO = [ 0 ] * 16
  for i1IiiiI1iI in range ( 16 ) : ooOOOoOooOoO [ i1IiiiI1iI ] = II1Ii1iI1i [ e [ i1IiiiI1iI ] ]
  return ooOOOoOooOoO
  if 83 - 83: OOooo000oo0 / IiII - ooOoO0o - I11i1i11i1I
 def I11iiI1i1 ( e , n = True ) :
  II1Ii1iI1i = [ ]
  if n : ooOOOoOooOoO = [ 0 , 13 , 10 , 7 , 4 , 1 , 14 , 11 , 8 , 5 , 2 , 15 , 12 , 9 , 6 , 3 ]
  else : ooOOOoOooOoO = [ 0 , 5 , 10 , 15 , 4 , 9 , 14 , 3 , 8 , 13 , 2 , 7 , 12 , 1 , 6 , 11 ]
  for i1IiiiI1iI in range ( 16 ) : II1Ii1iI1i . append ( e [ ooOOOoOooOoO [ i1IiiiI1iI ] ] )
  return II1Ii1iI1i
  if 36 - 36: O0O0O0O00OooO
 def I1i1Iiiii ( e , n = True ) :
  II1Ii1iI1i = [ 0 ] * 16
  if ( n ) :
   for i1IiiiI1iI in range ( 4 ) :
    II1Ii1iI1i [ 4 * i1IiiiI1iI ] = I11iI [ e [ 4 * i1IiiiI1iI ] ] ^ I1iI1ii1II [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ O0O0OOOOoo [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ oOooO0 [ e [ 3 + 4 * i1IiiiI1iI ] ]
    II1Ii1iI1i [ 1 + 4 * i1IiiiI1iI ] = oOooO0 [ e [ 4 * i1IiiiI1iI ] ] ^ I11iI [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ I1iI1ii1II [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ O0O0OOOOoo [ e [ 3 + 4 * i1IiiiI1iI ] ]
    II1Ii1iI1i [ 2 + 4 * i1IiiiI1iI ] = O0O0OOOOoo [ e [ 4 * i1IiiiI1iI ] ] ^ oOooO0 [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ I11iI [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ I1iI1ii1II [ e [ 3 + 4 * i1IiiiI1iI ] ]
    II1Ii1iI1i [ 3 + 4 * i1IiiiI1iI ] = I1iI1ii1II [ e [ 4 * i1IiiiI1iI ] ] ^ O0O0OOOOoo [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ oOooO0 [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ I11iI [ e [ 3 + 4 * i1IiiiI1iI ] ]
  else :
   for i1IiiiI1iI in range ( 4 ) :
    II1Ii1iI1i [ 4 * i1IiiiI1iI ] = Ii1I1Ii [ e [ 4 * i1IiiiI1iI ] ] ^ OOoO0 [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ e [ 2 + 4 * i1IiiiI1iI ] ^ e [ 3 + 4 * i1IiiiI1iI ]
    II1Ii1iI1i [ 1 + 4 * i1IiiiI1iI ] = e [ 4 * i1IiiiI1iI ] ^ Ii1I1Ii [ e [ 1 + 4 * i1IiiiI1iI ] ] ^ OOoO0 [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ e [ 3 + 4 * i1IiiiI1iI ]
    II1Ii1iI1i [ 2 + 4 * i1IiiiI1iI ] = e [ 4 * i1IiiiI1iI ] ^ e [ 1 + 4 * i1IiiiI1iI ] ^ Ii1I1Ii [ e [ 2 + 4 * i1IiiiI1iI ] ] ^ OOoO0 [ e [ 3 + 4 * i1IiiiI1iI ] ]
    II1Ii1iI1i [ 3 + 4 * i1IiiiI1iI ] = OOoO0 [ e [ 4 * i1IiiiI1iI ] ] ^ e [ 1 + 4 * i1IiiiI1iI ] ^ e [ 2 + 4 * i1IiiiI1iI ] ^ Ii1I1Ii [ e [ 3 + 4 * i1IiiiI1iI ] ]
  return II1Ii1iI1i
  if 86 - 86: i1IIi11111i * IIii11I1 % IIIiiIIii . I1Ii . OoOoOO00
 def oOo0oO ( e , r , n ) :
  ooOOOoOooOoO = [ 0 ] * 16
  for II1Ii1iI1i in range ( 16 ) : ooOOOoOooOoO [ II1Ii1iI1i ] = e [ II1Ii1iI1i ] ^ r [ n ] [ II1Ii1iI1i ]
  return ooOOOoOooOoO
  if 56 - 56: i1111 % OOooo000oo0 - IiII
 def iI ( e , r ) :
  II1Ii1iI1i = [ 0 ] * 16
  for i1iIi in range ( 16 ) : II1Ii1iI1i [ i1iIi ] = e [ i1iIi ] ^ r [ i1iIi ]
  return II1Ii1iI1i
  if 100 - 100: I1Ii - OOooo000oo0 % i1IIi11111i * I11i1i11i1I + IiII
 def Oo0 ( n ) :
  oooo0O0 = [ [ n [ 4 * II1Ii1iI1i + o0o ] for o0o in range ( 4 ) ] for II1Ii1iI1i in range ( i1IiiiI1iI ) ]
  if 88 - 88: ii1IiI1i - ooOoO0o * OOooo000oo0 * ii1IiI1i . ii1IiI1i
  for II1Ii1iI1i in range ( i1IiiiI1iI , 4 * ( IIiIi1iI + 1 ) ) :
   ii111iI1iIi1 = [ oo0o00O for oo0o00O in oooo0O0 [ II1Ii1iI1i - 1 ] ]
   if 0 == II1Ii1iI1i % i1IiiiI1iI : ii111iI1iIi1 = I111iI ( oOOo0 ( ii111iI1iIi1 ) ) ; ii111iI1iIi1 [ 0 ] ^= II1I1iiIII [ II1Ii1iI1i / i1IiiiI1iI - 1 ]
   elif i1IiiiI1iI > 6 and 4 == II1Ii1iI1i % i1IiiiI1iI : ii111iI1iIi1 = I111iI ( ii111iI1iIi1 )
   oooo0O0 . append ( [ oooo0O0 [ II1Ii1iI1i - i1IiiiI1iI ] [ oo0o00O ] ^ ii111iI1iIi1 [ oo0o00O ] for oo0o00O in range ( 4 ) ] )
   if 77 - 77: o00O0oo - iII111i - i1iIIIiI1I
  ooOOO0 = [ ]
  for II1Ii1iI1i in range ( IIiIi1iI + 1 ) :
   ooOOO0 . append ( [ ] )
   for ooOOOoO in range ( 4 ) : ooOOO0 [ II1Ii1iI1i ] += oooo0O0 [ 4 * II1Ii1iI1i + ooOOOoO ]
  return ooOOO0
  if 49 - 49: iII111i % OOooo000oo0 . o00O0oo + i1IIi11111i / IiII
 def I111iI ( e ) :
  return [ OO [ e [ i1IiiiI1iI ] ] for i1IiiiI1iI in range ( 4 ) ]
  if 72 - 72: i1iIIIiI1I * I1Ii111 . IiII - iII111i + IIIiiIIii
 def oOOo0 ( e ) :
  e . insert ( 4 , e [ 0 ] )
  e . remove ( e [ 4 ] )
  return e
  if 10 - 10: i1IIi11111i + IIIiiIIii
 def oOo0O ( e , r ) : return [ int ( e [ i1iIi : i1iIi + r ] , 16 ) for i1iIi in range ( 0 , len ( e ) , r ) ]
 if 52 - 52: OoOoOO00 / IIii11I1 * i1iIIIiI1I
 def iIOO0O000 ( e ) :
  i1iIi = [ 0 ] * len ( e )
  for i1IiiiI1iI in range ( len ( e ) ) : i1iIi [ e [ i1IiiiI1iI ] ] = i1IiiiI1iI
  return i1iIi
  if 37 - 37: ii1IiI1i - OOooo000oo0 - IIii11I1
 def o0o0O0O00oOOo ( e , r ) :
  II1Ii1iI1i = 0
  for i1iIi in range ( 8 ) :
   II1Ii1iI1i = II1Ii1iI1i ^ e if 1 == ( 1 & r ) else II1Ii1iI1i
   e = OOOooOO0 ( 283 ^ e << 1 ) if e > 127 else OOOooOO0 ( e << 1 )
   r >>= 1
  return II1Ii1iI1i
  if 14 - 14: o00O0oo + i1IIi11111i
 def oo00oO0O0 ( e ) :
  i1iIi = [ 0 ] * 256
  for i1IiiiI1iI in range ( 256 ) : i1iIi [ i1IiiiI1iI ] = o0o0O0O00oOOo ( e , i1IiiiI1iI )
  return i1iIi
  if 30 - 30: I11i1i11i1I + i1111 * Iiii % OoOoOO00 % o00O0oo
 OO = oOo0O ( "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16" , 2 )
 O0OO0O = iIOO0O000 ( OO )
 II1I1iiIII = oOo0O ( "01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591" , 2 )
 Ii1I1Ii = oo00oO0O0 ( 2 )
 OOoO0 = oo00oO0O0 ( 3 )
 oOooO0 = oo00oO0O0 ( 9 )
 I1iI1ii1II = oo00oO0O0 ( 11 )
 O0O0OOOOoo = oo00oO0O0 ( 13 )
 I11iI = oo00oO0O0 ( 14 )
 if 97 - 97: i1111 % i1111 % i1IIi11111i / IiIi1Iii1I1 - i1
 def ooooo0O0000oo ( e , r , n = '' ) :
  II1Ii1iI1i = iIii1II11 ( e )
  ooOOOoOooOoO = II1Ii1iI1i [ 8 : 16 ]
  oo0o00O = OOOOoo0Oo ( ooOOO0 ( r , n ) , ooOOOoOooOoO )
  ooOOOoO = oo0o00O [ 'key' ]
  oooo0O0 = oo0o00O [ 'iv' ]
  II1Ii1iI1i = II1Ii1iI1i [ 16 : len ( II1Ii1iI1i ) ]
  return iiIIiiIi1Ii11 ( II1Ii1iI1i , ooOOOoO , oooo0O0 , n )
  if 65 - 65: ii1IiI1i - i1111 / i1iIIIiI1I / iII111i / IIIiiIIii
 def iIii1II11 ( r ) :
  def o00oo0 ( n ) :
   try : ooOOOoO = IIiIi1iI . index ( r [ n ] )
   except : ooOOOoO = - 1
   return ooOOOoO
   if 38 - 38: i1iIIIiI1I % iII111i % Iiii / ooOoO0o + o00O0oo / IIIiiIIii
  IIiIi1iI = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  r = r . replace ( '\n' , '' ) ; II1Ii1iI1i = [ ] ; ooOOOoOooOoO = [ 0 ] * 4
  for i1iIi in range ( 0 , len ( r ) , 4 ) :
   for o0o in range ( len ( ooOOOoOooOoO ) ) : ooOOOoOooOoO [ o0o ] = o00oo0 ( i1iIi + o0o )
   II1Ii1iI1i . append ( OOOooOO0 ( ooOOOoOooOoO [ 0 ] << 2 | ooOOOoOooOoO [ 1 ] >> 4 ) )
   II1Ii1iI1i . append ( OOOooOO0 ( ( 15 & ooOOOoOooOoO [ 1 ] ) << 4 | ooOOOoOooOoO [ 2 ] >> 2 ) )
   II1Ii1iI1i . append ( OOOooOO0 ( ( 3 & ooOOOoOooOoO [ 2 ] ) << 6 | ooOOOoOooOoO [ 3 ] ) )
  return II1Ii1iI1i [ 0 : len ( II1Ii1iI1i ) - len ( II1Ii1iI1i ) % 16 ]
  if 54 - 54: i1 % i1111 - I11i1i11i1I / i1IIi11111i - ooOoO0o . Iiii
 def OOO ( e ) :
  def i1IiiiI1iI ( e , r ) : return OOOooOO0 ( e << r ) | OOOooOO0 ( OOOOoOoo0O0O0 ( e , 32 - r ) )
  if 11 - 11: i1111 . ooOoO0o * O0O0O0O00OooO * ii1IiI1i + i1iIIIiI1I
  def i1iIi ( e , r ) :
   ooOOOoOooOoO = 2147483648 & e
   oo0o00O = 2147483648 & r
   i1iIi = 1073741824 & e
   II1Ii1iI1i = 1073741824 & r
   ooOOOoO = ( 1073741823 & e ) + ( 1073741823 & r )
   o0o = 2147483648 ^ ooOOOoO ^ ooOOOoOooOoO ^ oo0o00O
   O0O0OOOOoo = 3221225472 ^ ooOOOoO ^ ooOOOoOooOoO ^ oo0o00O
   I1i1Iiiii = 1073741824 ^ ooOOOoO ^ ooOOOoOooOoO ^ oo0o00O
   return OOOooOO0 ( o0o if i1iIi & II1Ii1iI1i else ( ( O0O0OOOOoo if 1073741824 & ooOOOoO else I1i1Iiiii ) if i1iIi | II1Ii1iI1i else ooOOOoO ^ ooOOOoOooOoO ^ oo0o00O ) )
   if 33 - 33: OOooo000oo0 * IIii11I1 - Ooooo % Ooooo
  def II1Ii1iI1i ( e , r , n ) : return OOOooOO0 ( e & r ) | OOOooOO0 ( ~ e & n )
  if 18 - 18: Ooooo / I1Ii111 * Ooooo + Ooooo * OoOoOO00 * i1111
  def ooOOOoOooOoO ( e , r , n ) : return OOOooOO0 ( e & n ) | OOOooOO0 ( r & ~ n )
  if 11 - 11: i1iIIIiI1I / o00O0oo - O0O0O0O00OooO * ii1IiI1i + ii1IiI1i . o00O0oo
  def oo0o00O ( e , r , n ) : return e ^ r ^ n
  if 26 - 26: I1Ii % i1111
  def ooOOOoO ( e , r , n ) : return r ^ ( e | ~ n )
  if 76 - 76: O0O0O0O00OooO * IiIi1Iii1I1
  def oooo0O0 ( e , c , t , a , o , d , u ) :
   e = i1iIi ( e , i1iIi ( i1iIi ( II1Ii1iI1i ( c , t , a ) , o ) , u ) )
   return i1iIi ( i1IiiiI1iI ( e , d ) , c )
   if 52 - 52: I11i1i11i1I
  def ii111iI1iIi1 ( e , f , t , a , o , d , u ) :
   e = i1iIi ( e , i1iIi ( i1iIi ( ooOOOoOooOoO ( f , t , a ) , o ) , u ) )
   return i1iIi ( i1IiiiI1iI ( e , d ) , f )
   if 19 - 19: IiII
  def ooOOO0 ( e , f , c , a , o , d , u ) :
   e = i1iIi ( e , i1iIi ( i1iIi ( oo0o00O ( f , c , a ) , o ) , u ) )
   return i1iIi ( i1IiiiI1iI ( e , d ) , f )
   if 25 - 25: I1Ii / i1iIIIiI1I
  def o0o ( e , f , c , t , o , d , u ) :
   e = i1iIi ( e , i1iIi ( i1iIi ( ooOOOoO ( f , c , t ) , o ) , u ) )
   return i1iIi ( i1IiiiI1iI ( e , d ) , f )
   if 31 - 31: I11i1i11i1I . OOooo000oo0 % IiII . IIii11I1 + O0O0O0O00OooO
  def ooO00OO0 ( e ) :
   i1iIi = len ( e ) ; II1Ii1iI1i = i1iIi + 8 ; ooOOOoOooOoO = ( II1Ii1iI1i - II1Ii1iI1i % 64 ) / 64 ; oo0o00O = 16 * ( ooOOOoOooOoO + 1 ) ; ooOOOoO = [ 0 ] * oo0o00O ; oooo0O0 = 0
   for ii111iI1iIi1 in range ( i1iIi ) : i1IiiiI1iI = ( ii111iI1iIi1 - ii111iI1iIi1 % 4 ) / 4 ; oooo0O0 = 8 * ( ii111iI1iIi1 % 4 ) ; ooOOOoO [ i1IiiiI1iI ] = ooOOOoO [ i1IiiiI1iI ] | OOOooOO0 ( e [ ii111iI1iIi1 ] << oooo0O0 )
   ii111iI1iIi1 += 1
   i1IiiiI1iI = ( ii111iI1iIi1 - ii111iI1iIi1 % 4 ) / 4
   oooo0O0 = 8 * ( ii111iI1iIi1 % 4 )
   ooOOOoO [ i1IiiiI1iI ] = ooOOOoO [ i1IiiiI1iI ] | OOOooOO0 ( 128 << oooo0O0 )
   ooOOOoO [ oo0o00O - 2 ] = OOOooOO0 ( i1iIi << 3 )
   ooOOOoO [ oo0o00O - 1 ] = OOOooOO0 ( OOOOoOoo0O0O0 ( i1iIi , 29 ) )
   return ooOOOoO
   if 71 - 71: Ooooo . iII111i
  def OOOOoo0Oo ( e ) :
   II1Ii1iI1i = [ ]
   for i1iIi in range ( 4 ) :
    i1IiiiI1iI = OOOooOO0 ( 255 & OOOOoOoo0O0O0 ( e , 8 * i1iIi ) )
    II1Ii1iI1i . append ( i1IiiiI1iI )
   return II1Ii1iI1i
   if 62 - 62: ii1IiI1i . Iiii
  I111iI = oOo0O ( "67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391" , 8 )
  Oo0 = [ ] ; Oo0 = ooO00OO0 ( e ) ; I11iiI1i1 = I111iI [ 0 ] ; I1i1Iiiii = I111iI [ 1 ] ; oOo0oO = I111iI [ 2 ] ; iI = I111iI [ 3 ] ; oOOOoo00 = 0
  for oOOOoo00 in range ( 0 , len ( Oo0 ) , 16 ) :
   iiIIiiIi1Ii11 = I11iiI1i1
   iiIiIIi = I1i1Iiiii
   oOooo0O0Oo = oOo0oO
   OOOO0oo0 = iI
   I11iiI1i1 = oooo0O0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 0 ] , 7 , I111iI [ 4 ] )
   iI = oooo0O0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 1 ] , 12 , I111iI [ 5 ] )
   oOo0oO = oooo0O0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 2 ] , 17 , I111iI [ 6 ] )
   I1i1Iiiii = oooo0O0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 3 ] , 22 , I111iI [ 7 ] )
   I11iiI1i1 = oooo0O0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 4 ] , 7 , I111iI [ 8 ] )
   iI = oooo0O0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 5 ] , 12 , I111iI [ 9 ] )
   oOo0oO = oooo0O0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 6 ] , 17 , I111iI [ 10 ] )
   I1i1Iiiii = oooo0O0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 7 ] , 22 , I111iI [ 11 ] )
   I11iiI1i1 = oooo0O0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 8 ] , 7 , I111iI [ 12 ] )
   iI = oooo0O0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 9 ] , 12 , I111iI [ 13 ] )
   oOo0oO = oooo0O0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 10 ] , 17 , I111iI [ 14 ] )
   I1i1Iiiii = oooo0O0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 11 ] , 22 , I111iI [ 15 ] )
   I11iiI1i1 = oooo0O0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 12 ] , 7 , I111iI [ 16 ] )
   iI = oooo0O0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 13 ] , 12 , I111iI [ 17 ] )
   oOo0oO = oooo0O0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 14 ] , 17 , I111iI [ 18 ] )
   I1i1Iiiii = oooo0O0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 15 ] , 22 , I111iI [ 19 ] )
   I11iiI1i1 = ii111iI1iIi1 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 1 ] , 5 , I111iI [ 20 ] )
   iI = ii111iI1iIi1 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 6 ] , 9 , I111iI [ 21 ] )
   oOo0oO = ii111iI1iIi1 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 11 ] , 14 , I111iI [ 22 ] )
   I1i1Iiiii = ii111iI1iIi1 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 0 ] , 20 , I111iI [ 23 ] )
   I11iiI1i1 = ii111iI1iIi1 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 5 ] , 5 , I111iI [ 24 ] )
   iI = ii111iI1iIi1 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 10 ] , 9 , I111iI [ 25 ] )
   oOo0oO = ii111iI1iIi1 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 15 ] , 14 , I111iI [ 26 ] )
   I1i1Iiiii = ii111iI1iIi1 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 4 ] , 20 , I111iI [ 27 ] )
   I11iiI1i1 = ii111iI1iIi1 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 9 ] , 5 , I111iI [ 28 ] )
   iI = ii111iI1iIi1 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 14 ] , 9 , I111iI [ 29 ] )
   oOo0oO = ii111iI1iIi1 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 3 ] , 14 , I111iI [ 30 ] )
   I1i1Iiiii = ii111iI1iIi1 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 8 ] , 20 , I111iI [ 31 ] )
   I11iiI1i1 = ii111iI1iIi1 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 13 ] , 5 , I111iI [ 32 ] )
   iI = ii111iI1iIi1 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 2 ] , 9 , I111iI [ 33 ] )
   oOo0oO = ii111iI1iIi1 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 7 ] , 14 , I111iI [ 34 ] )
   I1i1Iiiii = ii111iI1iIi1 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 12 ] , 20 , I111iI [ 35 ] )
   I11iiI1i1 = ooOOO0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 5 ] , 4 , I111iI [ 36 ] )
   iI = ooOOO0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 8 ] , 11 , I111iI [ 37 ] )
   oOo0oO = ooOOO0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 11 ] , 16 , I111iI [ 38 ] )
   I1i1Iiiii = ooOOO0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 14 ] , 23 , I111iI [ 39 ] )
   I11iiI1i1 = ooOOO0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 1 ] , 4 , I111iI [ 40 ] )
   iI = ooOOO0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 4 ] , 11 , I111iI [ 41 ] )
   oOo0oO = ooOOO0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 7 ] , 16 , I111iI [ 42 ] )
   I1i1Iiiii = ooOOO0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 10 ] , 23 , I111iI [ 43 ] )
   I11iiI1i1 = ooOOO0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 13 ] , 4 , I111iI [ 44 ] )
   iI = ooOOO0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 0 ] , 11 , I111iI [ 45 ] )
   oOo0oO = ooOOO0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 3 ] , 16 , I111iI [ 46 ] )
   I1i1Iiiii = ooOOO0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 6 ] , 23 , I111iI [ 47 ] )
   I11iiI1i1 = ooOOO0 ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 9 ] , 4 , I111iI [ 48 ] )
   iI = ooOOO0 ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 12 ] , 11 , I111iI [ 49 ] )
   oOo0oO = ooOOO0 ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 15 ] , 16 , I111iI [ 50 ] )
   I1i1Iiiii = ooOOO0 ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 2 ] , 23 , I111iI [ 51 ] )
   I11iiI1i1 = o0o ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 0 ] , 6 , I111iI [ 52 ] )
   iI = o0o ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 7 ] , 10 , I111iI [ 53 ] )
   oOo0oO = o0o ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 14 ] , 15 , I111iI [ 54 ] )
   I1i1Iiiii = o0o ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 5 ] , 21 , I111iI [ 55 ] )
   I11iiI1i1 = o0o ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 12 ] , 6 , I111iI [ 56 ] )
   iI = o0o ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 3 ] , 10 , I111iI [ 57 ] )
   oOo0oO = o0o ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 10 ] , 15 , I111iI [ 58 ] )
   I1i1Iiiii = o0o ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 1 ] , 21 , I111iI [ 59 ] )
   I11iiI1i1 = o0o ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 8 ] , 6 , I111iI [ 60 ] )
   iI = o0o ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 15 ] , 10 , I111iI [ 61 ] )
   oOo0oO = o0o ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 6 ] , 15 , I111iI [ 62 ] )
   I1i1Iiiii = o0o ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 13 ] , 21 , I111iI [ 63 ] )
   I11iiI1i1 = o0o ( I11iiI1i1 , I1i1Iiiii , oOo0oO , iI , Oo0 [ oOOOoo00 + 4 ] , 6 , I111iI [ 64 ] )
   iI = o0o ( iI , I11iiI1i1 , I1i1Iiiii , oOo0oO , Oo0 [ oOOOoo00 + 11 ] , 10 , I111iI [ 65 ] )
   oOo0oO = o0o ( oOo0oO , iI , I11iiI1i1 , I1i1Iiiii , Oo0 [ oOOOoo00 + 2 ] , 15 , I111iI [ 66 ] )
   I1i1Iiiii = o0o ( I1i1Iiiii , oOo0oO , iI , I11iiI1i1 , Oo0 [ oOOOoo00 + 9 ] , 21 , I111iI [ 67 ] )
   I11iiI1i1 = i1iIi ( I11iiI1i1 , iiIIiiIi1Ii11 )
   I1i1Iiiii = i1iIi ( I1i1Iiiii , iiIiIIi )
   oOo0oO = i1iIi ( oOo0oO , oOooo0O0Oo )
   iI = i1iIi ( iI , OOOO0oo0 )
  return OOOOoo0Oo ( I11iiI1i1 ) + OOOOoo0Oo ( I1i1Iiiii ) + OOOOoo0Oo ( oOo0oO ) + OOOOoo0Oo ( iI )
  if 9 - 9: OOooo000oo0 % OOooo000oo0 - IIii11I1
  if 51 - 51: IiII . i1 - i1111 / OOooo000oo0
 def OOOoO00 ( b ) :
  def IIiIi11i1i ( s ) :
   oOOo0 , o0o , s , IIiIi1iI = s . split ( ',' )
   ooOOOoO = ooO00OO0 = ooOOOoOooOoO = 0 ; ii111iI1iIi1 = [ ] ; II1Ii1iI1i = [ ]
   while True :
    if ooOOOoO < 5 : II1Ii1iI1i . append ( oOOo0 [ ooOOOoO ] )
    elif ooOOOoO < len ( oOOo0 ) : ii111iI1iIi1 . append ( oOOo0 [ ooOOOoO ] )
    ooOOOoO += 1
    if 41 - 41: i1iIIIiI1I % ooOoO0o - I1Ii111 * Ooooo * I1Ii111
    if ooO00OO0 < 5 : II1Ii1iI1i . append ( o0o [ ooO00OO0 ] )
    elif ooO00OO0 < len ( o0o ) : ii111iI1iIi1 . append ( o0o [ ooO00OO0 ] )
    ooO00OO0 += 1
    if 69 - 69: I11i1i11i1I - ii1IiI1i + IIii11I1 - Iiii
    if ooOOOoOooOoO < 5 : II1Ii1iI1i . append ( s [ ooOOOoOooOoO ] )
    elif ooOOOoOooOoO < len ( s ) : ii111iI1iIi1 . append ( s [ ooOOOoOooOoO ] )
    ooOOOoOooOoO += 1
    if 23 - 23: OoOoOO00
    if len ( oOOo0 ) + len ( o0o ) + len ( s ) + len ( IIiIi1iI ) == len ( ii111iI1iIi1 ) + len ( II1Ii1iI1i ) + len ( IIiIi1iI ) : break
    if 30 - 30: IIii11I1 - IIIiiIIii % iII111i + Iiii * i1
   I1i1Iiiii = '' . join ( s for s in ii111iI1iIi1 ) ; I111iI = '' . join ( s for s in II1Ii1iI1i ) ; ooO00OO0 = 0 ; oooo0O0 = [ ]
   for ooOOOoO in range ( 0 , len ( ii111iI1iIi1 ) , 2 ) :
    i1iIi = - 1
    if ord ( I111iI [ ooO00OO0 ] ) % 2 : i1iIi = 1
    oooo0O0 . append ( chr ( int ( I1i1Iiiii [ ooOOOoO : ooOOOoO + 2 ] , 36 ) - i1iIi ) )
    ooO00OO0 += 1
    if ooO00OO0 >= len ( II1Ii1iI1i ) : ooO00OO0 = 0
   return '' . join ( s for s in oooo0O0 )
  oOOOoo00 = 0
  while oOOOoo00 < 5 or 'decodeLink' not in b :
   try : b = IIiIi11i1i ( oO ( "(\w{100,},\w+,\w+,\w+)" , b . replace ( "'" , '' ) ) ) ; oOOOoo00 += 1
   except : break
  return b
  if 81 - 81: O0O0O0O00OooO % IIIiiIIii . i1
 return ooooo0O0000oo ( string , key ) if key else OOOoO00 ( string )
 if 4 - 4: OoOoOO00 % ooOoO0o % IIIiiIIii / O0O0O0O00OooO
I11iIooOoo = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( I11iIooOoo ) == False :
 os . mkdir ( I11iIooOoo )
oooooOoo0ooo = os . path . join ( I11iIooOoo , 'cid' )
i111I = os . path . join ( I11iIooOoo , 'search.p' )
if 7 - 7: Ooooo * ooOoO0o - i1iIIIiI1I + I11i1i11i1I * IiII % ooOoO0o
if os . path . exists ( oooooOoo0ooo ) == False :
 with open ( oooooOoo0ooo , "w" ) as II1Ii1iI1i :
  II1Ii1iI1i . write ( str ( uuid . uuid1 ( ) ) )
  if 15 - 15: o00O0oo % IiII * Iiii
if __name__ == '__main__' :
 oo000 . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
