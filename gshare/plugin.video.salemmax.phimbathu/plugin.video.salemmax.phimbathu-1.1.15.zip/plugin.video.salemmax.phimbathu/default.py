#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64 , urlresolver
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
oo000 = Plugin ( )
ii = "plugin://plugin.video.salemmax.phimbathu"
oOOo = "https://uphinhnhanh.com/images/2018/01/08/fanart.jpg"
O0 = "https://uphinhnhanh.com/images/2018/01/08/fanart.jpg"
o0O = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
iI11I1II1I1I = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
oooo = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img class="img-film" src="(.+?)"[^>]*/>.+?<div class="name-real"><span>(.*?)</span></div></a></li>'
iIIii1IIi = '<li class="item.*?"><span class="label">(.*?)</span>.*?<a title="(.+?)" href=".+?-(\d+).html"><img[^>]*data-original="(.+?)"[^>]*/>.*?<div class="name-real"><span>(.*?)</span></div></a></li>'
o0OO00 = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
oo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
i1iII1IiiIiI1 = '&file=/xml.php\?id=(\d+)'
iIiiiI1IiI1I1 = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 87 - 87: OoOoOO00
I11i = 24
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
@ oo000 . route ( '/' )
def I11iIi1I ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % O0 )
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
@ oo000 . route ( '/search' )
def O0oOO0o0 ( ) :
 i1ii1iIII = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if i1ii1iIII :
  Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( i1ii1iIII ) + '&p=%s'
  with open ( i111I , "a" ) as II1Ii1iI1i :
   II1Ii1iI1i . write ( i1ii1iIII + "\n" )
  iiI1iIiI = {
 "title" : "Search: %s" % i1ii1iIII ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
  OOo = '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  oo000 . redirect ( OOo )
  if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ oo000 . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo (
 '[Search List]' ,
 '/searchlist/'
 )
 oO000OoOoo00o = [ ]
 iiiI11 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( ii ) ,
 "thumbnail" : "https://uphinhnhanh.com/images/2018/01/08/fanart.jpg"
 } ]
 OOooO = [ ]
 if os . path . exists ( i111I ) :
  with open ( i111I , "r" ) as II1Ii1iI1i :
   OOooO = II1Ii1iI1i . read ( ) . strip ( ) . split ( "\n" )
  for OOoO00o in reversed ( OOooO ) :
   Oo0oO0oo0oO00 = 'http://phimbathu.com/tim-kiem.html?q=' + urllib . quote_plus ( OOoO00o ) + '&p=%s'
   iiI1iIiI = {
 "title" : "Search: %s" % OOoO00o ,
 "url" : Oo0oO0oo0oO00 ,
 "page" : 1
 }
   II111iiii = { }
   II111iiii [ "label" ] = OOoO00o
   II111iiii [ "path" ] = "%s/list_media/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "thumbnail" ] = "https://uphinhnhanh.com/images/2018/01/08/fanart.jpg"
   oO000OoOoo00o . append ( II111iiii )
 oO000OoOoo00o = iiiI11 + oO000OoOoo00o
 return oo000 . finish ( oO000OoOoo00o )
 if 48 - 48: I1Ii . IiIi1Iii1I1 - O0O0O0O00OooO % Ooooo % i1iIIIiI1I - I11i1i11i1I
@ oo000 . route ( '/list_media/<args_json>' )
def OoO000 ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Media of] %s - Page %s" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1"
 ) ,
 '/list_media/%s/%s' % (
 IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] if "page" in IIiiIiI1 else "1" ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] % IIiiIiI1 [ "page" ] )
 if "Search: " in IIiiIiI1 [ "title" ] :
  OooO0 = re . compile ( iIIii1IIi ) . findall ( iiIiIIi )
 else :
  OooO0 = re . compile ( oooo ) . findall ( iiIiIIi )
 for II11iiii1Ii , OO0o , Ooo , O0o0Oo , Oo00OOOOO in OooO0 :
  if "://" not in O0o0Oo :
   O0o0Oo = "http://phimbathu.com/" + O0o0Oo
  Oo0oO0oo0oO00 = "http://phimbathu.com/xem-phim/phim---%s" % Ooo
  O0O = "%s - %s" % ( OO0o , Oo00OOOOO )
  iiI1iIiI = {
 "title" : O0O ,
 "quality_label" : II11iiii1Ii ,
 "url" : Oo0oO0oo0oO00
 }
  II111iiii = { }
  II111iiii [ "label" ] = "%s (%s)" % (
 iiI1iIiI [ "title" ] ,
 iiI1iIiI [ "quality_label" ]
 )
  II111iiii [ "path" ] = "%s/list_mirrors/%s" % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  II111iiii [ "thumbnail" ] = O0o0Oo
  if "HD" in II11iiii1Ii :
   II111iiii [ "label" ] = "[COLOR yellow]%s[/COLOR]" % II111iiii [ "label" ]
  oO000OoOoo00o . append ( II111iiii )
 if len ( oO000OoOoo00o ) == I11i :
  O00o0OO = int ( IIiiIiI1 [ "page" ] ) + 1
  IIiiIiI1 [ "page" ] = O00o0OO
  oO000OoOoo00o . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( IIiiIiI1 ) )
 ) ,
 'thumbnail' : oOOo
 } )
 return oo000 . finish ( oO000OoOoo00o )
 if 44 - 44: O0O0O0O00OooO / OOooo000oo0 % IIIiiIIii * i1IIi11111i + I1Ii111
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1I ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Mirrors of] %s (%s)" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : IIiiIiI1 [ "url" ]
 }
 Oo0o0 = '%s/list_eps/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
 oo000 . redirect ( Oo0o0 )
 return oo000 . finish ( oO000OoOoo00o )
 if 49 - 49: i1IIi11111i % I1Ii + IIIiiIIii . IiII % i1111
@ oo000 . route ( '/list_eps/<args_json>' )
def I1i1iii ( args_json = { } ) :
 oO000OoOoo00o = [ ]
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Browse Episodes of] %s (%s) [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 iiIiIIi = ooOoo0O ( IIiiIiI1 [ "url" ] )
 i1iiI11I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiIiIIi )
 if len ( i1iiI11I ) > 0 :
  for iiii , oO0o0O0OOOoo0 in i1iiI11I :
   if "_HD2" not in iiii :
    iiii = iiii . replace ( ".html" , "_HD2.html" )
   IiIiiI = "http://phimbathu.com/xem-phim/phim---%s" % iiii
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "label" ]
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
 else :
  try :
   iiI1iIiI = {
 "title" : IIiiIiI1 [ "title" ] ,
 "quality_label" : IIiiIiI1 [ "quality_label" ] ,
 "mirror" : IIiiIiI1 [ "mirror" ] ,
 "url" : IIiiIiI1 [ "url" ] ,
 "eps" : "Full"
 }
   II111iiii = { }
   II111iiii [ "label" ] = "Part %s - %s (%s) [%s]" % (
 "Full" ,
 IIiiIiI1 [ "title" ] ,
 IIiiIiI1 [ "quality_label" ] ,
 IIiiIiI1 [ "mirror" ]
 )
   II111iiii [ "path" ] = '%s/play/%s' % (
 ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   II111iiii [ "is_playable" ] = True
   oO000OoOoo00o . append ( II111iiii )
  except :
   pass
 return oo000 . finish ( oO000OoOoo00o )
 if 31 - 31: I1Ii . I1Ii - IIii11I1 / ooOoO0o + i1iIIIiI1I * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 IIiiIiI1 = json . loads ( args_json )
 oo0ooO0oOOOOo (
 "[Play] %s (%s) - Part %s [%s]" % (
 IIiiIiI1 [ "title" ] if "title" in IIiiIiI1 else "Unknow Title" ,
 IIiiIiI1 [ "quality_label" ] if "quality_label" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "eps" ] if "eps" in IIiiIiI1 else "" ,
 IIiiIiI1 [ "mirror" ] if "mirror" in IIiiIiI1 else ""
 ) ,
 '/play/%s/%s' % (
 IIiiIiI1 [ "url" ] ,
 json . dumps ( IIiiIiI1 [ "payloads" ] ) if "payloads" in IIiiIiI1 else "{}"
 )
 )
 o00O = xbmcgui . DialogProgress ( )
 o00O . create ( 'PhimBatHu' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( OOO0OOO00oo ( IIiiIiI1 [ "url" ] ) )
 o00O . close ( )
 del o00O
 if 31 - 31: iII111i - I11i1i11i1I . Ooooo % o00O0oo - OOooo000oo0
def OOO0OOO00oo ( url ) :
 iiIiIIi = ooOoo0O ( url )
 iii11 = None
 OooO0 = re . search ( 'playerSetting = (\{.+?\})\;' , iiIiIIi ) . group ( 1 )
 O0oo0OO0oOOOo = json . loads ( OooO0 )
 i1i1i11IIi = "phimbathu.com4590481877" + O0oo0OO0oOOOo [ "modelId" ]
 II1III = [ "sourceLinks" , "sourceLinksBk" , "sourcesVs" , "sourcesTm" ]
 if 19 - 19: i1IIi11111i % IIIiiIIii % IIii11I1
 for oo0OooOOo0 in II1III :
  if oo0OooOOo0 in O0oo0OO0oOOOo :
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "gd" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       if requests . head ( II1Ii1iI1i ) . status_code != 404 :
        return oOOoo0Oo ( II1Ii1iI1i . replace ( "/preview" , "/view" ) , oo000 . get_setting ( 'HQ' , bool ) )
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "st" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       if requests . head ( II1Ii1iI1i ) . status_code != 404 :
        return II1Ii1iI1i
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "gs" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       if requests . head ( II1Ii1iI1i ) . status_code != 404 :
        return II1Ii1iI1i
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "ga" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       if re . search ( "=m\d+$" , II1Ii1iI1i ) :
        o00OO00OoO = re . sub ( "=m\d+$" , "=m37" , II1Ii1iI1i ) . replace ( "https://" , "http://" )
        OOOO0OOoO0O0 = requests . head ( o00OO00OoO ) . status_code
        if OOOO0OOoO0O0 != 404 :
         return o00OO00OoO
        o00OO00OoO = re . sub ( "=m\d+$" , "=m22" , II1Ii1iI1i ) . replace ( "https://" , "http://" )
        OOOO0OOoO0O0 = requests . head ( o00OO00OoO ) . status_code
        if OOOO0OOoO0O0 != 404 :
         return o00OO00OoO
        return II1Ii1iI1i
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "yt" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       O0Oo000ooO00 = re . compile ( '(youtu\.be\/|youtube-nocookie\.com\/|youtube\.com\/(watch\?(.*&)?v=|(embed|v|user)\/))([^\?&"\'>]+)' ) . findall ( II1Ii1iI1i )
       oO0 = O0Oo000ooO00 [ 0 ] [ len ( O0Oo000ooO00 [ 0 ] ) - 1 ] . replace ( 'v/' , '' )
       return 'plugin://plugin.video.youtube/play/?video_id=%s' % oO0
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "op" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       return urlresolver . resolve ( II1Ii1iI1i )
      except : pass
   for o0OO00oO in O0oo0OO0oOOOo [ oo0OooOOo0 ] :
    if o0OO00oO [ "server" ] == "gp" :
     for I11i1I1I in o0OO00oO [ "links" ] :
      try :
       II1Ii1iI1i = oO0Oo ( I11i1I1I [ "file" ] , i1i1i11IIi )
       return II1Ii1iI1i
      except : pass
 return iii11
 if 45 - 45: OoOoOO00 * iII111i % i1 + i1111 - I1Ii
 if 17 - 17: O0O0O0O00OooO
def ooOoo0O ( url , data = { } ) :
 ooOooo000oOO = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 'Content-Type' : 'text/html; charset=utf-8' ,
 }
 if data == { } :
  Oo0oOOo = requests . get (
 url ,
 headers = ooOooo000oOO )
 else :
  ooOooo000oOO [ "Content-Type" ] = "application/x-www-form-urlencoded"
  Oo0oOOo = requests . post (
 url ,
 headers = ooOooo000oOO ,
 data = data )
  return Oo0oOOo . json ( )
 Oo0oOOo . encoding = "utf-8"
 iiIiIIi = Oo0OoO00oOO0o ( Oo0oOOo . text . encode ( "utf8" ) )
 return iiIiIIi
 if 80 - 80: i1IIi11111i + I11i1i11i1I - I11i1i11i1I % IiIi1Iii1I1
def oOOoo0Oo ( url , hq ) :
 ooOooo000oOO = {
 'User-Agent' : o0O ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 Oo0oOOo = requests . get ( url , headers = ooOooo000oOO )
 O0Oo000ooO00 = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( Oo0oOOo . text ) [ 0 ]
 OoOO0oo0o = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : reversed ( OoOO0oo0o )
 II11i1I11Ii1i = json . loads ( O0Oo000ooO00 ) [ 1 ] . split ( "," )
 for O000O0oOO0 in OoOO0oo0o :
  for O0ooo0O0oo0 in II11i1I11Ii1i :
   if O0ooo0O0oo0 . startswith ( O000O0oOO0 + "|" ) :
    url = O0ooo0O0oo0 . split ( "|" ) [ 1 ]
    oo0oOo = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( o0O ) , urllib . quote ( Oo0oOOo . headers [ 'set-cookie' ] ) )
    return url + oo0oOo
 raise ValueError ( 'NaN' )
 if 89 - 89: o00O0oo
def OO0oOoOO0oOO0 ( url , data = { } ) :
 ooOooo000oOO = {
 'User-Agent' : iI11I1II1I1I ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  Oo0oOOo = requests . get (
 url ,
 headers = ooOooo000oOO )
 else :
  ooOooo000oOO [ "Content-Type" ] = "application/x-www-form-urlencoded"
  Oo0oOOo = requests . post (
 url ,
 headers = ooOooo000oOO ,
 data = data )
 Oo0oOOo . encoding = "utf-8"
 iiIiIIi = Oo0OoO00oOO0o ( Oo0oOOo . text . encode ( "utf8" ) )
 return iiIiIIi
 if 86 - 86: I11i1i11i1I
def Oo0OoO00oOO0o ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 55 - 55: I1Ii111 + i1 / o00O0oo * i1IIi11111i - OoOoOO00 - I1Ii
def ii1ii1ii ( s ) :
 O000O0oOO0 = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( O000O0oOO0 , '' , s )
 return s . strip ( )
 if 91 - 91: O0O0O0O00OooO
def oo0ooO0oOOOOo ( title = "Home" , page = "/" ) :
 try :
  iiIii = "http://www.google-analytics.com/collect"
  ooo0O = open ( oOoO0o00OO0 ) . read ( )
  i1I1ii = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ooo0O ,
 't' : 'pageview' ,
 'dp' : "PhimBatHu%s" % page ,
 'dt' : "[PhimBatHu] - %s" % title . encode ( "utf8" )
 }
  requests . post ( iiIii , data = urllib . urlencode ( i1I1ii ) )
 except :
  pass
  if 61 - 61: iII111i
def O0OOO ( pattern , string , group = 1 , flags = 0 , result = '' ) :
 try : iiIiIIi = re . search ( pattern , string , flags ) . group ( group )
 except : iiIiIIi = result
 return iiIiIIi
 if 10 - 10: I11i1i11i1I * Iiii % o00O0oo / IiII / o00O0oo
def oO0Oo ( string , key = '' ) :
 import ctypes
 def iIIi1i1 ( l , s = 4 ) :
  i1IIIiiII1 = [ ]
  for OOOOoOoo0O0O0 in range ( 0 , len ( l ) , s ) : i1IIIiiII1 . append ( ( l [ OOOOoOoo0O0O0 : OOOOoOoo0O0O0 + s ] ) )
  return i1IIIiiII1
  if 85 - 85: i1IIi11111i % OoOoOO00 - IiIi1Iii1I1 * ii1IiI1i / IiII % IiII
 def IIiIi1iI ( v ) : return ctypes . c_int ( v ) . value
 def i1IiiiI1iI ( val , n ) : return ( val % 0x100000000 ) >> n
 if 49 - 49: I1Ii / ooOoO0o . iII111i
 ooOOoooooo = 14
 II1I = 8
 O0i1II1Iiii1I11 = False
 if 9 - 9: i1111 / I1Ii111 - IiII / ii1IiI1i / i1 - IIii11I1
 def II1Ii1iI1i ( e ) :
  if 91 - 91: IiIi1Iii1I1 % IIIiiIIii % i1
  if 20 - 20: I11i1i11i1I % I1Ii / I1Ii + I1Ii
  return str ( e )
  if 45 - 45: i1IIi11111i - O0O0O0O00OooO - ii1IiI1i - ooOoO0o . iII111i / OOooo000oo0
 def oo0o00O ( e ) :
  if 51 - 51: I1Ii - ooOoO0o * IiIi1Iii1I1
  if 66 - 66: ii1IiI1i + OOooo000oo0
  return str ( e )
  if 11 - 11: Iiii + ii1IiI1i - ooOoO0o / IIii11I1 + I1Ii111 . iII111i
 def i1Iii1i1I ( e ) :
  II1Ii1iI1i = [ 0 ] * len ( e )
  if 16 > len ( e ) :
   II1I = 16 - len ( e )
   II1Ii1iI1i = [ II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I , II1I ]
  for O0i1II1Iiii1I11 in range ( len ( e ) ) : II1Ii1iI1i [ O0i1II1Iiii1I11 ] = e [ O0i1II1Iiii1I11 ]
  return II1Ii1iI1i
  if 91 - 91: i1111 + IiII . I11i1i11i1I * i1111 + IiII * I1Ii111
 def O000OOOOOo ( e ) :
  O0i1II1Iiii1I11 = ""
  for II1I in len ( e ) : O0i1II1Iiii1I11 += ( "0" if 16 > e [ II1I ] else "" ) + format ( e [ II1I ] , 'x' )
  return O0i1II1Iiii1I11
  if 22 - 22: IIIiiIIii + OOooo000oo0 . i1 * IiIi1Iii1I1 % OoOoOO00 * IiII
 def oo000o ( e , r ) :
  oo0o00O = [ ]
  if not r : e = II1Ii1iI1i ( e )
  for O0i1II1Iiii1I11 in range ( len ( e ) ) : oo0o00O . append ( ord ( e [ O0i1II1Iiii1I11 ] ) )
  return oo0o00O
  if 44 - 44: IIIiiIIii % iII111i + Iiii
 def OOOOoOoo0O0O0 ( n ) :
  if n == 128 : ooOOoooooo = 10 ; II1I = 4
  elif n == 192 : ooOOoooooo = 12 ; II1I = 6
  elif n == 256 : ooOOoooooo = 14 ; II1I = 8
  if 45 - 45: IiIi1Iii1I1 / IiIi1Iii1I1 + Ooooo + i1iIIIiI1I
 def iI111i ( e ) :
  O0i1II1Iiii1I11 = [ ]
  for II1I in range ( e ) : O0i1II1Iiii1I11 . append ( 256 )
  return O0i1II1Iiii1I11
  if 26 - 26: i1111 * IiIi1Iii1I1 . iII111i * I1Ii
 def II1 ( n , f ) :
  iiiIi1 = [ ] ; i1Iii1i1I = 3 if ooOOoooooo >= 12 else 2 ; OOOOoOoo0O0O0 = n + f ; iiiIi1 . append ( i1I1ii11i1Iii ( OOOOoOoo0O0O0 ) ) ; oo000o = [ oo0o00O for oo0o00O in iiiIi1 [ 0 ] ]
  for oo0o00O in range ( 1 , i1Iii1i1I ) : iiiIi1 . append ( i1I1ii11i1Iii ( iiiIi1 [ oo0o00O - 1 ] + OOOOoOoo0O0O0 ) ) ; oo000o += iiiIi1 [ oo0o00O ]
  return { 'key' : oo000o [ 0 : 4 * II1I ] , 'iv' : oo000o [ 4 * II1I : 4 * II1I + 16 ] }
  if 26 - 26: Iiii - i1 - IiII / ooOoO0o . o00O0oo % i1
 def OO ( e , r = False ) :
  oo0o00O = ""
  if ( r ) :
   O0i1II1Iiii1I11 = e [ 15 ]
   if 25 - 25: ooOoO0o
   if 16 != O0i1II1Iiii1I11 :
    for II1Ii1iI1i in range ( 16 - O0i1II1Iiii1I11 ) : oo0o00O += chr ( e [ II1Ii1iI1i ] )
  else :
   for II1Ii1iI1i in range ( 16 ) : oo0o00O += chr ( e [ II1Ii1iI1i ] )
  return oo0o00O
  if 62 - 62: I11i1i11i1I + OOooo000oo0
 def i1IIIiiII1 ( e , r = False ) :
  if not r : oo0o00O = '' . join ( chr ( e [ f ] ) for f in range ( 16 ) )
  elif 16 != e [ 15 ] : oo0o00O = '' . join ( chr ( e [ f ] ) for f in range ( 16 - e [ 15 ] ) )
  else : oo0o00O = ''
  return oo0o00O
  if 98 - 98: IIii11I1
 def OOOO0oo0 ( e , r , n , f = '' ) :
  r = I11iiI1i1 ( r ) ; O000OOOOOo = len ( e ) / 16 ; oo000o = [ 0 ] * O000OOOOOo
  iiiIi1 = [ e [ 16 * i1Iii1i1I : 16 * ( i1Iii1i1I + 1 ) ] for i1Iii1i1I in range ( O000OOOOOo ) ]
  for i1Iii1i1I in range ( len ( iiiIi1 ) - 1 , - 1 , - 1 ) :
   oo000o [ i1Iii1i1I ] = I1i1Iiiii ( iiiIi1 [ i1Iii1i1I ] , r )
   oo000o [ i1Iii1i1I ] = OOo0oO00ooO00 ( oo000o [ i1Iii1i1I ] , n ) if 0 == i1Iii1i1I else OOo0oO00ooO00 ( oo000o [ i1Iii1i1I ] , iiiIi1 [ i1Iii1i1I - 1 ] )
   if 90 - 90: o00O0oo * Ooooo + IIii11I1
  OOOOoOoo0O0O0 = '' . join ( i1IIIiiII1 ( oo000o [ i1Iii1i1I ] ) for i1Iii1i1I in range ( O000OOOOOo - 1 ) )
  OOOOoOoo0O0O0 += i1IIIiiII1 ( oo000o [ O000OOOOOo - 1 ] , True )
  return OOOOoOoo0O0O0 if f else oo0o00O ( OOOOoOoo0O0O0 )
  if 81 - 81: i1IIi11111i . IIii11I1 % OOooo000oo0 / IiII - i1IIi11111i
 def iiIiIIi ( r , f ) :
  O0i1II1Iiii1I11 = False
  i1Iii1i1I = Ii1I1i ( r , f , 0 )
  for oo0o00O in ( 1 , ooOOoooooo + 1 , 1 ) :
   i1Iii1i1I = OOI1iI1ii1II ( i1Iii1i1I )
   i1Iii1i1I = O0O0OOOOoo ( i1Iii1i1I )
   if ooOOoooooo > oo0o00O : i1Iii1i1I = oOooO0 ( i1Iii1i1I )
   i1Iii1i1I = Ii1I1i ( i1Iii1i1I , f , oo0o00O )
  return i1Iii1i1I
  if 29 - 29: i1 + o00O0oo * ooOoO0o * I11i1i11i1I . IiII * IiII
 def I1i1Iiiii ( r , f ) :
  O0i1II1Iiii1I11 = True
  i1Iii1i1I = Ii1I1i ( r , f , ooOOoooooo )
  for oo0o00O in range ( ooOOoooooo - 1 , - 1 , - 1 ) :
   i1Iii1i1I = O0O0OOOOoo ( i1Iii1i1I , O0i1II1Iiii1I11 )
   i1Iii1i1I = OOI1iI1ii1II ( i1Iii1i1I , O0i1II1Iiii1I11 )
   i1Iii1i1I = Ii1I1i ( i1Iii1i1I , f , oo0o00O )
   if oo0o00O > 0 : i1Iii1i1I = oOooO0 ( i1Iii1i1I , O0i1II1Iiii1I11 )
  return i1Iii1i1I
  if 7 - 7: O0O0O0O00OooO * Ooooo % I1Ii - IIii11I1
 def OOI1iI1ii1II ( e , n = True ) :
  II1Ii1iI1i = i1i if n else oOOoo00O00o ; oo0o00O = [ 0 ] * 16
  for II1I in range ( 16 ) : oo0o00O [ II1I ] = II1Ii1iI1i [ e [ II1I ] ]
  return oo0o00O
  if 98 - 98: I11i1i11i1I + O0O0O0O00OooO + i1IIi11111i % ii1IiI1i
 def O0O0OOOOoo ( e , n = True ) :
  II1Ii1iI1i = [ ]
  if n : oo0o00O = [ 0 , 13 , 10 , 7 , 4 , 1 , 14 , 11 , 8 , 5 , 2 , 15 , 12 , 9 , 6 , 3 ]
  else : oo0o00O = [ 0 , 5 , 10 , 15 , 4 , 9 , 14 , 3 , 8 , 13 , 2 , 7 , 12 , 1 , 6 , 11 ]
  for II1I in range ( 16 ) : II1Ii1iI1i . append ( e [ oo0o00O [ II1I ] ] )
  return II1Ii1iI1i
  if 97 - 97: OOooo000oo0 * ii1IiI1i . ii1IiI1i
 def oOooO0 ( e , n = True ) :
  II1Ii1iI1i = [ 0 ] * 16
  if ( n ) :
   for II1I in range ( 4 ) :
    II1Ii1iI1i [ 4 * II1I ] = I111iI [ e [ 4 * II1I ] ] ^ oOOo0 [ e [ 1 + 4 * II1I ] ] ^ II1I1iiIII [ e [ 2 + 4 * II1I ] ] ^ oOOo0O00o [ e [ 3 + 4 * II1I ] ]
    II1Ii1iI1i [ 1 + 4 * II1I ] = oOOo0O00o [ e [ 4 * II1I ] ] ^ I111iI [ e [ 1 + 4 * II1I ] ] ^ oOOo0 [ e [ 2 + 4 * II1I ] ] ^ II1I1iiIII [ e [ 3 + 4 * II1I ] ]
    II1Ii1iI1i [ 2 + 4 * II1I ] = II1I1iiIII [ e [ 4 * II1I ] ] ^ oOOo0O00o [ e [ 1 + 4 * II1I ] ] ^ I111iI [ e [ 2 + 4 * II1I ] ] ^ oOOo0 [ e [ 3 + 4 * II1I ] ]
    II1Ii1iI1i [ 3 + 4 * II1I ] = oOOo0 [ e [ 4 * II1I ] ] ^ II1I1iiIII [ e [ 1 + 4 * II1I ] ] ^ oOOo0O00o [ e [ 2 + 4 * II1I ] ] ^ I111iI [ e [ 3 + 4 * II1I ] ]
  else :
   for II1I in range ( 4 ) :
    II1Ii1iI1i [ 4 * II1I ] = iIiIi11 [ e [ 4 * II1I ] ] ^ OOO [ e [ 1 + 4 * II1I ] ] ^ e [ 2 + 4 * II1I ] ^ e [ 3 + 4 * II1I ]
    II1Ii1iI1i [ 1 + 4 * II1I ] = e [ 4 * II1I ] ^ iIiIi11 [ e [ 1 + 4 * II1I ] ] ^ OOO [ e [ 2 + 4 * II1I ] ] ^ e [ 3 + 4 * II1I ]
    II1Ii1iI1i [ 2 + 4 * II1I ] = e [ 4 * II1I ] ^ e [ 1 + 4 * II1I ] ^ iIiIi11 [ e [ 2 + 4 * II1I ] ] ^ OOO [ e [ 3 + 4 * II1I ] ]
    II1Ii1iI1i [ 3 + 4 * II1I ] = OOO [ e [ 4 * II1I ] ] ^ e [ 1 + 4 * II1I ] ^ e [ 2 + 4 * II1I ] ^ iIiIi11 [ e [ 3 + 4 * II1I ] ]
  return II1Ii1iI1i
  if 32 - 32: IIIiiIIii / iII111i . I1Ii111
 def Ii1I1i ( e , r , n ) :
  oo0o00O = [ 0 ] * 16
  for II1Ii1iI1i in range ( 16 ) : oo0o00O [ II1Ii1iI1i ] = e [ II1Ii1iI1i ] ^ r [ n ] [ II1Ii1iI1i ]
  return oo0o00O
  if 62 - 62: ii1IiI1i * IiII
 def OOo0oO00ooO00 ( e , r ) :
  II1Ii1iI1i = [ 0 ] * 16
  for O0i1II1Iiii1I11 in range ( 16 ) : II1Ii1iI1i [ O0i1II1Iiii1I11 ] = e [ O0i1II1Iiii1I11 ] ^ r [ O0i1II1Iiii1I11 ]
  return II1Ii1iI1i
  if 58 - 58: o00O0oo % IIii11I1
 def I11iiI1i1 ( n ) :
  O000OOOOOo = [ [ n [ 4 * II1Ii1iI1i + OOOOoOoo0O0O0 ] for OOOOoOoo0O0O0 in range ( 4 ) ] for II1Ii1iI1i in range ( II1I ) ]
  if 50 - 50: Ooooo . IIii11I1
  for II1Ii1iI1i in range ( II1I , 4 * ( ooOOoooooo + 1 ) ) :
   iiiIi1 = [ i1Iii1i1I for i1Iii1i1I in O000OOOOOo [ II1Ii1iI1i - 1 ] ]
   if 0 == II1Ii1iI1i % II1I : iiiIi1 = ooO0OO ( O000OOO ( iiiIi1 ) ) ; iiiIi1 [ 0 ] ^= II [ II1Ii1iI1i / II1I - 1 ]
   elif II1I > 6 and 4 == II1Ii1iI1i % II1I : iiiIi1 = ooO0OO ( iiiIi1 )
   O000OOOOOo . append ( [ O000OOOOOo [ II1Ii1iI1i - II1I ] [ i1Iii1i1I ] ^ iiiIi1 [ i1Iii1i1I ] for i1Iii1i1I in range ( 4 ) ] )
   if 77 - 77: I11i1i11i1I * i1
  oo000o = [ ]
  for II1Ii1iI1i in range ( ooOOoooooo + 1 ) :
   oo000o . append ( [ ] )
   for i1IIIiiII1 in range ( 4 ) : oo000o [ II1Ii1iI1i ] += O000OOOOOo [ 4 * II1Ii1iI1i + i1IIIiiII1 ]
  return oo000o
  if 98 - 98: IiII % I1Ii * ii1IiI1i
 def ooO0OO ( e ) :
  return [ oOOoo00O00o [ e [ II1I ] ] for II1I in range ( 4 ) ]
  if 51 - 51: i1 . o00O0oo / i1IIi11111i + IIii11I1
 def O000OOO ( e ) :
  e . insert ( 4 , e [ 0 ] )
  e . remove ( e [ 4 ] )
  return e
  if 33 - 33: i1iIIIiI1I . iII111i % IiIi1Iii1I1 + IIii11I1
 def oO00O000oO0 ( e , r ) : return [ int ( e [ O0i1II1Iiii1I11 : O0i1II1Iiii1I11 + r ] , 16 ) for O0i1II1Iiii1I11 in range ( 0 , len ( e ) , r ) ]
 if 79 - 79: Iiii - ii1IiI1i - i1IIi11111i - i1 * I11i1i11i1I
 def Iii ( e ) :
  O0i1II1Iiii1I11 = [ 0 ] * len ( e )
  for II1I in range ( len ( e ) ) : O0i1II1Iiii1I11 [ e [ II1I ] ] = II1I
  return O0i1II1Iiii1I11
  if 16 - 16: I1Ii + O0O0O0O00OooO * OOooo000oo0 % IIIiiIIii . IiII
 def Oo0OO ( e , r ) :
  II1Ii1iI1i = 0
  for O0i1II1Iiii1I11 in range ( 8 ) :
   II1Ii1iI1i = II1Ii1iI1i ^ e if 1 == ( 1 & r ) else II1Ii1iI1i
   e = IIiIi1iI ( 283 ^ e << 1 ) if e > 127 else IIiIi1iI ( e << 1 )
   r >>= 1
  return II1Ii1iI1i
  if 78 - 78: I11i1i11i1I - ii1IiI1i - i1111 / i1iIIIiI1I / iII111i
 def iiI11ii1I1 ( e ) :
  O0i1II1Iiii1I11 = [ 0 ] * 256
  for II1I in range ( 256 ) : O0i1II1Iiii1I11 [ II1I ] = Oo0OO ( e , II1I )
  return O0i1II1Iiii1I11
  if 82 - 82: iII111i % Iiii / ooOoO0o + o00O0oo / IIii11I1 / Ooooo
 oOOoo00O00o = oO00O000oO0 ( "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16" , 2 )
 i1i = Iii ( oOOoo00O00o )
 II = oO00O000oO0 ( "01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591" , 2 )
 iIiIi11 = iiI11ii1I1 ( 2 )
 OOO = iiI11ii1I1 ( 3 )
 oOOo0O00o = iiI11ii1I1 ( 9 )
 oOOo0 = iiI11ii1I1 ( 11 )
 II1I1iiIII = iiI11ii1I1 ( 13 )
 I111iI = iiI11ii1I1 ( 14 )
 if 70 - 70: i1IIi11111i
 def oOOoO0o0oO ( e , r , n = '' ) :
  II1Ii1iI1i = o0Oo0oO0oOO00 ( e )
  oo0o00O = II1Ii1iI1i [ 8 : 16 ]
  i1Iii1i1I = II1 ( oo000o ( r , n ) , oo0o00O )
  i1IIIiiII1 = i1Iii1i1I [ 'key' ]
  O000OOOOOo = i1Iii1i1I [ 'iv' ]
  II1Ii1iI1i = II1Ii1iI1i [ 16 : len ( II1Ii1iI1i ) ]
  return OOOO0oo0 ( II1Ii1iI1i , i1IIIiiII1 , O000OOOOOo , n )
  if 92 - 92: ii1IiI1i * Ooooo
 def o0Oo0oO0oOO00 ( r ) :
  def o0000oO ( n ) :
   try : i1IIIiiII1 = ooOOoooooo . index ( r [ n ] )
   except : i1IIIiiII1 = - 1
   return i1IIIiiII1
   if 11 - 11: i1iIIIiI1I / o00O0oo - O0O0O0O00OooO * ii1IiI1i + ii1IiI1i . o00O0oo
  ooOOoooooo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  r = r . replace ( '\n' , '' ) ; II1Ii1iI1i = [ ] ; oo0o00O = [ 0 ] * 4
  for O0i1II1Iiii1I11 in range ( 0 , len ( r ) , 4 ) :
   for OOOOoOoo0O0O0 in range ( len ( oo0o00O ) ) : oo0o00O [ OOOOoOoo0O0O0 ] = o0000oO ( O0i1II1Iiii1I11 + OOOOoOoo0O0O0 )
   II1Ii1iI1i . append ( IIiIi1iI ( oo0o00O [ 0 ] << 2 | oo0o00O [ 1 ] >> 4 ) )
   II1Ii1iI1i . append ( IIiIi1iI ( ( 15 & oo0o00O [ 1 ] ) << 4 | oo0o00O [ 2 ] >> 2 ) )
   II1Ii1iI1i . append ( IIiIi1iI ( ( 3 & oo0o00O [ 2 ] ) << 6 | oo0o00O [ 3 ] ) )
  return II1Ii1iI1i [ 0 : len ( II1Ii1iI1i ) - len ( II1Ii1iI1i ) % 16 ]
  if 26 - 26: I1Ii % i1111
 def i1I1ii11i1Iii ( e ) :
  def II1I ( e , r ) : return IIiIi1iI ( e << r ) | IIiIi1iI ( i1IiiiI1iI ( e , 32 - r ) )
  if 76 - 76: O0O0O0O00OooO * IiIi1Iii1I1
  def O0i1II1Iiii1I11 ( e , r ) :
   oo0o00O = 2147483648 & e
   i1Iii1i1I = 2147483648 & r
   O0i1II1Iiii1I11 = 1073741824 & e
   II1Ii1iI1i = 1073741824 & r
   i1IIIiiII1 = ( 1073741823 & e ) + ( 1073741823 & r )
   OOOOoOoo0O0O0 = 2147483648 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   II1I1iiIII = 3221225472 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   oOooO0 = 1073741824 ^ i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I
   return IIiIi1iI ( OOOOoOoo0O0O0 if O0i1II1Iiii1I11 & II1Ii1iI1i else ( ( II1I1iiIII if 1073741824 & i1IIIiiII1 else oOooO0 ) if O0i1II1Iiii1I11 | II1Ii1iI1i else i1IIIiiII1 ^ oo0o00O ^ i1Iii1i1I ) )
   if 52 - 52: I11i1i11i1I
  def II1Ii1iI1i ( e , r , n ) : return IIiIi1iI ( e & r ) | IIiIi1iI ( ~ e & n )
  if 19 - 19: IiII
  def oo0o00O ( e , r , n ) : return IIiIi1iI ( e & n ) | IIiIi1iI ( r & ~ n )
  if 25 - 25: I1Ii / i1iIIIiI1I
  def i1Iii1i1I ( e , r , n ) : return e ^ r ^ n
  if 31 - 31: I11i1i11i1I . OOooo000oo0 % IiII . IIii11I1 + O0O0O0O00OooO
  def i1IIIiiII1 ( e , r , n ) : return r ^ ( e | ~ n )
  if 71 - 71: Ooooo . iII111i
  def O000OOOOOo ( e , c , t , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( II1Ii1iI1i ( c , t , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , c )
   if 62 - 62: ii1IiI1i . Iiii
  def iiiIi1 ( e , f , t , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( oo0o00O ( f , t , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 61 - 61: o00O0oo - I11i1i11i1I - IIIiiIIii
  def oo000o ( e , f , c , a , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( i1Iii1i1I ( f , c , a ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 25 - 25: OOooo000oo0 * Iiii + i1111 . IIii11I1 . IIii11I1
  def OOOOoOoo0O0O0 ( e , f , c , t , o , d , u ) :
   e = O0i1II1Iiii1I11 ( e , O0i1II1Iiii1I11 ( O0i1II1Iiii1I11 ( i1IIIiiII1 ( f , c , t ) , o ) , u ) )
   return O0i1II1Iiii1I11 ( II1I ( e , d ) , f )
   if 58 - 58: IiII
  def iI111i ( e ) :
   O0i1II1Iiii1I11 = len ( e ) ; II1Ii1iI1i = O0i1II1Iiii1I11 + 8 ; oo0o00O = ( II1Ii1iI1i - II1Ii1iI1i % 64 ) / 64 ; i1Iii1i1I = 16 * ( oo0o00O + 1 ) ; i1IIIiiII1 = [ 0 ] * i1Iii1i1I ; O000OOOOOo = 0
   for iiiIi1 in range ( O0i1II1Iiii1I11 ) : II1I = ( iiiIi1 - iiiIi1 % 4 ) / 4 ; O000OOOOOo = 8 * ( iiiIi1 % 4 ) ; i1IIIiiII1 [ II1I ] = i1IIIiiII1 [ II1I ] | IIiIi1iI ( e [ iiiIi1 ] << O000OOOOOo )
   iiiIi1 += 1
   II1I = ( iiiIi1 - iiiIi1 % 4 ) / 4
   O000OOOOOo = 8 * ( iiiIi1 % 4 )
   i1IIIiiII1 [ II1I ] = i1IIIiiII1 [ II1I ] | IIiIi1iI ( 128 << O000OOOOOo )
   i1IIIiiII1 [ i1Iii1i1I - 2 ] = IIiIi1iI ( O0i1II1Iiii1I11 << 3 )
   i1IIIiiII1 [ i1Iii1i1I - 1 ] = IIiIi1iI ( i1IiiiI1iI ( O0i1II1Iiii1I11 , 29 ) )
   return i1IIIiiII1
   if 53 - 53: IIIiiIIii
  def II1 ( e ) :
   II1Ii1iI1i = [ ]
   for O0i1II1Iiii1I11 in range ( 4 ) :
    II1I = IIiIi1iI ( 255 & i1IiiiI1iI ( e , 8 * O0i1II1Iiii1I11 ) )
    II1Ii1iI1i . append ( II1I )
   return II1Ii1iI1i
   if 59 - 59: IIii11I1
  ooO0OO = oO00O000oO0 ( "67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391" , 8 )
  I11iiI1i1 = [ ] ; I11iiI1i1 = iI111i ( e ) ; O0O0OOOOoo = ooO0OO [ 0 ] ; oOooO0 = ooO0OO [ 1 ] ; Ii1I1i = ooO0OO [ 2 ] ; OOo0oO00ooO00 = ooO0OO [ 3 ] ; oOoO00O0 = 0
  for oOoO00O0 in range ( 0 , len ( I11iiI1i1 ) , 16 ) :
   OOOO0oo0 = O0O0OOOOoo
   iiIiIIi = oOooO0
   I1i1Iiiii = Ii1I1i
   OOI1iI1ii1II = OOo0oO00ooO00
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 0 ] , 7 , ooO0OO [ 4 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 1 ] , 12 , ooO0OO [ 5 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 2 ] , 17 , ooO0OO [ 6 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 3 ] , 22 , ooO0OO [ 7 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 4 ] , 7 , ooO0OO [ 8 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 5 ] , 12 , ooO0OO [ 9 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 6 ] , 17 , ooO0OO [ 10 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 7 ] , 22 , ooO0OO [ 11 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 8 ] , 7 , ooO0OO [ 12 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 9 ] , 12 , ooO0OO [ 13 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 10 ] , 17 , ooO0OO [ 14 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 11 ] , 22 , ooO0OO [ 15 ] )
   O0O0OOOOoo = O000OOOOOo ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 12 ] , 7 , ooO0OO [ 16 ] )
   OOo0oO00ooO00 = O000OOOOOo ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 13 ] , 12 , ooO0OO [ 17 ] )
   Ii1I1i = O000OOOOOo ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 14 ] , 17 , ooO0OO [ 18 ] )
   oOooO0 = O000OOOOOo ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 15 ] , 22 , ooO0OO [ 19 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 1 ] , 5 , ooO0OO [ 20 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 6 ] , 9 , ooO0OO [ 21 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 11 ] , 14 , ooO0OO [ 22 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 0 ] , 20 , ooO0OO [ 23 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 5 ] , 5 , ooO0OO [ 24 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 10 ] , 9 , ooO0OO [ 25 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 15 ] , 14 , ooO0OO [ 26 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 4 ] , 20 , ooO0OO [ 27 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 9 ] , 5 , ooO0OO [ 28 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 14 ] , 9 , ooO0OO [ 29 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 3 ] , 14 , ooO0OO [ 30 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 8 ] , 20 , ooO0OO [ 31 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 13 ] , 5 , ooO0OO [ 32 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 2 ] , 9 , ooO0OO [ 33 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 7 ] , 14 , ooO0OO [ 34 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 12 ] , 20 , ooO0OO [ 35 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 5 ] , 4 , ooO0OO [ 36 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 8 ] , 11 , ooO0OO [ 37 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 11 ] , 16 , ooO0OO [ 38 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 14 ] , 23 , ooO0OO [ 39 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 1 ] , 4 , ooO0OO [ 40 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 4 ] , 11 , ooO0OO [ 41 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 7 ] , 16 , ooO0OO [ 42 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 10 ] , 23 , ooO0OO [ 43 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 13 ] , 4 , ooO0OO [ 44 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 0 ] , 11 , ooO0OO [ 45 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 3 ] , 16 , ooO0OO [ 46 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 6 ] , 23 , ooO0OO [ 47 ] )
   O0O0OOOOoo = oo000o ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 9 ] , 4 , ooO0OO [ 48 ] )
   OOo0oO00ooO00 = oo000o ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 12 ] , 11 , ooO0OO [ 49 ] )
   Ii1I1i = oo000o ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 15 ] , 16 , ooO0OO [ 50 ] )
   oOooO0 = oo000o ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 2 ] , 23 , ooO0OO [ 51 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 0 ] , 6 , ooO0OO [ 52 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 7 ] , 10 , ooO0OO [ 53 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 14 ] , 15 , ooO0OO [ 54 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 5 ] , 21 , ooO0OO [ 55 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 12 ] , 6 , ooO0OO [ 56 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 3 ] , 10 , ooO0OO [ 57 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 10 ] , 15 , ooO0OO [ 58 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 1 ] , 21 , ooO0OO [ 59 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 8 ] , 6 , ooO0OO [ 60 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 15 ] , 10 , ooO0OO [ 61 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 6 ] , 15 , ooO0OO [ 62 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 13 ] , 21 , ooO0OO [ 63 ] )
   O0O0OOOOoo = OOOOoOoo0O0O0 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ oOoO00O0 + 4 ] , 6 , ooO0OO [ 64 ] )
   OOo0oO00ooO00 = OOOOoOoo0O0O0 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ oOoO00O0 + 11 ] , 10 , ooO0OO [ 65 ] )
   Ii1I1i = OOOOoOoo0O0O0 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ oOoO00O0 + 2 ] , 15 , ooO0OO [ 66 ] )
   oOooO0 = OOOOoOoo0O0O0 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ oOoO00O0 + 9 ] , 21 , ooO0OO [ 67 ] )
   O0O0OOOOoo = O0i1II1Iiii1I11 ( O0O0OOOOoo , OOOO0oo0 )
   oOooO0 = O0i1II1Iiii1I11 ( oOooO0 , iiIiIIi )
   Ii1I1i = O0i1II1Iiii1I11 ( Ii1I1i , I1i1Iiiii )
   OOo0oO00ooO00 = O0i1II1Iiii1I11 ( OOo0oO00ooO00 , OOI1iI1ii1II )
  return II1 ( O0O0OOOOoo ) + II1 ( oOooO0 ) + II1 ( Ii1I1i ) + II1 ( OOo0oO00ooO00 )
  if 75 - 75: IiII . i1iIIIiI1I . OOooo000oo0 * Ooooo
  if 4 - 4: I1Ii % i1IIi11111i * ooOoO0o
 def o0O0OOOOoOO0 ( b ) :
  def iiO0oOo00o ( s ) :
   O000OOO , OOOOoOoo0O0O0 , s , ooOOoooooo = s . split ( ',' )
   i1IIIiiII1 = iI111i = oo0o00O = 0 ; iiiIi1 = [ ] ; II1Ii1iI1i = [ ]
   while True :
    if i1IIIiiII1 < 5 : II1Ii1iI1i . append ( O000OOO [ i1IIIiiII1 ] )
    elif i1IIIiiII1 < len ( O000OOO ) : iiiIi1 . append ( O000OOO [ i1IIIiiII1 ] )
    i1IIIiiII1 += 1
    if 81 - 81: O0O0O0O00OooO % IIIiiIIii . i1
    if iI111i < 5 : II1Ii1iI1i . append ( OOOOoOoo0O0O0 [ iI111i ] )
    elif iI111i < len ( OOOOoOoo0O0O0 ) : iiiIi1 . append ( OOOOoOoo0O0O0 [ iI111i ] )
    iI111i += 1
    if 4 - 4: OoOoOO00 % ooOoO0o % IIIiiIIii / O0O0O0O00OooO
    if oo0o00O < 5 : II1Ii1iI1i . append ( s [ oo0o00O ] )
    elif oo0o00O < len ( s ) : iiiIi1 . append ( s [ oo0o00O ] )
    oo0o00O += 1
    if 6 - 6: IiIi1Iii1I1 / IiII % I11i1i11i1I - IiII
    if len ( O000OOO ) + len ( OOOOoOoo0O0O0 ) + len ( s ) + len ( ooOOoooooo ) == len ( iiiIi1 ) + len ( II1Ii1iI1i ) + len ( ooOOoooooo ) : break
    if 31 - 31: I11i1i11i1I
   oOooO0 = '' . join ( s for s in iiiIi1 ) ; ooO0OO = '' . join ( s for s in II1Ii1iI1i ) ; iI111i = 0 ; O000OOOOOo = [ ]
   for i1IIIiiII1 in range ( 0 , len ( iiiIi1 ) , 2 ) :
    O0i1II1Iiii1I11 = - 1
    if ord ( ooO0OO [ iI111i ] ) % 2 : O0i1II1Iiii1I11 = 1
    O000OOOOOo . append ( chr ( int ( oOooO0 [ i1IIIiiII1 : i1IIIiiII1 + 2 ] , 36 ) - O0i1II1Iiii1I11 ) )
    iI111i += 1
    if iI111i >= len ( II1Ii1iI1i ) : iI111i = 0
   return '' . join ( s for s in O000OOOOOo )
  oOoO00O0 = 0
  while oOoO00O0 < 5 or 'decodeLink' not in b :
   try : b = iiO0oOo00o ( O0OOO ( "(\w{100,},\w+,\w+,\w+)" , b . replace ( "'" , '' ) ) ) ; oOoO00O0 += 1
   except : break
  return b
  if 23 - 23: Ooooo . O0O0O0O00OooO
 return oOOoO0o0oO ( string , key ) if key else o0O0OOOOoOO0 ( string )
 if 92 - 92: o00O0oo + Ooooo * I1Ii % IiII
i1I1i1 = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( i1I1i1 ) == False :
 os . mkdir ( i1I1i1 )
oOoO0o00OO0 = os . path . join ( i1I1i1 , 'cid' )
i111I = os . path . join ( i1I1i1 , 'search.p' )
if 81 - 81: i1iIIIiI1I - i1 - IIIiiIIii / Ooooo - OOooo000oo0 * Iiii
if os . path . exists ( oOoO0o00OO0 ) == False :
 with open ( oOoO0o00OO0 , "w" ) as II1Ii1iI1i :
  II1Ii1iI1i . write ( str ( uuid . uuid1 ( ) ) )
  if 20 - 20: i1IIi11111i % O0O0O0O00OooO
if __name__ == '__main__' :
 oo000 . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
