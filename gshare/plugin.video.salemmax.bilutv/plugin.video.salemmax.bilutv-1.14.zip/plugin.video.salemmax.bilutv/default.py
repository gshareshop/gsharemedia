#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , base64 , urlresolver , cfscrape , kodi4vn
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = 24
IIi1IiiiI1Ii = "plugin://plugin.video.salemmax.bilutv"
I11i11Ii = IIi1IiiiI1Ii . split ( "/" ) [ - 1 ]
oO00oOo = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
OOOo0 = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
Oooo000o = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img[^>]*src="(.+?)"[^>]*/>.*?<div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.*?)</p></div></a></li>'
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*>.*?<div class="title"><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
if 54 - 54: IIIiiIIii / o0oo0oo0OO00 . iI111iI / oOOo + I1Ii111
if 93 - 93: iiI1i1 . II1ii1II1iII1 + oO0o . oOOOO0o0o . o0oO0 + oo00
o00 = {
 'Referer' : 'http://tvhay.org/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * o0oOoO00o % o0oOoO00o
if 22 - 22: oo00 . o0oOoO00o
@ OO0o . route ( '/' )
def I11 ( ) :
 xbmc . executebuiltin ( "ShowPicture({})" . format ( OOOo0 ) )
 if 98 - 98: i11iIiiIii * o0oo0oo0OO00 % II1ii * II1ii * IIIiiIIii
@ OO0o . route ( '/search' )
def o0o0Oo0oooo0 ( ) :
 oO0O0o0o0 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if oO0O0o0o0 :
  i1iIIII = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( oO0O0o0o0 ) + '&p=%s'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as I1 :
   I1 . write ( oO0O0o0o0 + "\n" )
  O0OoOoo00o = {
 "title" : "Search: {}" . format ( oO0O0o0o0 ) ,
 "url" : i1iIIII ,
 "page" : 1
 }
  iiiI11 = '{}/list_media/{}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OO0o . redirect ( iiiI11 )
  if 91 - 91: iiI1i1 / IIIiiIIii . II1ii1II1iII1 + oOOOO0o0o
@ OO0o . route ( '/searchlist' )
def iI11 ( ) :
 iII111ii = [ ]
 i1iIIi1 = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{}/search" . format ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 ii11iIi1I = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as I1 :
   ii11iIi1I = I1 . read ( ) . strip ( ) . split ( "\n" )
  for iI111I11I1I1 in reversed ( ii11iIi1I ) :
   i1iIIII = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( iI111I11I1I1 ) + '&p=%s'
   O0OoOoo00o = {
 "title" : "Search: {}" . format ( iI111I11I1I1 ) ,
 "url" : i1iIIII ,
 "page" : 1
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = iI111I11I1I1
   OOooO0OOoo [ "path" ] = "{}/list_media/{}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   iII111ii . append ( OOooO0OOoo )
 iII111ii = i1iIIi1 + iII111ii
 OO0o . set_content ( "files" )
 return OO0o . finish ( iII111ii )
 if 29 - 29: iiI1i1 / IIii1I
@ OO0o . route ( '/list_media/<args_json>' )
def IiIIIiI1I1 ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MEDIA , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] % OoO000 [ "page" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 if "Search: " in OoO000 [ "title" ] :
  kodi4vn . Log ( "Search page detected." )
  ooOoo0O = re . compile ( IiIi11iIIi1Ii ) . findall ( iiIiIIi )
 else :
  ooOoo0O = re . compile ( Oooo000o ) . findall ( iiIiIIi )
 for OooO0 , II11iiii1Ii , OO0oOoo , O0o0Oo , Oo00OOOOO , O0O in ooOoo0O :
  II11iiii1Ii = re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) . strip ( )
  if "://" not in O0o0Oo :
   O0o0Oo = "http://bilutv.com/" + O0o0Oo
  i1iIIII = "http://bilutv.com/xem-phim/phim---{}" . format ( OO0oOoo )
  O00o0OO = u"{} - {} ({} {})" . format ( Oo00OOOOO , O0O , OooO0 , re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) )
  O0OoOoo00o = {
 "title" : O00o0OO ,
 "quality_label" : II11iiii1Ii ,
 "url" : i1iIIII
 }
  OOooO0OOoo = { }
  OOooO0OOoo [ "label" ] = O00o0OO
  OOooO0OOoo [ "path" ] = "{}/list_mirrors/{}" . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
  OOooO0OOoo [ "thumbnail" ] = O0o0Oo
  if "HD" in OooO0 :
   OOooO0OOoo [ "label" ] = "[COLOR yellow]{}[/COLOR]" . format ( OOooO0OOoo [ "label" ] )
  iII111ii . append ( OOooO0OOoo )
 if len ( iII111ii ) == I1IiiI :
  I11i1 = int ( OoO000 [ "page" ] ) + 1
  OoO000 [ "page" ] = I11i1
  iII111ii . append ( {
 'label' : 'Next >>' ,
 'path' : '{}/list_media/{}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OoO000 ) )
 ) ,
 'thumbnail' : oO00oOo
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( iII111ii )
 if 25 - 25: iI111iI - o0oOoO00o . II1
 if 22 - 22: o0oOoO00o + IIIiiIIii % iIi1IIii11I . o0oO0 . I1Ii111
@ OO0o . route ( '/list_mirrors/<args_json>' )
def OO0oo0oOO ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_MIRROR , OoO000 )
 O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : OoO000 [ "url" ]
 }
 oo0oooooO0 = '{}/list_eps/{}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
 OO0o . set_content ( "files" )
 OO0o . redirect ( oo0oooooO0 )
 if 19 - 19: o0oO0 + oo0
@ OO0o . route ( '/list_eps/<args_json>' )
def ooo ( args_json = { } ) :
 iII111ii = [ ]
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_EPS , OoO000 )
 IIiiIiI1 = kodi4vn . Request ( OoO000 [ "url" ] , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text ) . encode ( "utf8" )
 ii1I1i1I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiIiIIi )
 if len ( ii1I1i1I ) > 0 :
  for OOoo0O0 , iiiIi1i1I in ii1I1i1I :
   if "_HD2" not in OOoo0O0 :
    OOoo0O0 = OOoo0O0 . replace ( ".html" , "_HD2.html" )
   oOO00oOO = "http://bilutv.com/xem-phim/phim---{}" . format ( OOoo0O0 )
   O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : oOO00oOO ,
 "eps" : iiiIi1i1I
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = u"Part {} - {} ({}) [{}]" . format (
 iiiIi1i1I . decode ( "utf8" ) ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
   OOooO0OOoo [ "label" ]
   OOooO0OOoo [ "path" ] = '{}/play/{}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "is_playable" ] = True
   iII111ii . append ( OOooO0OOoo )
 else :
  try :
   O0OoOoo00o = {
 "title" : OoO000 [ "title" ] ,
 "quality_label" : OoO000 [ "quality_label" ] ,
 "mirror" : OoO000 [ "mirror" ] ,
 "url" : OoO000 [ "url" ] ,
 "eps" : "Full"
 }
   OOooO0OOoo = { }
   OOooO0OOoo [ "label" ] = "Part {} - {} ({}) [{}]" . format (
 "Full" ,
 OoO000 [ "title" ] ,
 OoO000 [ "quality_label" ] ,
 OoO000 [ "mirror" ]
 )
   OOooO0OOoo [ "path" ] = '{}/play/{}' . format (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoOoo00o ) )
 )
   OOooO0OOoo [ "is_playable" ] = True
   iII111ii . append ( OOooO0OOoo )
  except :
   pass
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( iII111ii )
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / I1Ii111 . IIIiiIIii - O00ooooo00
@ OO0o . route ( '/play/<args_json>' )
def O000OO0 ( args_json = { } ) :
 OoO000 = json . loads ( args_json )
 kodi4vn . GA ( I11i11Ii , kodi4vn . GA_PLAY , OoO000 )
 OO0o . set_resolved_url ( I11iii1Ii ( OoO000 [ "url" ] ) )
 if 13 - 13: iIi1IIii11I % I1Ii111 - i11iIiiIii . o0oo0oo0OO00 + IIIiiIIii
def I11iii1Ii ( url ) :
 IIiiIiI1 = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
 iiIiIIi = kodi4vn . cleanHTML ( IIiiIiI1 . text )
 II111ii1II1i = None
 ooOoo0O = re . compile ( 'playerSetting = (\{.+?\})\;' ) . findall ( iiIiIIi )
 OoOo00o = re . search ( '"(/ajax/getLinkPlayer/id/.+?)"' , iiIiIIi ) . group ( 1 )
 o0OOoo0OO0OOO = json . loads ( ooOoo0O [ 0 ] )
 iI1iI1I1i1I = "bilutv.com4590481877" + o0OOoo0OO0OOO [ "modelId" ]
 iIi11Ii1 = [ "sourceLinks" , "sourceLinksBk" , "sourcesVs" , "sourcesTm" ]
 if 50 - 50: IIIiiIIii - oo0 * II1ii1II1iII1 / iIi1IIii11I + iiI1i1
 def O0O0O ( url ) :
  IIiiIiI1 = kodi4vn . Request ( url , session = Oo0Ooo , mobile = True )
  return IIiiIiI1 . json ( )
  if 83 - 83: II1ii1II1iII1 / oo0
 OoOo00o = "http://bilutv.com" + OoOo00o + "%s"
 iIIIIii1 = [ ( OoOo00o % oo000OO00Oo ) for oo000OO00Oo in range ( 15 ) ]
 if 51 - 51: o0oOoO00o * iiI1i1 + o0oO0 + oOOo
 with concurrent . futures . ThreadPoolExecutor ( max_workers = 4 ) as o0O0O00 :
  for o000o in o0O0O00 . map ( O0O0O , iIIIIii1 ) :
   o0OOoo0OO0OOO [ "sourceLinks" ] += o000o [ "sourceLinks" ]
   if 7 - 7: oo0 * oOOo % oO0o . o0oOoO00o
 ooOoo0O = re . compile ( '"file": "(.+?)"' ) . findall ( json . dumps ( o0OOoo0OO0OOO [ "sourceLinks" ] ) )
 ooOoo0O = [ kodi4vn . gibberishAES ( Ii1iIiII1ii1 , iI1iI1I1i1I ) for Ii1iIiII1ii1 in ooOoo0O ]
 ooOoo0O = set ( ooOoo0O )
 ooOoo0O = list ( ooOoo0O )
 ooOoo0O = sorted ( ooOoo0O )
 for I1 in ooOoo0O :
  try :
   if re . search ( 'api.bilutv.com/\w+/play.php' , I1 ) :
    ooOooo000oOO = "|Referer=" + urllib . quote_plus ( url )
    return I1 + ooOooo000oOO
   if "api.bilutv.com" in I1 :
    IIiiIiI1 = kodi4vn . Request ( I1 , session = Oo0Ooo , mobile = True )
    Oo0oOOo = IIiiIiI1 . json ( )
    for Ii1iIiII1ii1 in Oo0oOOo :
     Ii1iIiII1ii1 [ "label" ] = int ( Ii1iIiII1ii1 [ "label" ] . replace ( "p" , "" ) )
     sorted ( Oo0oOOo , key = itemgetter ( 'label' ) )
    I1 = Oo0oOOo [ - 1 ] [ "file" ]
    Oo0OoO00oOO0o = requests . head ( I1 , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    if "http" in I1 and Oo0OoO00oOO0o < 400 :
     return I1 + "|Referer=" + urllib . quote_plus ( url )
   else :
    Oo0OoO00oOO0o = requests . head ( I1 , headers = { "Referer" : url } , allow_redirects = True ) . status_code
    if "http" in I1 and Oo0OoO00oOO0o < 400 :
     return kodi4vn . resolve ( I1 )
  except : pass
 return None
 if 80 - 80: oO0o + oOOOO0o0o - oOOOO0o0o % II1ii
 if 63 - 63: o0oo0oo0OO00 - II1ii1II1iII1 + OOO0O0O0ooooo % o0oO0 / IIii1I / iiI1i1
if __name__ == '__main__' :
 OO0o . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
