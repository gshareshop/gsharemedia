#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , requests , re , os , json , uuid , base64
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
from operator import itemgetter
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "plugin://plugin.video.salemmax.bilutv"
I11i11Ii = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
oO00oOo = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
OOOo0 = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.75 Safari/537.36"
Oooo000o = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0_2 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12A366 Safari/600.1.4"
IiIi11iIIi1Ii = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a href=".+?-(\d+).html"[^>]*><img src="(.+?)"[^>]*/><div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
Oo0O = '<li class="film-item.+?"><label class="current-status">(.+?)</label>(.*?)<a[^>]*href=".+?-(\d+).html"[^>]*><img[^>]*data-original="(.+?)"[^>]*><div[^>]*><p[^>]*>(.*?)</p><p[^>]*>(.+?)</p></div></a></li>'
IiI = '<a class="watch_button now" href="(.+?)">Xem phim</a>'
ooOo = '<li><a href="(/xem-phim/.+?)">(.+?)</a></li>'
Oo = '&file=/xml.php\?id=(\d+)'
o0O = '<div class="list_episodes content">.*?<td[^>]*class="name">%s</td><td valign="top" class="ep">(.+?)</td></tr>'
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = 24
if 9 - 9: o0o - OOO0o0o
@ oo000 . route ( '/' )
def Ii1iI ( ) :
 xbmc . executebuiltin ( "ShowPicture(%s)" % oO00oOo )
 if 100 - 100: i11Ii11I1Ii1i . ooO - OOoO / ooo0Oo0 * i1 - OOooo0000ooo
@ oo000 . route ( '/search' )
def OOo000 ( ) :
 O0 = oo000 . keyboard ( heading = 'Tìm kiếm' )
 if O0 :
  I11i1i11i1I = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( O0 ) + '&p=%s'
  with open ( oOOo , "a" ) as Iiii :
   Iiii . write ( O0 + "\n" )
  OOO0O = {
 "title" : "Search: %s" % O0 ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
  oo0ooO0oOOOOo = '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  oo000 . redirect ( oo0ooO0oOOOOo )
  if 71 - 71: O00OoOoo00
@ oo000 . route ( '/searchlist' )
def iIiiI1 ( ) :
 OoOooOOOO (
 '[Search List]' ,
 '/searchlist/'
 )
 i11iiII = [ ]
 I1iiiiI1iII = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "%s/search" % ( IIi1IiiiI1Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 IiIi11i = [ ]
 if os . path . exists ( oOOo ) :
  with open ( oOOo , "r" ) as Iiii :
   IiIi11i = Iiii . read ( ) . strip ( ) . split ( "\n" )
  for iIii1I111I11I in reversed ( IiIi11i ) :
   I11i1i11i1I = 'http://bilutv.com/tim-kiem.html?q=' + urllib . quote_plus ( iIii1I111I11I ) + '&p=%s'
   OOO0O = {
 "title" : "Search: %s" % iIii1I111I11I ,
 "url" : I11i1i11i1I ,
 "page" : 1
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = iIii1I111I11I
   OO00OooO0OO [ "path" ] = "%s/list_media/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   i11iiII . append ( OO00OooO0OO )
 i11iiII = I1iiiiI1iII + i11iiII
 return oo000 . finish ( i11iiII )
 if 28 - 28: iIii1
@ oo000 . route ( '/list_media/<args_json>' )
def oOOoO0 ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Media of] %s - Page %s" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1"
 ) ,
 '/list_media/%s/%s' % (
 O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] if "page" in O0OoO000O0OO else "1" ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] % O0OoO000O0OO [ "page" ] )
 if "Search: " in O0OoO000O0OO [ "title" ] :
  ooOoOoo0O = re . compile ( Oo0O ) . findall ( iiI1IiI )
 else :
  ooOoOoo0O = re . compile ( IiIi11iIIi1Ii ) . findall ( iiI1IiI )
 for OooO0 , II11iiii1Ii , OO0o , Ooo , O0o0Oo , Oo00OOOOO in ooOoOoo0O :
  II11iiii1Ii = re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) . strip ( )
  if "://" not in Ooo :
   Ooo = "http://bilutv.com/" + Ooo
  I11i1i11i1I = "http://bilutv.com/xem-phim/phim---%s" % OO0o
  O0O = "%s - %s (%s %s)" % ( O0o0Oo , Oo00OOOOO , OooO0 , re . sub ( '<[^>]*>' , '' , II11iiii1Ii ) )
  OOO0O = {
 "title" : O0O ,
 "quality_label" : II11iiii1Ii ,
 "url" : I11i1i11i1I
 }
  OO00OooO0OO = { }
  OO00OooO0OO [ "label" ] = O0O
  OO00OooO0OO [ "path" ] = "%s/list_mirrors/%s" % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
  OO00OooO0OO [ "thumbnail" ] = Ooo
  if "HD" in OooO0 :
   OO00OooO0OO [ "label" ] = "[COLOR yellow]%s[/COLOR]" % OO00OooO0OO [ "label" ]
  i11iiII . append ( OO00OooO0OO )
 if len ( i11iiII ) == O0oOO0o0 :
  O00o0OO = int ( O0OoO000O0OO [ "page" ] ) + 1
  O0OoO000O0OO [ "page" ] = O00o0OO
  i11iiII . append ( {
 'label' : 'Next >>' ,
 'path' : '%s/list_media/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( O0OoO000O0OO ) )
 ) ,
 'thumbnail' : I11i11Ii
 } )
 return oo000 . finish ( i11iiII )
 if 44 - 44: OOooo0000ooo / OO0OO0O0O0 % I1IiiI * i11Ii11I1Ii1i + I1Ii111
@ oo000 . route ( '/list_mirrors/<args_json>' )
def Ii1I ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Mirrors of] %s (%s)" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : "Default server" ,
 "url" : O0OoO000O0OO [ "url" ]
 }
 Oo0o0 = '%s/list_eps/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
 oo000 . redirect ( Oo0o0 )
 return oo000 . finish ( i11iiII )
 if 49 - 49: i11Ii11I1Ii1i % ooo0Oo0 + I1IiiI . IiII % OOO0o0o
@ oo000 . route ( '/list_eps/<args_json>' )
def I1i1iii ( args_json = { } ) :
 i11iiII = [ ]
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Browse Episodes of] %s (%s) [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/list_mirrors/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 iiI1IiI = II ( O0OoO000O0OO [ "url" ] )
 i1iiI11I = re . compile ( '-(\d+_e\d+.*?.html)">(.+?)</a>' ) . findall ( iiI1IiI )
 if len ( i1iiI11I ) > 0 :
  for iiii , oO0o0O0OOOoo0 in i1iiI11I :
   if "_HD2" not in iiii :
    iiii = iiii . replace ( ".html" , "_HD2.html" )
   IiIiiI = "http://bilutv.com/xem-phim/phim---%s" % iiii
   OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : O0OoO000O0OO [ "mirror" ] ,
 "url" : IiIiiI ,
 "eps" : oO0o0O0OOOoo0
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part %s - %s (%s) [%s]" % (
 oO0o0O0OOOoo0 . decode ( "utf8" ) ,
 O0OoO000O0OO [ "title" ] ,
 O0OoO000O0OO [ "quality_label" ] ,
 O0OoO000O0OO [ "mirror" ]
 )
   OO00OooO0OO [ "label" ]
   OO00OooO0OO [ "path" ] = '%s/play/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
 else :
  try :
   OOO0O = {
 "title" : O0OoO000O0OO [ "title" ] ,
 "quality_label" : O0OoO000O0OO [ "quality_label" ] ,
 "mirror" : O0OoO000O0OO [ "mirror" ] ,
 "url" : O0OoO000O0OO [ "url" ] ,
 "eps" : "Full"
 }
   OO00OooO0OO = { }
   OO00OooO0OO [ "label" ] = "Part %s - %s (%s) [%s]" % (
 "Full" ,
 O0OoO000O0OO [ "title" ] ,
 O0OoO000O0OO [ "quality_label" ] ,
 O0OoO000O0OO [ "mirror" ]
 )
   OO00OooO0OO [ "path" ] = '%s/play/%s' % (
 IIi1IiiiI1Ii ,
 urllib . quote_plus ( json . dumps ( OOO0O ) )
 )
   OO00OooO0OO [ "is_playable" ] = True
   i11iiII . append ( OO00OooO0OO )
  except :
   pass
 return oo000 . finish ( i11iiII )
 if 31 - 31: ooo0Oo0 . ooo0Oo0 - o0o / ooOoO0o + iIii1 * IiII
@ oo000 . route ( '/play/<args_json>' )
def O0ooOooooO ( args_json = { } ) :
 O0OoO000O0OO = json . loads ( args_json )
 OoOooOOOO (
 "[Play] %s (%s) - Part %s [%s]" % (
 O0OoO000O0OO [ "title" ] if "title" in O0OoO000O0OO else "Unknow Title" ,
 O0OoO000O0OO [ "quality_label" ] if "quality_label" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "eps" ] if "eps" in O0OoO000O0OO else "" ,
 O0OoO000O0OO [ "mirror" ] if "mirror" in O0OoO000O0OO else ""
 ) ,
 '/play/%s/%s' % (
 O0OoO000O0OO [ "url" ] ,
 json . dumps ( O0OoO000O0OO [ "payloads" ] ) if "payloads" in O0OoO000O0OO else "{}"
 )
 )
 o00O = xbmcgui . DialogProgress ( )
 o00O . create ( 'bilutv' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( OOO0OOO00oo ( O0OoO000O0OO [ "url" ] ) )
 o00O . close ( )
 del o00O
 if 31 - 31: iII111i - ooO . O00OoOoo00 % o00O0oo - OO0OO0O0O0
def OOO0OOO00oo ( url ) :
 iiI1IiI = II ( url )
 iii11 = None
 ooOoOoo0O = re . compile ( 'playerSetting = (\{.+?\})\;' ) . findall ( iiI1IiI )
 O0oo0OO0oOOOo = json . loads ( ooOoOoo0O [ 0 ] )
 i1i1i11IIi = "bilutv.com4590481877" + O0oo0OO0oOOOo [ "modelId" ]
 II1III = [ "sourcesVs" , "sourcesTm" ]
 for iI1iI1I1i1I in II1III :
  if iI1iI1I1i1I in O0oo0OO0oOOOo :
   for iIi11Ii1 in O0oo0OO0oOOOo [ iI1iI1I1i1I ] :
    for Ii11iII1 in iIi11Ii1 [ "links" ] :
     try :
      Iiii = Oo0O0O0ooO0O ( Ii11iII1 [ "file" ] , i1i1i11IIi )
      if Ii11iII1 [ "type" ] != "mp4" and iIi11Ii1 [ "server" ] == "gd" :
       return IIIIii ( Iiii . replace ( "/preview" , "/view" ) , oo000 . get_setting ( 'HQ' , bool ) )
     except : pass
   for iIi11Ii1 in O0oo0OO0oOOOo [ iI1iI1I1i1I ] :
    for Ii11iII1 in iIi11Ii1 [ "links" ] :
     Iiii = Oo0O0O0ooO0O ( Ii11iII1 [ "file" ] , i1i1i11IIi )
     if Ii11iII1 [ "type" ] == "mp4" :
      return Iiii
      if 70 - 70: ooo0Oo0 / OOoO . i1 % I1Ii111
      if 67 - 67: o00O0oo * o0o . OOooo0000ooo - ooOoO0o * o0o
 return iii11
 if 46 - 46: ooO + o00O0oo . IiII * i11Ii11I1Ii1i % OOooo0000ooo
 if 86 - 86: IiII + ooo0Oo0 % Oo0Ooo * i11Ii11I1Ii1i . iIii1 * OOoO
def II ( url , data = { } ) :
 i1I11i1iI = {
 'User-Agent' : OOOo0 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 'Content-Type' : 'text/html; charset=utf-8' ,
 }
 if data == { } :
  I1ii1Ii1 = requests . get (
 url ,
 headers = i1I11i1iI )
 else :
  i1I11i1iI [ "Content-Type" ] = "application/x-www-form-urlencoded"
  I1ii1Ii1 = requests . post (
 url ,
 headers = i1I11i1iI ,
 data = data )
  return I1ii1Ii1 . json ( )
 I1ii1Ii1 . encoding = "utf-8"
 iiI1IiI = iii11oOOOOo0 ( I1ii1Ii1 . text . encode ( "utf8" ) )
 return iiI1IiI
 if 20 - 20: I1IiiI + OOO0o0o - iIii1
def IIIIii ( url , hq ) :
 if 30 - 30: iII111i - ooO - Oo0Ooo % o00O0oo - iII111i * ooo0Oo0
 i1I11i1iI = {
 'User-Agent' : OOOo0 ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 I1ii1Ii1 = requests . get ( url , headers = i1I11i1iI )
 oO00O0O0O = re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( I1ii1Ii1 . text ) [ 0 ]
 i1ii1iiI = [ "38" , "37" , "46" , "22" , "45" , "18" , "43" ]
 if not hq : i1ii1iiI . reverse ( )
 O0o0O00Oo0o0 = json . loads ( oO00O0O0O ) [ 1 ] . split ( "," )
 for O00O0oOO00O00 in i1ii1iiI :
  for i1Oo00 in O0o0O00Oo0o0 :
   if i1Oo00 . startswith ( O00O0oOO00O00 + "|" ) :
    url = i1Oo00 . split ( "|" ) [ 1 ]
    i1i = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( OOOo0 ) , urllib . quote ( I1ii1Ii1 . headers [ 'set-cookie' ] ) )
    return url + i1i
    if 50 - 50: OOooo0000ooo
def i11I1iIiII ( url , data = { } ) :
 i1I11i1iI = {
 'User-Agent' : Oooo000o ,
 'Accept-Encoding' : 'gzip, deflate, sdch' ,
 }
 if data == { } :
  I1ii1Ii1 = requests . get (
 url ,
 headers = i1I11i1iI )
 else :
  i1I11i1iI [ "Content-Type" ] = "application/x-www-form-urlencoded"
  I1ii1Ii1 = requests . post (
 url ,
 headers = i1I11i1iI ,
 data = data )
 I1ii1Ii1 . encoding = "utf-8"
 iiI1IiI = iii11oOOOOo0 ( I1ii1Ii1 . text . encode ( "utf8" ) )
 return iiI1IiI
 if 96 - 96: I1Ii111
def iii11oOOOOo0 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return s
 if 45 - 45: OO0OO0O0O0 * o0o % I1Ii111 * iII111iiiii11 + i1 . o00O0oo
def Oo0ooOo0o ( s ) :
 O00O0oOO00O00 = re . compile ( r'<.*?>' , re . IGNORECASE )
 s = re . sub ( O00O0oOO00O00 , '' , s )
 return s . strip ( )
 if 22 - 22: iiiIIii1IIi / Oo0Ooo * iiiIIii1IIi * iII111i . ooO / Oo0Ooo
def OoOooOOOO ( title = "Home" , page = "/" ) :
 try :
  IiiiOO0OoO0o00 = "http://www.google-analytics.com/collect"
  ooOO0O0ooOooO = open ( oOOOo00O00oOo ) . read ( )
  iiIIIi = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : ooOO0O0ooOooO ,
 't' : 'pageview' ,
 'dp' : "BiluTV%s" % page ,
 'dt' : "[BiluTV] - %s" % title . encode ( "utf8" )
 }
  requests . post ( IiiiOO0OoO0o00 , data = urllib . urlencode ( iiIIIi ) )
 except :
  pass
  if 93 - 93: i1
def i1IIIiiII1 ( pattern , string , group = 1 , flags = 0 , result = '' ) :
 try : iiI1IiI = re . search ( pattern , string , flags ) . group ( group )
 except : iiI1IiI = result
 return iiI1IiI
 if 87 - 87: i11Ii11I1Ii1i * OOO0o0o + ooO / iiiIIii1IIi / i1
def Oo0O0O0ooO0O ( string , key = '' ) :
 import ctypes
 def I1111IIi ( l , s = 4 ) :
  Oo0oO = [ ]
  for IIiIi1iI in range ( 0 , len ( l ) , s ) : Oo0oO . append ( ( l [ IIiIi1iI : IIiIi1iI + s ] ) )
  return Oo0oO
  if 35 - 35: ooo0Oo0 % OO0OO0O0O0 - OO0OO0O0O0
 def IiIIIi1iIi ( v ) : return ctypes . c_int ( v ) . value
 def ooOOoooooo ( val , n ) : return ( val % 0x100000000 ) >> n
 if 1 - 1: I1Ii111 / o0o % i1 * OOooo0000ooo . Oo0Ooo
 III1Iiii1I11 = 14
 IIII = 8
 iiIiI = False
 if 91 - 91: i1 % I1IiiI % iiiIIii1IIi
 def Iiii ( e ) :
  if 20 - 20: ooO % ooo0Oo0 / ooo0Oo0 + ooo0Oo0
  if 45 - 45: i11Ii11I1Ii1i - OOooo0000ooo - iII111iiiii11 - ooOoO0o . iII111i / OO0OO0O0O0
  return str ( e )
  if 51 - 51: OO0OO0O0O0 + i1
 def IIIII11I1IiI ( e ) :
  if 16 - 16: iiiIIii1IIi
  if 90 - 90: o0o % I1IiiI / ooOoO0o
  return str ( e )
  if 44 - 44: I1Ii111 . ooOoO0o / OOO0o0o + ooo0Oo0
 def o0oO0OOoO00OO0o ( e ) :
  Iiii = [ 0 ] * len ( e )
  if 16 > len ( e ) :
   IIII = 16 - len ( e )
   Iiii = [ IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII , IIII ]
  for iiIiI in range ( len ( e ) ) : Iiii [ iiIiI ] = e [ iiIiI ]
  return Iiii
  if 38 - 38: ooO % OOoO % o0o % ooOoO0o - I1Ii111
 def i1Ii ( e ) :
  iiIiI = ""
  for IIII in len ( e ) : iiIiI += ( "0" if 16 > e [ IIII ] else "" ) + format ( e [ IIII ] , 'x' )
  return iiIiI
  if 14 - 14: i1
 def I1iI1iIi111i ( e , r ) :
  IIIII11I1IiI = [ ]
  if not r : e = Iiii ( e )
  for iiIiI in range ( len ( e ) ) : IIIII11I1IiI . append ( ord ( e [ iiIiI ] ) )
  return IIIII11I1IiI
  if 44 - 44: I1IiiI % iII111i + OOoO
 def IIiIi1iI ( n ) :
  if n == 128 : III1Iiii1I11 = 10 ; IIII = 4
  elif n == 192 : III1Iiii1I11 = 12 ; IIII = 6
  elif n == 256 : III1Iiii1I11 = 14 ; IIII = 8
  if 45 - 45: i1 / i1 + O00OoOoo00 + iIii1
 def iI111i ( e ) :
  iiIiI = [ ]
  for IIII in range ( e ) : iiIiI . append ( 256 )
  return iiIiI
  if 26 - 26: OOO0o0o * i1 . iII111i * ooo0Oo0
 def II1 ( n , f ) :
  iiiIi1 = [ ] ; o0oO0OOoO00OO0o = 3 if III1Iiii1I11 >= 12 else 2 ; IIiIi1iI = n + f ; iiiIi1 . append ( i1I1ii11i1Iii ( IIiIi1iI ) ) ; I1iI1iIi111i = [ IIIII11I1IiI for IIIII11I1IiI in iiiIi1 [ 0 ] ]
  for IIIII11I1IiI in range ( 1 , o0oO0OOoO00OO0o ) : iiiIi1 . append ( i1I1ii11i1Iii ( iiiIi1 [ IIIII11I1IiI - 1 ] + IIiIi1iI ) ) ; I1iI1iIi111i += iiiIi1 [ IIIII11I1IiI ]
  return { 'key' : I1iI1iIi111i [ 0 : 4 * IIII ] , 'iv' : I1iI1iIi111i [ 4 * IIII : 4 * IIII + 16 ] }
  if 26 - 26: OOoO - iiiIIii1IIi - IiII / ooOoO0o . o00O0oo % iiiIIii1IIi
 def OO ( e , r = False ) :
  IIIII11I1IiI = ""
  if ( r ) :
   iiIiI = e [ 15 ]
   if 25 - 25: ooOoO0o
   if 16 != iiIiI :
    for Iiii in range ( 16 - iiIiI ) : IIIII11I1IiI += chr ( e [ Iiii ] )
  else :
   for Iiii in range ( 16 ) : IIIII11I1IiI += chr ( e [ Iiii ] )
  return IIIII11I1IiI
  if 62 - 62: ooO + OO0OO0O0O0
 def Oo0oO ( e , r = False ) :
  if not r : IIIII11I1IiI = '' . join ( chr ( e [ f ] ) for f in range ( 16 ) )
  elif 16 != e [ 15 ] : IIIII11I1IiI = '' . join ( chr ( e [ f ] ) for f in range ( 16 - e [ 15 ] ) )
  else : IIIII11I1IiI = ''
  return IIIII11I1IiI
  if 98 - 98: o0o
 def OOOO0oo0 ( e , r , n , f = '' ) :
  r = I11iiI1i1 ( r ) ; i1Ii = len ( e ) / 16 ; I1iI1iIi111i = [ 0 ] * i1Ii
  iiiIi1 = [ e [ 16 * o0oO0OOoO00OO0o : 16 * ( o0oO0OOoO00OO0o + 1 ) ] for o0oO0OOoO00OO0o in range ( i1Ii ) ]
  for o0oO0OOoO00OO0o in range ( len ( iiiIi1 ) - 1 , - 1 , - 1 ) :
   I1iI1iIi111i [ o0oO0OOoO00OO0o ] = I1i1Iiiii ( iiiIi1 [ o0oO0OOoO00OO0o ] , r )
   I1iI1iIi111i [ o0oO0OOoO00OO0o ] = OOo0oO00ooO00 ( I1iI1iIi111i [ o0oO0OOoO00OO0o ] , n ) if 0 == o0oO0OOoO00OO0o else OOo0oO00ooO00 ( I1iI1iIi111i [ o0oO0OOoO00OO0o ] , iiiIi1 [ o0oO0OOoO00OO0o - 1 ] )
   if 90 - 90: o00O0oo * O00OoOoo00 + o0o
  IIiIi1iI = '' . join ( Oo0oO ( I1iI1iIi111i [ o0oO0OOoO00OO0o ] ) for o0oO0OOoO00OO0o in range ( i1Ii - 1 ) )
  IIiIi1iI += Oo0oO ( I1iI1iIi111i [ i1Ii - 1 ] , True )
  return IIiIi1iI if f else IIIII11I1IiI ( IIiIi1iI )
  if 81 - 81: i11Ii11I1Ii1i . o0o % OO0OO0O0O0 / IiII - i11Ii11I1Ii1i
 def iiI1IiI ( r , f ) :
  iiIiI = False
  o0oO0OOoO00OO0o = Ii1I1i ( r , f , 0 )
  for IIIII11I1IiI in ( 1 , III1Iiii1I11 + 1 , 1 ) :
   o0oO0OOoO00OO0o = OOI1iI1ii1II ( o0oO0OOoO00OO0o )
   o0oO0OOoO00OO0o = O0O0OOOOoo ( o0oO0OOoO00OO0o )
   if III1Iiii1I11 > IIIII11I1IiI : o0oO0OOoO00OO0o = oOooO0 ( o0oO0OOoO00OO0o )
   o0oO0OOoO00OO0o = Ii1I1i ( o0oO0OOoO00OO0o , f , IIIII11I1IiI )
  return o0oO0OOoO00OO0o
  if 29 - 29: iiiIIii1IIi + o00O0oo * ooOoO0o * ooO . IiII * IiII
 def I1i1Iiiii ( r , f ) :
  iiIiI = True
  o0oO0OOoO00OO0o = Ii1I1i ( r , f , III1Iiii1I11 )
  for IIIII11I1IiI in range ( III1Iiii1I11 - 1 , - 1 , - 1 ) :
   o0oO0OOoO00OO0o = O0O0OOOOoo ( o0oO0OOoO00OO0o , iiIiI )
   o0oO0OOoO00OO0o = OOI1iI1ii1II ( o0oO0OOoO00OO0o , iiIiI )
   o0oO0OOoO00OO0o = Ii1I1i ( o0oO0OOoO00OO0o , f , IIIII11I1IiI )
   if IIIII11I1IiI > 0 : o0oO0OOoO00OO0o = oOooO0 ( o0oO0OOoO00OO0o , iiIiI )
  return o0oO0OOoO00OO0o
  if 7 - 7: OOooo0000ooo * O00OoOoo00 % ooo0Oo0 - o0o
 def OOI1iI1ii1II ( e , n = True ) :
  Iiii = i1ioOOoo00O00o if n else O0O00Oo ; IIIII11I1IiI = [ 0 ] * 16
  for IIII in range ( 16 ) : IIIII11I1IiI [ IIII ] = Iiii [ e [ IIII ] ]
  return IIIII11I1IiI
  if 97 - 97: OO0OO0O0O0 * iII111iiiii11 . iII111iiiii11
 def O0O0OOOOoo ( e , n = True ) :
  Iiii = [ ]
  if n : IIIII11I1IiI = [ 0 , 13 , 10 , 7 , 4 , 1 , 14 , 11 , 8 , 5 , 2 , 15 , 12 , 9 , 6 , 3 ]
  else : IIIII11I1IiI = [ 0 , 5 , 10 , 15 , 4 , 9 , 14 , 3 , 8 , 13 , 2 , 7 , 12 , 1 , 6 , 11 ]
  for IIII in range ( 16 ) : Iiii . append ( e [ IIIII11I1IiI [ IIII ] ] )
  return Iiii
  if 33 - 33: O00OoOoo00 + i1 * i11Ii11I1Ii1i / iiiIIii1IIi - IiII
 def oOooO0 ( e , n = True ) :
  Iiii = [ 0 ] * 16
  if ( n ) :
   for IIII in range ( 4 ) :
    Iiii [ 4 * IIII ] = O0oO [ e [ 4 * IIII ] ] ^ OO0ooOOO0OOO [ e [ 1 + 4 * IIII ] ] ^ oO00oooOOoOo0 [ e [ 2 + 4 * IIII ] ] ^ OoOOoOooooOOo [ e [ 3 + 4 * IIII ] ]
    Iiii [ 1 + 4 * IIII ] = OoOOoOooooOOo [ e [ 4 * IIII ] ] ^ O0oO [ e [ 1 + 4 * IIII ] ] ^ OO0ooOOO0OOO [ e [ 2 + 4 * IIII ] ] ^ oO00oooOOoOo0 [ e [ 3 + 4 * IIII ] ]
    Iiii [ 2 + 4 * IIII ] = oO00oooOOoOo0 [ e [ 4 * IIII ] ] ^ OoOOoOooooOOo [ e [ 1 + 4 * IIII ] ] ^ O0oO [ e [ 2 + 4 * IIII ] ] ^ OO0ooOOO0OOO [ e [ 3 + 4 * IIII ] ]
    Iiii [ 3 + 4 * IIII ] = OO0ooOOO0OOO [ e [ 4 * IIII ] ] ^ oO00oooOOoOo0 [ e [ 1 + 4 * IIII ] ] ^ OoOOoOooooOOo [ e [ 2 + 4 * IIII ] ] ^ O0oO [ e [ 3 + 4 * IIII ] ]
  else :
   for IIII in range ( 4 ) :
    Iiii [ 4 * IIII ] = oOo0O [ e [ 4 * IIII ] ] ^ oo0O0 [ e [ 1 + 4 * IIII ] ] ^ e [ 2 + 4 * IIII ] ^ e [ 3 + 4 * IIII ]
    Iiii [ 1 + 4 * IIII ] = e [ 4 * IIII ] ^ oOo0O [ e [ 1 + 4 * IIII ] ] ^ oo0O0 [ e [ 2 + 4 * IIII ] ] ^ e [ 3 + 4 * IIII ]
    Iiii [ 2 + 4 * IIII ] = e [ 4 * IIII ] ^ e [ 1 + 4 * IIII ] ^ oOo0O [ e [ 2 + 4 * IIII ] ] ^ oo0O0 [ e [ 3 + 4 * IIII ] ]
    Iiii [ 3 + 4 * IIII ] = oo0O0 [ e [ 4 * IIII ] ] ^ e [ 1 + 4 * IIII ] ^ e [ 2 + 4 * IIII ] ^ oOo0O [ e [ 3 + 4 * IIII ] ]
  return Iiii
  if 22 - 22: o00O0oo . ooO * o00O0oo
 def Ii1I1i ( e , r , n ) :
  IIIII11I1IiI = [ 0 ] * 16
  for Iiii in range ( 16 ) : IIIII11I1IiI [ Iiii ] = e [ Iiii ] ^ r [ n ] [ Iiii ]
  return IIIII11I1IiI
  if 54 - 54: OOooo0000ooo + ooo0Oo0 % ooOoO0o + iII111iiiii11 - OO0OO0O0O0 - o0o
 def OOo0oO00ooO00 ( e , r ) :
  Iiii = [ 0 ] * 16
  for iiIiI in range ( 16 ) : Iiii [ iiIiI ] = e [ iiIiI ] ^ r [ iiIiI ]
  return Iiii
  if 77 - 77: ooO * iiiIIii1IIi
 def I11iiI1i1 ( n ) :
  i1Ii = [ [ n [ 4 * Iiii + IIiIi1iI ] for IIiIi1iI in range ( 4 ) ] for Iiii in range ( IIII ) ]
  if 98 - 98: IiII % ooo0Oo0 * iII111iiiii11
  for Iiii in range ( IIII , 4 * ( III1Iiii1I11 + 1 ) ) :
   iiiIi1 = [ o0oO0OOoO00OO0o for o0oO0OOoO00OO0o in i1Ii [ Iiii - 1 ] ]
   if 0 == Iiii % IIII : iiiIi1 = OoiIIiIi1 ( o0O0o0 ( iiiIi1 ) ) ; iiiIi1 [ 0 ] ^= II111iI111I1I [ Iiii / IIII - 1 ]
   elif IIII > 6 and 4 == Iiii % IIII : iiiIi1 = OoiIIiIi1 ( iiiIi1 )
   i1Ii . append ( [ i1Ii [ Iiii - IIII ] [ o0oO0OOoO00OO0o ] ^ iiiIi1 [ o0oO0OOoO00OO0o ] for o0oO0OOoO00OO0o in range ( 4 ) ] )
   if 18 - 18: i1 - ooO . O00OoOoo00 . iiiIIii1IIi
  I1iI1iIi111i = [ ]
  for Iiii in range ( III1Iiii1I11 + 1 ) :
   I1iI1iIi111i . append ( [ ] )
   for Oo0oO in range ( 4 ) : I1iI1iIi111i [ Iiii ] += i1Ii [ 4 * Iiii + Oo0oO ]
  return I1iI1iIi111i
  if 2 - 2: ooO . ooOoO0o
 def OoiIIiIi1 ( e ) :
  return [ O0O00Oo [ e [ IIII ] ] for IIII in range ( 4 ) ]
  if 78 - 78: OOoO * iiiIIii1IIi . IiII / o0o - iII111iiiii11 / O00OoOoo00
 def o0O0o0 ( e ) :
  e . insert ( 4 , e [ 0 ] )
  e . remove ( e [ 4 ] )
  return e
  if 35 - 35: OOoO % ooO - i11Ii11I1Ii1i
 def ii1iii1i ( e , r ) : return [ int ( e [ iiIiI : iiIiI + r ] , 16 ) for iiIiI in range ( 0 , len ( e ) , r ) ]
 if 35 - 35: iII111i % ooO . iIii1 + iIii1 % iII111i % iII111i
 def ooOoO00 ( e ) :
  iiIiI = [ 0 ] * len ( e )
  for IIII in range ( len ( e ) ) : iiIiI [ e [ IIII ] ] = IIII
  return iiIiI
  if 14 - 14: I1IiiI - o0o % OO0OO0O0O0 - ooOoO0o
 def ooO0O00Oo0o ( e , r ) :
  Iiii = 0
  for iiIiI in range ( 8 ) :
   Iiii = Iiii ^ e if 1 == ( 1 & r ) else Iiii
   e = IiIIIi1iIi ( 283 ^ e << 1 ) if e > 127 else IiIIIi1iIi ( e << 1 )
   r >>= 1
  return Iiii
  if 65 - 65: OOO0o0o . OOoO - O00OoOoo00 * OOooo0000ooo / O00OoOoo00 / iIii1
 def i111iIi1i1II1 ( e ) :
  iiIiI = [ 0 ] * 256
  for IIII in range ( 256 ) : iiIiI [ IIII ] = ooO0O00Oo0o ( e , IIII )
  return iiIiI
  if 86 - 86: iiiIIii1IIi / o00O0oo . iII111i
 O0O00Oo = ii1iii1i ( "637c777bf26b6fc53001672bfed7ab76ca82c97dfa5947f0add4a2af9ca472c0b7fd9326363ff7cc34a5e5f171d8311504c723c31896059a071280e2eb27b27509832c1a1b6e5aa0523bd6b329e32f8453d100ed20fcb15b6acbbe394a4c58cfd0efaafb434d338545f9027f503c9fa851a3408f929d38f5bcb6da2110fff3d2cd0c13ec5f974417c4a77e3d645d197360814fdc222a908846eeb814de5e0bdbe0323a0a4906245cc2d3ac629195e479e7c8376d8dd54ea96c56f4ea657aae08ba78252e1ca6b4c6e8dd741f4bbd8b8a703eb5664803f60e613557b986c11d9ee1f8981169d98e949b1e87e9ce5528df8ca1890dbfe6426841992d0fb054bb16" , 2 )
 i1ioOOoo00O00o = ooOoO00 ( O0O00Oo )
 II111iI111I1I = ii1iii1i ( "01020408102040801b366cd8ab4d9a2f5ebc63c697356ad4b37dfaefc591" , 2 )
 oOo0O = i111iIi1i1II1 ( 2 )
 oo0O0 = i111iIi1i1II1 ( 3 )
 OoOOoOooooOOo = i111iIi1i1II1 ( 9 )
 OO0ooOOO0OOO = i111iIi1i1II1 ( 11 )
 oO00oooOOoOo0 = i111iIi1i1II1 ( 13 )
 O0oO = i111iIi1i1II1 ( 14 )
 if 19 - 19: OOO0o0o % iII111iiiii11 % OOooo0000ooo * o0o % OO0OO0O0O0
 def ooo ( e , r , n = '' ) :
  Iiii = i1i1iI1iiiI ( e )
  IIIII11I1IiI = Iiii [ 8 : 16 ]
  o0oO0OOoO00OO0o = II1 ( I1iI1iIi111i ( r , n ) , IIIII11I1IiI )
  Oo0oO = o0oO0OOoO00OO0o [ 'key' ]
  i1Ii = o0oO0OOoO00OO0o [ 'iv' ]
  Iiii = Iiii [ 16 : len ( Iiii ) ]
  return OOOO0oo0 ( Iiii , Oo0oO , i1Ii , n )
  if 51 - 51: IiII % O00OoOoo00 . i11Ii11I1Ii1i / iiiIIii1IIi / OOoO . i11Ii11I1Ii1i
 def i1i1iI1iiiI ( r ) :
  def IIIii11 ( n ) :
   try : Oo0oO = III1Iiii1I11 . index ( r [ n ] )
   except : Oo0oO = - 1
   return Oo0oO
   if 9 - 9: OO0OO0O0O0 % OO0OO0O0O0 - o0o
  III1Iiii1I11 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
  r = r . replace ( '\n' , '' ) ; Iiii = [ ] ; IIIII11I1IiI = [ 0 ] * 4
  for iiIiI in range ( 0 , len ( r ) , 4 ) :
   for IIiIi1iI in range ( len ( IIIII11I1IiI ) ) : IIIII11I1IiI [ IIiIi1iI ] = IIIii11 ( iiIiI + IIiIi1iI )
   Iiii . append ( IiIIIi1iIi ( IIIII11I1IiI [ 0 ] << 2 | IIIII11I1IiI [ 1 ] >> 4 ) )
   Iiii . append ( IiIIIi1iIi ( ( 15 & IIIII11I1IiI [ 1 ] ) << 4 | IIIII11I1IiI [ 2 ] >> 2 ) )
   Iiii . append ( IiIIIi1iIi ( ( 3 & IIIII11I1IiI [ 2 ] ) << 6 | IIIII11I1IiI [ 3 ] ) )
  return Iiii [ 0 : len ( Iiii ) - len ( Iiii ) % 16 ]
  if 51 - 51: IiII . iiiIIii1IIi - OOO0o0o / OO0OO0O0O0
 def i1I1ii11i1Iii ( e ) :
  def IIII ( e , r ) : return IiIIIi1iIi ( e << r ) | IiIIIi1iIi ( ooOOoooooo ( e , 32 - r ) )
  if 52 - 52: o0o + OO0OO0O0O0 + i1 + I1Ii111 % i1
  def iiIiI ( e , r ) :
   IIIII11I1IiI = 2147483648 & e
   o0oO0OOoO00OO0o = 2147483648 & r
   iiIiI = 1073741824 & e
   Iiii = 1073741824 & r
   Oo0oO = ( 1073741823 & e ) + ( 1073741823 & r )
   IIiIi1iI = 2147483648 ^ Oo0oO ^ IIIII11I1IiI ^ o0oO0OOoO00OO0o
   oO00oooOOoOo0 = 3221225472 ^ Oo0oO ^ IIIII11I1IiI ^ o0oO0OOoO00OO0o
   oOooO0 = 1073741824 ^ Oo0oO ^ IIIII11I1IiI ^ o0oO0OOoO00OO0o
   return IiIIIi1iIi ( IIiIi1iI if iiIiI & Iiii else ( ( oO00oooOOoOo0 if 1073741824 & Oo0oO else oOooO0 ) if iiIiI | Iiii else Oo0oO ^ IIIII11I1IiI ^ o0oO0OOoO00OO0o ) )
   if 75 - 75: IiII . iIii1 . OO0OO0O0O0 * O00OoOoo00
  def Iiii ( e , r , n ) : return IiIIIi1iIi ( e & r ) | IiIIIi1iIi ( ~ e & n )
  if 4 - 4: ooo0Oo0 % i11Ii11I1Ii1i * ooOoO0o
  def IIIII11I1IiI ( e , r , n ) : return IiIIIi1iIi ( e & n ) | IiIIIi1iIi ( r & ~ n )
  if 100 - 100: O00OoOoo00 * ooO + ooO
  def o0oO0OOoO00OO0o ( e , r , n ) : return e ^ r ^ n
  if 54 - 54: iII111iiiii11 + o0o - I1IiiI % Oo0Ooo
  def Oo0oO ( e , r , n ) : return r ^ ( e | ~ n )
  if 3 - 3: o0o % o0o
  def i1Ii ( e , c , t , a , o , d , u ) :
   e = iiIiI ( e , iiIiI ( iiIiI ( Iiii ( c , t , a ) , o ) , u ) )
   return iiIiI ( IIII ( e , d ) , c )
   if 83 - 83: iII111i + O00OoOoo00
  def iiiIi1 ( e , f , t , a , o , d , u ) :
   e = iiIiI ( e , iiIiI ( iiIiI ( IIIII11I1IiI ( f , t , a ) , o ) , u ) )
   return iiIiI ( IIII ( e , d ) , f )
   if 73 - 73: i1
  def I1iI1iIi111i ( e , f , c , a , o , d , u ) :
   e = iiIiI ( e , iiIiI ( iiIiI ( o0oO0OOoO00OO0o ( f , c , a ) , o ) , u ) )
   return iiIiI ( IIII ( e , d ) , f )
   if 42 - 42: Oo0Ooo * iiiIIii1IIi / OOO0o0o . Oo0Ooo % OOoO
  def IIiIi1iI ( e , f , c , t , o , d , u ) :
   e = iiIiI ( e , iiIiI ( iiIiI ( Oo0oO ( f , c , t ) , o ) , u ) )
   return iiIiI ( IIII ( e , d ) , f )
   if 41 - 41: OOooo0000ooo / OO0OO0O0O0
  def iI111i ( e ) :
   iiIiI = len ( e ) ; Iiii = iiIiI + 8 ; IIIII11I1IiI = ( Iiii - Iiii % 64 ) / 64 ; o0oO0OOoO00OO0o = 16 * ( IIIII11I1IiI + 1 ) ; Oo0oO = [ 0 ] * o0oO0OOoO00OO0o ; i1Ii = 0
   for iiiIi1 in range ( iiIiI ) : IIII = ( iiiIi1 - iiiIi1 % 4 ) / 4 ; i1Ii = 8 * ( iiiIi1 % 4 ) ; Oo0oO [ IIII ] = Oo0oO [ IIII ] | IiIIIi1iIi ( e [ iiiIi1 ] << i1Ii )
   iiiIi1 += 1
   IIII = ( iiiIi1 - iiiIi1 % 4 ) / 4
   i1Ii = 8 * ( iiiIi1 % 4 )
   Oo0oO [ IIII ] = Oo0oO [ IIII ] | IiIIIi1iIi ( 128 << i1Ii )
   Oo0oO [ o0oO0OOoO00OO0o - 2 ] = IiIIIi1iIi ( iiIiI << 3 )
   Oo0oO [ o0oO0OOoO00OO0o - 1 ] = IiIIIi1iIi ( ooOOoooooo ( iiIiI , 29 ) )
   return Oo0oO
   if 51 - 51: OOoO % IiII
  def II1 ( e ) :
   Iiii = [ ]
   for iiIiI in range ( 4 ) :
    IIII = IiIIIi1iIi ( 255 & ooOOoooooo ( e , 8 * iiIiI ) )
    Iiii . append ( IIII )
   return Iiii
   if 60 - 60: IiII / ooO . IiII / O00OoOoo00 . OOooo0000ooo
  OoiIIiIi1 = ii1iii1i ( "67452301efcdab8998badcfe10325476d76aa478e8c7b756242070dbc1bdceeef57c0faf4787c62aa8304613fd469501698098d88b44f7afffff5bb1895cd7be6b901122fd987193a679438e49b40821f61e2562c040b340265e5a51e9b6c7aad62f105d02441453d8a1e681e7d3fbc821e1cde6c33707d6f4d50d87455a14eda9e3e905fcefa3f8676f02d98d2a4c8afffa39428771f6816d9d6122fde5380ca4beea444bdecfa9f6bb4b60bebfbc70289b7ec6eaa127fad4ef308504881d05d9d4d039e6db99e51fa27cf8c4ac5665f4292244432aff97ab9423a7fc93a039655b59c38f0ccc92ffeff47d85845dd16fa87e4ffe2ce6e0a30143144e0811a1f7537e82bd3af2352ad7d2bbeb86d391" , 8 )
  I11iiI1i1 = [ ] ; I11iiI1i1 = iI111i ( e ) ; O0O0OOOOoo = OoiIIiIi1 [ 0 ] ; oOooO0 = OoiIIiIi1 [ 1 ] ; Ii1I1i = OoiIIiIi1 [ 2 ] ; OOo0oO00ooO00 = OoiIIiIi1 [ 3 ] ; OO0000o = 0
  for OO0000o in range ( 0 , len ( I11iiI1i1 ) , 16 ) :
   OOOO0oo0 = O0O0OOOOoo
   iiI1IiI = oOooO0
   I1i1Iiiii = Ii1I1i
   OOI1iI1ii1II = OOo0oO00ooO00
   O0O0OOOOoo = i1Ii ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 0 ] , 7 , OoiIIiIi1 [ 4 ] )
   OOo0oO00ooO00 = i1Ii ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 1 ] , 12 , OoiIIiIi1 [ 5 ] )
   Ii1I1i = i1Ii ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 2 ] , 17 , OoiIIiIi1 [ 6 ] )
   oOooO0 = i1Ii ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 3 ] , 22 , OoiIIiIi1 [ 7 ] )
   O0O0OOOOoo = i1Ii ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 4 ] , 7 , OoiIIiIi1 [ 8 ] )
   OOo0oO00ooO00 = i1Ii ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 5 ] , 12 , OoiIIiIi1 [ 9 ] )
   Ii1I1i = i1Ii ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 6 ] , 17 , OoiIIiIi1 [ 10 ] )
   oOooO0 = i1Ii ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 7 ] , 22 , OoiIIiIi1 [ 11 ] )
   O0O0OOOOoo = i1Ii ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 8 ] , 7 , OoiIIiIi1 [ 12 ] )
   OOo0oO00ooO00 = i1Ii ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 9 ] , 12 , OoiIIiIi1 [ 13 ] )
   Ii1I1i = i1Ii ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 10 ] , 17 , OoiIIiIi1 [ 14 ] )
   oOooO0 = i1Ii ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 11 ] , 22 , OoiIIiIi1 [ 15 ] )
   O0O0OOOOoo = i1Ii ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 12 ] , 7 , OoiIIiIi1 [ 16 ] )
   OOo0oO00ooO00 = i1Ii ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 13 ] , 12 , OoiIIiIi1 [ 17 ] )
   Ii1I1i = i1Ii ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 14 ] , 17 , OoiIIiIi1 [ 18 ] )
   oOooO0 = i1Ii ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 15 ] , 22 , OoiIIiIi1 [ 19 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 1 ] , 5 , OoiIIiIi1 [ 20 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 6 ] , 9 , OoiIIiIi1 [ 21 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 11 ] , 14 , OoiIIiIi1 [ 22 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 0 ] , 20 , OoiIIiIi1 [ 23 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 5 ] , 5 , OoiIIiIi1 [ 24 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 10 ] , 9 , OoiIIiIi1 [ 25 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 15 ] , 14 , OoiIIiIi1 [ 26 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 4 ] , 20 , OoiIIiIi1 [ 27 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 9 ] , 5 , OoiIIiIi1 [ 28 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 14 ] , 9 , OoiIIiIi1 [ 29 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 3 ] , 14 , OoiIIiIi1 [ 30 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 8 ] , 20 , OoiIIiIi1 [ 31 ] )
   O0O0OOOOoo = iiiIi1 ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 13 ] , 5 , OoiIIiIi1 [ 32 ] )
   OOo0oO00ooO00 = iiiIi1 ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 2 ] , 9 , OoiIIiIi1 [ 33 ] )
   Ii1I1i = iiiIi1 ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 7 ] , 14 , OoiIIiIi1 [ 34 ] )
   oOooO0 = iiiIi1 ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 12 ] , 20 , OoiIIiIi1 [ 35 ] )
   O0O0OOOOoo = I1iI1iIi111i ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 5 ] , 4 , OoiIIiIi1 [ 36 ] )
   OOo0oO00ooO00 = I1iI1iIi111i ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 8 ] , 11 , OoiIIiIi1 [ 37 ] )
   Ii1I1i = I1iI1iIi111i ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 11 ] , 16 , OoiIIiIi1 [ 38 ] )
   oOooO0 = I1iI1iIi111i ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 14 ] , 23 , OoiIIiIi1 [ 39 ] )
   O0O0OOOOoo = I1iI1iIi111i ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 1 ] , 4 , OoiIIiIi1 [ 40 ] )
   OOo0oO00ooO00 = I1iI1iIi111i ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 4 ] , 11 , OoiIIiIi1 [ 41 ] )
   Ii1I1i = I1iI1iIi111i ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 7 ] , 16 , OoiIIiIi1 [ 42 ] )
   oOooO0 = I1iI1iIi111i ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 10 ] , 23 , OoiIIiIi1 [ 43 ] )
   O0O0OOOOoo = I1iI1iIi111i ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 13 ] , 4 , OoiIIiIi1 [ 44 ] )
   OOo0oO00ooO00 = I1iI1iIi111i ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 0 ] , 11 , OoiIIiIi1 [ 45 ] )
   Ii1I1i = I1iI1iIi111i ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 3 ] , 16 , OoiIIiIi1 [ 46 ] )
   oOooO0 = I1iI1iIi111i ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 6 ] , 23 , OoiIIiIi1 [ 47 ] )
   O0O0OOOOoo = I1iI1iIi111i ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 9 ] , 4 , OoiIIiIi1 [ 48 ] )
   OOo0oO00ooO00 = I1iI1iIi111i ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 12 ] , 11 , OoiIIiIi1 [ 49 ] )
   Ii1I1i = I1iI1iIi111i ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 15 ] , 16 , OoiIIiIi1 [ 50 ] )
   oOooO0 = I1iI1iIi111i ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 2 ] , 23 , OoiIIiIi1 [ 51 ] )
   O0O0OOOOoo = IIiIi1iI ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 0 ] , 6 , OoiIIiIi1 [ 52 ] )
   OOo0oO00ooO00 = IIiIi1iI ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 7 ] , 10 , OoiIIiIi1 [ 53 ] )
   Ii1I1i = IIiIi1iI ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 14 ] , 15 , OoiIIiIi1 [ 54 ] )
   oOooO0 = IIiIi1iI ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 5 ] , 21 , OoiIIiIi1 [ 55 ] )
   O0O0OOOOoo = IIiIi1iI ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 12 ] , 6 , OoiIIiIi1 [ 56 ] )
   OOo0oO00ooO00 = IIiIi1iI ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 3 ] , 10 , OoiIIiIi1 [ 57 ] )
   Ii1I1i = IIiIi1iI ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 10 ] , 15 , OoiIIiIi1 [ 58 ] )
   oOooO0 = IIiIi1iI ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 1 ] , 21 , OoiIIiIi1 [ 59 ] )
   O0O0OOOOoo = IIiIi1iI ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 8 ] , 6 , OoiIIiIi1 [ 60 ] )
   OOo0oO00ooO00 = IIiIi1iI ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 15 ] , 10 , OoiIIiIi1 [ 61 ] )
   Ii1I1i = IIiIi1iI ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 6 ] , 15 , OoiIIiIi1 [ 62 ] )
   oOooO0 = IIiIi1iI ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 13 ] , 21 , OoiIIiIi1 [ 63 ] )
   O0O0OOOOoo = IIiIi1iI ( O0O0OOOOoo , oOooO0 , Ii1I1i , OOo0oO00ooO00 , I11iiI1i1 [ OO0000o + 4 ] , 6 , OoiIIiIi1 [ 64 ] )
   OOo0oO00ooO00 = IIiIi1iI ( OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , Ii1I1i , I11iiI1i1 [ OO0000o + 11 ] , 10 , OoiIIiIi1 [ 65 ] )
   Ii1I1i = IIiIi1iI ( Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , oOooO0 , I11iiI1i1 [ OO0000o + 2 ] , 15 , OoiIIiIi1 [ 66 ] )
   oOooO0 = IIiIi1iI ( oOooO0 , Ii1I1i , OOo0oO00ooO00 , O0O0OOOOoo , I11iiI1i1 [ OO0000o + 9 ] , 21 , OoiIIiIi1 [ 67 ] )
   O0O0OOOOoo = iiIiI ( O0O0OOOOoo , OOOO0oo0 )
   oOooO0 = iiIiI ( oOooO0 , iiI1IiI )
   Ii1I1i = iiIiI ( Ii1I1i , I1i1Iiiii )
   OOo0oO00ooO00 = iiIiI ( OOo0oO00ooO00 , OOI1iI1ii1II )
  return II1 ( O0O0OOOOoo ) + II1 ( oOooO0 ) + II1 ( Ii1I1i ) + II1 ( OOo0oO00ooO00 )
  if 42 - 42: I1Ii111
  if 76 - 76: IiII * i1 % O00OoOoo00
 def OoooO00o ( b ) :
  def o0O0o ( s ) :
   o0O0o0 , IIiIi1iI , s , III1Iiii1I11 = s . split ( ',' )
   Oo0oO = iI111i = IIIII11I1IiI = 0 ; iiiIi1 = [ ] ; Iiii = [ ]
   while True :
    if Oo0oO < 5 : Iiii . append ( o0O0o0 [ Oo0oO ] )
    elif Oo0oO < len ( o0O0o0 ) : iiiIi1 . append ( o0O0o0 [ Oo0oO ] )
    Oo0oO += 1
    if 77 - 77: o00O0oo - IiII * Oo0Ooo * iIii1 * iiiIIii1IIi
    if iI111i < 5 : Iiii . append ( IIiIi1iI [ iI111i ] )
    elif iI111i < len ( IIiIi1iI ) : iiiIi1 . append ( IIiIi1iI [ iI111i ] )
    iI111i += 1
    if 100 - 100: i11Ii11I1Ii1i / O00OoOoo00 / OOO0o0o
    if IIIII11I1IiI < 5 : Iiii . append ( s [ IIIII11I1IiI ] )
    elif IIIII11I1IiI < len ( s ) : iiiIi1 . append ( s [ IIIII11I1IiI ] )
    IIIII11I1IiI += 1
    if 78 - 78: I1Ii111 - o0o / o00O0oo
    if len ( o0O0o0 ) + len ( IIiIi1iI ) + len ( s ) + len ( III1Iiii1I11 ) == len ( iiiIi1 ) + len ( Iiii ) + len ( III1Iiii1I11 ) : break
    if 10 - 10: i1 + I1Ii111 * OOO0o0o + iiiIIii1IIi / O00OoOoo00 / OOO0o0o
   oOooO0 = '' . join ( s for s in iiiIi1 ) ; OoiIIiIi1 = '' . join ( s for s in Iiii ) ; iI111i = 0 ; i1Ii = [ ]
   for Oo0oO in range ( 0 , len ( iiiIi1 ) , 2 ) :
    iiIiI = - 1
    if ord ( OoiIIiIi1 [ iI111i ] ) % 2 : iiIiI = 1
    i1Ii . append ( chr ( int ( oOooO0 [ Oo0oO : Oo0oO + 2 ] , 36 ) - iiIiI ) )
    iI111i += 1
    if iI111i >= len ( Iiii ) : iI111i = 0
   return '' . join ( s for s in i1Ii )
  OO0000o = 0
  while OO0000o < 5 or 'decodeLink' not in b :
   try : b = o0O0o ( i1IIIiiII1 ( "(\w{100,},\w+,\w+,\w+)" , b . replace ( "'" , '' ) ) ) ; OO0000o += 1
   except : break
  return b
  if 42 - 42: IiII
 return ooo ( string , key ) if key else OoooO00o ( string )
 if 38 - 38: ooO + iII111i % iIii1 % o00O0oo - ooo0Oo0 / iII111iiiii11
ii = xbmc . translatePath ( 'special://userdata' )
oOOo = os . path . join ( ii , 'search.p' )
if 73 - 73: o0o * OO0OO0O0O0 - Oo0Ooo
oOOOo00O00oOo = os . path . join ( ii , 'cid' )
if not os . path . exists ( oOOOo00O00oOo ) :
 with open ( oOOOo00O00oOo , "w" ) as Iiii :
  Iiii . write ( str ( uuid . uuid1 ( ) ) )
  if 85 - 85: ooo0Oo0 % i1 + OOoO / o0o . i11Ii11I1Ii1i + ooO
if __name__ == '__main__' :
 oo000 . run ( ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
