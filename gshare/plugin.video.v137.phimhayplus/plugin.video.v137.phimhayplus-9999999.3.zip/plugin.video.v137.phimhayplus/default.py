#!/usr/bin/env python
# -*- coding: utf-8 -*-

debug       = False
maintenance = False

import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import cookielib, json, os, random, re, requests, string, sys, urllib, urllib2, urlparse
from bs4 import BeautifulSoup
import HTMLParser
html_parser = HTMLParser.HTMLParser()

addon         = xbmcaddon.Addon()
addonId       = addon.getAddonInfo('id')
addonBase     = sys.argv[0]
addonHandle   = int(sys.argv[1])
pluginArgs    = urlparse.parse_qs(sys.argv[2][1:])
addonDir      = xbmc.translatePath(addon.getAddonInfo('path'))
icon          = os.path.join(addonDir, 'icon.png')
fanart        = 'https://v137.xyz/py/v137/img/phimhayplus_02.jpg' # os.path.join(addonDir, 'fanart.jpg')
domain        = 'http://phimhayplus.com/' # modify also in /p/gb
searchUrl     = '/ajax/suggest'

colour1       = '[COLOR white][B]%s[/B][/COLOR]'
colour2       = '[COLOR yellowgreen][B]%s[/B][/COLOR]'
colour3       = '[COLOR limegreen][B]%s[/B][/COLOR]'
colour9       = '[COLOR yellow][B]%s[/B][/COLOR]'

skin_used     = xbmc.getSkinDir()
maxhistory    = 25

resolution    = {
	16 : 'FULL',
	15 : '1080',
	14 : '720',
	13 : 'HD',
	12 : 'HQ',
	11 : '576',
	10 : '540',
	9  : 'MQ',
	8  : '480',
	7  : '360',
	6  : 'SD',
	5  : 'Auto',
	4  : '240',
	3  : 'LQ',
	2  : 'LOW',
	1  : 'LOWEST',
	0  : 'MOBILE',
}

userPath      = xbmc.translatePath(addon.getAddonInfo('profile'))
if not os.path.exists(userPath):
	os.makedirs(userPath)

# PERSIST COOKIES ACROSS SESSIONS
cookieJar     = os.path.join(userPath, 'cookiejar.lwp')
cj            = cookielib.LWPCookieJar(cookieJar)
if not os.path.exists(cookieJar):
	cj.save()
else:
	try:
		cj.load(ignore_discard=True)
	except:
		os.remove(cookieJar)
		cj.save()

s             = requests.session()

jar = requests.cookies.RequestsCookieJar()
jar.set('CLIENT_IP6', '', domain='.phimhayplus.com', path='/')
jar.set('CLIENT_IPV6', '', domain='.phimhayplus.com', path='/')
jar.set('CLIENT_PROXY_OUT', '', domain='.phimhayplus.com', path='/')
jar.set('CLIENT_COUNTRY', 'US', domain='.phimhayplus.com', path='/')
 

userAgent     = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'


icons        = {
 'countries'  : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_explore_white_48dp.png',
 'genres'     : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_class_white_48dp.png',
 'hd'         : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_hd_white_48dp.png',
 'history'    : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_history_white_48dp.png',
 'intheatres' : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_theaters_white_48dp.png',
 'movies'     : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_creation_white_48dp.png',
 'new'        : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_fiber_new_white_48dp.png',
 'nextpage'   : 'https://github.com/google/material-design-icons/raw/master/navigation/drawable-xxxhdpi/ic_last_page_white_48dp.png',
 'popular'    : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_remove_red_eye_white_48dp.png',
 'search'     : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_search_white_48dp.png',
 'series'     : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_filter_white_48dp.png',
 'warning'    : 'https://github.com/google/material-design-icons/raw/master/alert/drawable-xxxhdpi/ic_warning_white_48dp.png'
}

def Home():
	if maintenance:
		xbmcgui.Dialog().ok('[COLOR deepskyblue][B]CHÚ Ý / ATTENTION[/B][/COLOR]', '[COLOR white][B]Trang web tạm đang có lỗi kỹ thuật.[/B][/COLOR]', '[COLOR white][B]Website is temporarily having technical difficulties.[/B][/COLOR]')
	AddDir('[COLOR yellowgreen][B][ Tìm Kiếm ][/B][/COLOR]',           'http://phimhayplus.com/ajax/suggest?ajaxSearch=1&keysearch=%s', 'history', icon)
#	AddDir('[COLOR white][B]Phim mới[/B][/COLOR]',                     'http://phimhayplus.com/phim-moi/trang-1.html', 'index', icon)
	AddDir('[COLOR white][B]Phim lẻ[/B][/COLOR]',                      'http://phimhayplus.com/phim-le/trang-1.html', 'index', icon)
	AddDir('[COLOR white][B]Phim bộ[/B][/COLOR]',                      'http://phimhayplus.com/phim-bo/trang-1.html', 'index', icon)
	AddDir('[COLOR white][B]Phim chiếu rạp[/B][/COLOR]',               'http://phimhayplus.com/phim-chieu-rap/trang-1.html', 'index', icon)
	AddDir('[COLOR white][B]Trailer phim[/B][/COLOR]',                 'http://phimhayplus.com/trailer/trang-1.html', 'index', icon)
	AddDir('[COLOR yellowgreen][B]+ Thể loại[/B][/COLOR]',             'http://phimhayplus.com', 'categories', icon)
	AddDir('[COLOR yellowgreen][B]+ Quốc gia[/B][/COLOR]',             'http://phimhayplus.com', 'categories', icon)
	AddDir('[COLOR yellowgreen][B]+ Phim lẻ năm sản xuất[/B][/COLOR]', 'http://phimhayplus.com', 'categories', icon)
	AddDir('[COLOR yellowgreen][B]+ Phim bộ năm sản xuất[/B][/COLOR]', 'http://phimhayplus.com', 'categories', icon)

	EndDir()
#	if skin_used == 'skin.heidi':
#		xbmc.executebuiltin('Container.SetViewMode(53)')

def Categories(category):
	xbmc.log('| Categories | %s' % category)
	html = Request(domain, referer=domain)
	html = html.replace('<li><a href="/">Home</a></li>', '')
	menus = re.compile('<nav>(.+?)</nav>').findall(html)
	menus = re.compile('<li><a[^>]*>(.+?)</a>\s?<ul>(.+?)</ul>').findall(html)
	for header, menu in menus:
		header = header.encode('utf-8')
		menu   = menu.encode('utf-8')
		if header.lower() in category.lower():
			items = re.compile('<li><a href="(.+?)" title=".+?">([^<]*)</a></li>').findall(menu)
			for url, name in items:
				url = url + 'trang-1.html' if url.endswith('/') else url + '/trang-1.html'
				AddDir('[COLOR white][B]%s[/B][/COLOR]' % name, url, 'index', icon)
			EndDir()

def History(url):
#	if True: # DEBUG #
	try:
		history = eval(addon.getSetting('history'))
		if len(history) == 0:
			raise
	except:
		history = '[]'
		addon.setSetting('history', history)
		Search(url, history)
	else:
		contextMenu = [('[COLOR white][B]XÓA TẤT CẢ[/B][/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=clear)' % addonId)]
		AddDir('[COLOR white][B]TÌM KIẾM MỚI[/B][/COLOR]', url, 'search', icons['search'], extra=str(history), context=contextMenu)
		for i, searchText in enumerate(reversed(history)):
			num = abs(i+1-len(history))
			searchText = urllib.unquote(searchText)
			contextMenu = [
				('[COLOR white][B]XÓA HÀNG[/B][/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=clear&extra=%d)' % (addonId, num)),
				('[COLOR white][B]XÓA TẤT CẢ[/B][/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=clear)' % addonId)
			]
			AddDir('[COLOR yellowgreen][B]%s[/B][/COLOR]' % urllib.unquote_plus(searchText),  url % searchText, 'index', icons['history'], context=contextMenu)
		EndDir(viewMode=50)

def Search(url, history):
#	if True: # DEBUG #
	try:
		if '/suggest' in url:
			keyb = xbmc.Keyboard('', '[COLOR white][B]Nhập từ khóa để tìm:[/B][/COLOR]')
			keyb.doModal()
			if (keyb.isConfirmed()):
				searchText = urllib.quote_plus(keyb.getText())
				if not searchText == '':
					try:
						history = eval(history)
						if len(history) >= maxhistory: del history[0]
						history.append(searchText)
						addon.setSetting('history', repr(history))
					except:
						pass
		url = url % (searchText)
		xbmc.log('| Search | %s' % url)
		Index(url)
	except:
		pass

def Clear(num):
	if num:
		history = eval(addon.getSetting('history'))
		del history[int(num)]
	else:
		history = []
	addon.setSetting('history', repr(history))
	if len(history) == 0:
		AddDir('[COLOR white][B]TÌM KIẾM MỚI[/B][/COLOR]', '', 'search', icons['search'], extra=str(history))
		EndDir(viewMode=50)
	else:
		xbmc.executebuiltin('Container.Refresh')

def Index(url):
	xbmc.log('| Index | %s' % url)
	if searchUrl in url:
		url2, params = url.split('?')
		data = {
			'ajaxSearch' : urllib.unquote_plus(urlparse.parse_qs(params)['ajaxSearch'][0]),
			'keysearch'  : urlparse.parse_qs(params)['keysearch'][0],
		}
		soup = Request(url2, post=True, data=data, soup=True)
#		xbmc.log(str(soup).decode('utf-8').encode('utf-8'))
		items = soup.find_all(class_='ss-info')
	else:
		html = Request(url, referer=domain)
		items = re.compile(u'(<a class="movie-item m-block" title=".+?">.+?</a>)').findall(html)
	for item in items:
#		if True: # DEBUG #
		try:
			if searchUrl in url:
				vurl   = item.a['href']
				vthumb = re.compile('background-image: url\(\'([^\']*)\'\)').findall(str(item.parent))[0]
				vname1 = item.find(class_='ss-title').text
				try:
					vname2 = item.find_all('p')[0].text
				except:
					vanem2 = ''
				try:
					vinfo = vname2 = item.find_all('p')[1].text
				except:
					vinfo = ''
			else:
				vurl   = re.compile('<a class="movie-item m-block" title=".+?" href="(.+?)">').findall(item)[0]
				vthumb = re.compile('background-image:url\("(.+?)"\)').findall(item)[0]
				vname1 = re.compile('<div class="movie-title-1">([^<]*)<').findall(item)[0]
				try:
					vname2 = re.compile('span class="movie-title-2">([^<]*)<').findall(item)[0]
				except:
					vname2 = ''
#				vinfo  = re.compile('<span class="movie-title-chap">([^<]*)<').findall(item)[0]
				vinfo = re.compile('<span class="ribbon">([^<]*)<').findall(item)[0]
			vinfo   = vinfo.replace('HD-', '').replace('HD ', '').replace(u'Lồng tiếng', u'Lồng Tiếng').replace(u'Thuyết minh', u'Thuyết Minh').replace(u'Full Vietsub', u'Phụ Đề').replace(u'Full VietSub', u'Phụ Đề').replace(u'Vietsub', u'Phụ Đề').replace(u'VietSub', u'Phụ Đề').replace(u'BẢN ĐẸP', '').strip()
			vinfo  = vinfo.replace(u'Lồng Tiếng', u'LT').replace(u'Thuyết Minh', u'TM').replace(u'Phụ Đề', u'PD').strip()
			if vinfo == '':
				vinfo = '/'
			else:
				if vinfo.startswith('|'):
					vinfo = vinfo.replace('| ', '')
				if vinfo.startswith('+'):
					vinfo = vinfo.replace('+', '')
				vinfo = '(' + vinfo.encode('utf-8') + ')'
			vname1 = html_parser.unescape(vname1).strip().encode('utf-8').replace('"', "'").replace('&#39', "'")
			vname2 = html_parser.unescape(vname2).strip().encode('utf-8').replace('"', "'").replace('&#39', "'")
			if not vurl.startswith('http'):
				vurl = domain + vurl
			vurl   = vurl.encode('utf-8')
			vthumb = vthumb.replace(' ', '%20').encode('utf-8')
			AddDir('[COLOR white][B]' + vname1 + '[/B][/COLOR] ' + '[COLOR yellowgreen][B]' + vinfo + '[/B][/COLOR]' + ' [COLOR grey][B]' + vname2 + '[/B][/COLOR]', vurl, 'mirrors', vthumb.encode('utf-8'), vname=(vname1 + ' - ' + vname2))
		except:
			pass

#	if True: # DEBUG POINT
	try:
		page = int(re.compile(u'/trang-(\d+).html').findall(url)[0])
		if u'Trang kế' in html:
			pnext = re.sub(u'/trang-(\d+).html', '/trang-' + str(page+1) + '.html', url)
			AddDir('[COLOR yellowgreen][B]Trang kế >>[/B][/COLOR]', pnext, 'index', '')
		if '/tim-kiem' not in url:
			AddDir('[COLOR grey][B][ Nhập số trang ][/B][/COLOR]', re.sub('/trang-(\d+).html', '/trang-%s.html', url), 'search', '')
	except:
		pass
	if searchUrl in url and len(items) == 0:
		AddDir('[COLOR white][B]Tìm kiếm không có kết quả.[/B][/COLOR]', '', '', icons['warning'], folder=False)
		AddDir('[COLOR yellowgreen][B]Vui lòng bấm nút RETURN để quay trở lại.[/B][/COLOR]', '', '', icons['warning'], folder=False)
	EndDir()

def Info(url, image):
	src   = Request(url, referer=domain)
	try:
		desc  = re.compile('<div class="content" id="film-content"[^>]*>([^<]*)<').findall(src)[0]
	except:
		desc  = re.compile('<meta property="og:description" content="(.+?)"').findall(src)[0]
	try:
		title = re.compile('filmInfo.title = "(.+?)";').findall(src)[0]
	except:
		title = re.compile('<meta property="og:title" content="(.+?)"').findall(src)[0]
	if not image:
		image = re.compile('<meta property="og:image" content="(.+?)"').findall(src)[0]
	info  = re.compile('<div class="movie-meta-info">(.+?)</div>').findall(src)[0]
	info  = info.replace('<br />', '').replace('<br/>', '')
	info  = re.sub('(<a[^>]*>)', '', info)
	info  = re.sub('(</a>)', '', info)
	info  = re.sub('<dd[^>]*></dd>', '', info)
	lines = re.compile('<dt[^>]*>(.+?)</dt><dd[^>]*>(.+?)</dd>').findall(info)
	info2 = ''
	for line1, line2 in lines:
		if line2.endswith(', '): line2 = line2[0:len(line2)-2]
		if '>' in line1: line1 = line1.split('>')[-1]
		if '>' in line2: line1 = line2.split('>')[-1]
		info2 = info2 + line1 + line2 + '\n'
	info2 = info2.replace(':', ': ').replace(':  ', ': ')

	ACTION_MOVE_LEFT     = 1
	ACTION_MOVE_RIGHT    = 2
	ACTION_MOVE_UP       = 3
	ACTION_MOVE_DOWN     = 4
	ACTION_PREVIOUS_MENU = 10
	ACTION_BACK          = 92
	class InfoWindow(xbmcgui.WindowDialog):
		def __init__(self):
			# MAIN WINDOW
			self.window = xbmcgui.ControlImage(x=0, y=0, width=1280, height=720, filename=fanart, aspectRatio=0, colorDiffuse='0xFF666666')
			self.addControl(self.window)
			# IMAGE
			self.imageWindow = xbmcgui.ControlImage(x=47, y=47, width=306, height=406, filename=os.path.join(addonDir, 'resources/images/white.png'), aspectRatio=0, colorDiffuse='0x55FFFFFF')
			self.addControl(self.imageWindow)
			self.image = xbmcgui.ControlImage(x=50, y=50, width=300, height=400, filename=image, aspectRatio=1)
			self.addControl(self.image)
			# TEXT
			if xbmc.getSkinDir() == 'skin.estuary':
				self.title = xbmcgui.ControlLabel(x=400, y=50, width=830, height=50, label=title, font='font52_title', textColor='0xFFFFFFFF', alignment=0)
			else:
				self.title = xbmcgui.ControlLabel(x=400, y=50, width=830, height=50, label=title, font='Volume', textColor='0xFFFFFFFF', alignment=0)
			self.addControl(self.title)
			self.textboxWindow = xbmcgui.ControlImage(x=400, y=125, width=830, height=330, filename='https://v137.xyz/py/v137/img/black.png', aspectRatio=0, colorDiffuse='0x88444444')
			self.addControl(self.textboxWindow)
			self.textbox1 = xbmcgui.ControlTextBox(x=425, y=140, width=780, height=300, font='Details', textColor='0xFF44FF44')
			self.addControl(self.textbox1)
			self.textbox1.setText(info2)
			self.textbox1.autoScroll(2500, 2500, 2500)
			self.textbox2 = xbmcgui.ControlTextBox(x=400, y=480, width=830, height=190, font='size22', textColor='0xFFFFFFFF')
			self.addControl(self.textbox2)
			self.textbox2.setText(desc)
			self.textbox2.autoScroll(2500, 2500, 2500)
			# BUTTON
			if xbmc.getSkinDir() == 'skin.estuary':
				self.button1 = xbmcgui.ControlButton(x=50, y=500, width=300, height=50, label='Xem | Watch', focusTexture=os.path.join(addonDir, 'resources/images/white.png'), noFocusTexture=os.path.join(addonDir, 'resources/images/white.png'), font='font36_title', textColor ='0xFF222222', alignment=6, disabledColor='0xFF222222', focusedColor='0xFF222222')
			else:
				self.button1 = xbmcgui.ControlButton(x=50, y=500, width=300, height=50, label='XEM', font='InfoTitle', alignment=6)
			self.addControl(self.button1)
			self.setFocus(self.button1)

		def onAction(self, action):
			if action == ACTION_PREVIOUS_MENU or action == ACTION_BACK:
				self.close()
				self.prompt = False

		def onControl(self, control):
			if control == self.button1:
				self.close()
				self.prompt = True

		def Response(self):
			return self.prompt

	window = InfoWindow()
	window.setCoordinateResolution(2)
	window.doModal()
	prompt = window.Response()
	del window
	if prompt:
		return AdultCheck(info2)

def Mirrors(url, image, vname):
	newurl = url + 'xem-phim.html' if url.endswith('/') else url + '/xem-phim.html'
	xbmc.log('| Mirrors | %s' % newurl)
	html = Request(newurl, referer=domain)
	mlist = re.compile(u'class="server-title">([^<]*)<.+?<ul class="list-episode">(.+?)</ul>').findall(html)
	if not mlist:
		mlist = re.compile(u'class="server-name">([^<]*)<.+?<ul class="list-episode">(.+?)</ul>').findall(html)
	if mlist:
		if len(mlist) > 1:
			for index, (mirror) in enumerate(mlist):
				label = '[COLOR white][B]Nguồn ' + mirror[0].encode('utf-8') + '[/B][/COLOR]'
				html = mlist[index][1].encode('utf-8')
				AddDir(label, newurl, 'episodes', image, vname=vname, extra=html, context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % newurl)])
			EndDir()
		else:
			html = mlist[0][1].encode('utf-8')
			if html == '':
				AddDir('[COLOR white][B]Bấm RETURN để quay trở lại.[/B][/COLOR]', '', '', '', '', folder=False, playable=False)
				AddDir('[COLOR white][B]Press RETURN to go back.[/B][/COLOR]', '', '', '', '', folder=False, playable=False)
				EndDir()
			else:
				Episodes(newurl, image, vname, html)
	else:
		PlayVideo(newurl, image, vname)


def Episodes(url, image, vname, html):
	html = html.decode('utf-8')
	xbmc.log('| Episodes | %s' % url)
	if html == '':
		PlayVideo(url, image, vname)
	else:
		elist = re.compile(u'class="episode[^"]*">.+?title="(.+?)" .+? href="([^"]*)"[^>]*>([^>]*)<').findall(html)
		if elist:
			for ename, elink, ename2 in elist:
				ename = ename.strip().encode('utf-8')
				ename2 = 'Tập ' + ename2.strip().encode('utf-8')
				if not elink.startswith('http'):
					elink = domain + elink
				elink = elink.encode('utf-8')
				if len(elist) == 1:
					PlayVideo(elink, image, vname)
				else:
					AddDir('[COLOR yellowgreen][B]' + ename2 + '[/B][/COLOR] - [COLOR white][B]' + vname + '[/B][/COLOR]', elink, 'loadvideo', image, vname=(vname + ' [COLOR yellowgreen][B](' + ename + ')[/B][/COLOR]'), playable=True, context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)])
			if len(elist) > 1:
				EndDir()
		else:
			PlayVideo(url, image, vname)

def GetVideo(url):
	if domain in url:
		html = Request(url, referer=domain)
	#	xbmc.log(html.encode('utf-8'))
		id = re.compile('filmInfo.filmID = parseInt\("(.+?)"\)').findall(html)[0]
		link = re.compile('PHP\("(.+?)",filmInfo.filmID\)').findall(html)[0]
		data = {
			'id'   : id,
			'link' : link,
		}
		html = Request('http://phimhayplus.com/ajax/player', post=True, data=data)
		if debug:
			xbmc.log(html.encode('utf-8'))
		j = json.loads(html)
		try:
			links = []
			for link in j['link']:
				label = link['label']
				file  = link['file']
				links.append((label, file))
			url2 = ChooseRes(links)
		except:
			url2 = j['link']
	else:
		url2 = url
	url2 = FormatUrl(url2, domain=url)
	xbmc.log('| Resolving... | %s' % url2)
	if 'youtube.' in url2:
		src = YouTube(url2)
	elif 'bilutv.' in url2:
#		src = 'plugin://plugin.video.v137.bilutv/?id=None&image=None&mode=SERVERS&title=None&url=%s' % urllib.quote_plus(url2)
		src = url2
	elif any(domain in url2 for domain in ['docs.google.', 'drive.google.', 'video.google.', 'googleusercontent.', 'googlevideo.', 'youtube.googleapis.']):
		src = GoogleDocs(url2)
	elif any(domain in url2 for domain in ['ok.ru']):
		src = OKRU(url2)
	elif any(domain in url2 for domain in ['openload.', 'oload.']):
		src = UrlResolver(url2)
	else:
		src = url2
	return src

def LoadVideo(url, image, vname, passback=False):
	dialogWait = xbmcgui.DialogProgress()
	dialogWait.create('PhimHayPlus', 'Đang tải. Xin chờ...')
	if debug:
		src = GetVideo(url)
	else:
		try:
			src = GetVideo(url)
		except:
			xbmcgui.Dialog().ok('Xin lỗi', 'Phim hiện không xem được', 'Xin vui lòng thử phim khác')
			sys.exit()
	xbmc.log('| Resolved | %s' % src)
	video = xbmcgui.ListItem(vname, thumbnailImage=image)
	if '.mkv' in src or '.mp4' in src:
		video.setContentLookup(False)
		video.setMimeType('video/mp4')
	video.setProperty('IsPlayable', 'true')
	video.setPath(str(src))
	if 'bilutv.' in src:
#		dialogWait.close()
#		del dialogWait
#		xbmc.executebuiltin('ActivateWindow(10025,"%s",return)' % src)
		xbmc.log('| BiluTV | %s' % src)
		BiluTVServers(src, vname, image, vname)
	elif passback:
		return src, video, dialogWait
	else:
#		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, video)
		xbmc.Player().play(src, listitem=video)
		dialogWait.close()
		del dialogWait

def PlayVideo(url, image, vname):
	if debug:
		src, video, dialogWait = LoadVideo(url, image, vname, passback=True)
	else:
		try:
			src, video, dialogWait = LoadVideo(url, image, vname, passback=True)
		except:
			src = ''
	if src:
		xbmc.Player().play(src, listitem=video)
		dialogWait.close()
		del dialogWait

def Decode(s, p, d=None):
	r = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(500))
	s = s.replace('\/', '/').replace('\\/', '/')
	d = d.replace('https://', '').replace('http://', '').replace('www.', '').replace('/', '')
	xbmc.log('| S | %s' % s)
	xbmc.log('| P | %s' % p)
	if d: url = 'https://v137.xyz/p/gb?r=%s&s=%s&p=%s&d=%s' % (urllib.quote_plus(r), urllib.quote_plus(s), urllib.quote_plus(p), urllib.quote_plus(d))
	else: url = 'https://v137.xyz/p/gb?r=%s&s=%s&p=%s' % (urllib.quote_plus(r), urllib.quote_plus(s), urllib.quote_plus(p))
	src = Request(url)
	return src

def YouTube(url):
	if 'watch?v=' in url:
		youtubeID = re.compile('watch\?v=(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/embed/' in url:
		youtubeID = re.compile('/embed/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/v/' in url:
		youtubeID = re.compile('/v/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	else:
		if url.startswith('http'):
			return url
		else:
			return ''
	return 'plugin://plugin.video.youtube/play/?video_id=%s' % youtubeID

def BiluTVServers(url, title, image, vtitle, src=None):
	domain = 'http://bilutv.com'
	if src == None:
		soup = Request(url, soup=True)
		html = str(soup)
	else:
		soup = src
		html = str(soup)
#	if True: # DEBUG #
	try:
		modelId = re.compile('"modelId":"(.+?)"').findall(html)[0]
		epId    = soup.find(id='film_id')['value']
		if 'sourceLinks' in html:
			servers = eval(re.compile('playerSetting = ({.+?});').findall(html)[0])
			BiluTVMirrors(url, title, image, vtitle, modelId, epId=epId, src=servers)
		else:
			servers = soup.find(id='list-server')
			stypes  = servers.select('.name')
			for stype in stypes:
				slabel = stype.get_text().strip().encode('utf-8')
				servers =stype.parent.find(class_='option').select('.btn')
				for server in servers:
					serverId = server['data-index']
					surl     = domain + '/ajax/getLinkPlayer/id/%s/index/%s' % (epId, serverId)
					stitle   = server.text.strip().encode('utf-8')
					AddDir('%s -- %s' % (colour1 % stitle, colour2 % slabel), surl, 'BILUTVMIRRORS', image, vname=vtitle, id=modelId)
		EndDir(contentType='Files', viewMode=50)
	except:
		xbmc.log('| No servers | ')
		BiluTVMirrors(url, None, image, vtitle=vtitle, id=modelId, src=soup)

def BiluTVMirrors(url, title, image, vtitle, id, epId=None, src=None):
	domain = 'http://bilutv.com'
#	xbmc.log(html.encode('utf-8'))
#	if True: # DEBUG #
	try:
		if src == None:
			soup = Request(url, soup=True)
			html = str(soup)
			epId = re.compile('/id/(.+?)/').findall(url)[0]
			if '<body>' in html:
				j = json.loads(re.compile('<body>(.+?)</body>').findall(html)[0])
			else:
				j = json.loads(html)
		else:
			j = src
#		print j
		mirrors = j['sourceLinks']
		try: mirrors.extend(j['sourceLinksBk'])
		except: pass
		links2 = []
		if mirrors:
			for i, mirror in enumerate(mirrors):
				sources   = mirror['links']
				links  = []
				if sources:
					for source in sources:
						label = source['label']
						link = source['file']
						xbmc.log('| %s | %s' % (label, link))
						links.append((label, link))
					murl = ChooseRes(links)
					xbmc.log('| Encrypted | %s' % murl)
					murl = Decode(murl, id, domain)
					xbmc.log('| Decrypted | %s' % murl)
					if murl:
						status = Request(murl, referer=url, getstatus=True)
						if status < 400:
							links2.append((urlparse.urlparse(murl).netloc.split('.')[-2].upper(), murl))
		if len(links2) == 0:
#			pass # DEBUG 
			raise
		else:
			for mtitle, murl in links2:
				mtitle = '%s %s' % (colour2 % 'Link:', colour1 % mtitle)
				AddDir(mtitle, murl, 'BILUTVPLAY', image, vname=vtitle, id=url, folder=False, playable=True, context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % murl)])
			EndDir(contentType='Files', viewMode=50)
	except:
		xbmc.log('| No mirrors |')
		BiluTVPlay(url, image, vtitle)

def BiluTVResolve(url, referer=''):
#	print(url)
	print('| Resolving... | %s' % url)
	if 'youtube.' in url:
		link = YouTube(url)
	elif 'drive.google.' in url and '/videoplayback?' in url:
		link = url
	elif 'vimeo' in url and '.mp4' in url:
		link = url
	elif 'drive.google.' in url:
		link = GoogleDocs(url)
	elif 'getfb/play.php?' in url:
		link = Request(url, getredir=True)
	elif 'getst/play.php?' in url:
		link = Request(url, getredir=True)
#	elif urlparse.urlparse(domain).netloc.split('.')[-2] in url and '.mp4' in url.lower():
	elif '.mp4' in url.lower() and not 'openload.' in url:
		link = '%s|Referer=%s' % (url, referer)
	else:
		link = UrlResolver(url)
	return link

def BiluTVPlay(url, title, image, referer=''):
#	if True: # DEBUG #
	try:
		src = BiluTVResolve(url, referer)
		print('| Resolved URL | %s' % src)
		title = re.sub('(\[COLOR.+?\])', '', title).replace('[/COLOR]', '').replace('[B]', '').replace('[/B]', '')
		if mode == 'BILUTVPLAY':
			BiluTVSetResolved(src, title, image)
		else:
			li = xbmcgui.ListItem(title, thumbnailImage=image)
			if any(ext in src for ext in ['.mkv', '.mp4']):
				li.setContentLookup(False)
				li.setMimeType('video/mp4')
			xbmc.Player().play(src, listitem=li)
	except:
		xbmcgui.Dialog().ok('Xin lỗi', 'Phim hiện không xem được', 'Xin vui lòng thử phim khác', colour9 % '-- Cannot resolve --')

def BiluTVSetResolved(url, title='', image=''):
	li = xbmcgui.ListItem(title, path=url, thumbnailImage=image)
	if any(ext in url for ext in ['.mkv', '.mp4']):
		li.setContentLookup(False)
		li.setMimeType('video/mp4')
	xbmcplugin.setResolvedUrl(addonHandle, True, li)

def GoogleDocs(url):
	xbmc.log('| GOOGLE DOCS | %s' % url)
	gd_bug     = 0 # 0 = None | 1 = Basic | 2 = Detailed
	gd_agent   = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
	gd_session = requests.session()
	gd_headers = {
		'User-Agent': gd_agent,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate, sdch'
	}
	# Resolve redirect if GoogleUserContent
	if 'googleusercontent.' in url:
		# Get final URL
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url, headers=gd_headers, stream=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			url = r.url
			if gd_bug >= 1: xbmc.log('| GD: REDIRECTION | %s' % url)
	# Extract video ID
	if 'open?id=' in url:
		id = re.compile('open\?id=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'docid=' in url:
		id = re.compile('docid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'driveid=' in url:
		id = re.compile('driveid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif '/file/d/' in url:
		id = re.compile('/file/d/(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	else:
		id = None
	if id:
		url = 'https://docs.google.com/leaf?id=%s' % id
	else:
		return url
	# Initial request
	try:
		if gd_bug >= 1: xbmc.log('| GD: REQUEST | %s' % url)
		r = gd_session.get(url=url, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: xbmc.log('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: xbmc.log(src)
	except Exception, e:
		xbmc.log('| ERROR | %s' % str(e))
		src = ''
		cookie = ''
	# Method 1: parse JSON data
	if 'fmt_stream_map' in src:
		links  = re.compile('(\["fmt_stream_map",.+?\])').findall(src)[0]
		links  = re.compile('(\d+)\|(.+?)[,|"|\]]').findall(links)
		if gd_bug >= 2: xbmc.log(links)
		labels = re.compile('(\["fmt_list",.+?\])').findall(src)[0]
		labels = re.compile('["|,](\d+)/.+?x(.+?)/').findall(labels)
		if gd_bug >= 2: xbmc.log(labels)
		links2 = []
		for i, (linkdigit, link) in enumerate(links):
			for labeldigit, label in labels:
				if labeldigit == linkdigit:
					links2.append((label, link))
			src = ChooseRes(links2)
		src = src.decode('unicode-escape') + '|Cookie=%s' % cookie
	# Method 2: get download link
	else:
		url2 = 'https://drive.google.com/uc?id=%s&export=download' % id
		if gd_bug >= 1: xbmc.log('| GD: REQUEST | %s' % url2)
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url2, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: xbmc.log('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: xbmc.log(src)
		url3 = re.compile('<a id="uc-download-link".+?href="(.+?)">').findall(src)[0]
		url3 = url3.replace('&amp;', '&')
		url3 = 'https://drive.google.com%s' % url3 if not url3.startswith('http') else url3
		# Get final URL
		if gd_bug >= 1: xbmc.log('| GD: REDIRECTION | %s' % url3)
		gd_headers.update({'Referer': url2})
		r = gd_session.head(url=url3, headers=gd_headers, allow_redirects=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			src = r.url
		else:
			if gd_bug >= 1: xbmc.log('| GD: NO REDIRECT |')
			src = url3
	if gd_bug >= 1: xbmc.log('| GD: RESOLVED | %s' % src)
	return src

def OKRU(url):
	url = url.replace('/video/', '/videoembed/')
	html = requests.get(url, headers={'User-Agent': userAgent}).text
#	xbmc.log(html.encode('utf-8'))
	src = re.compile('<div data-module="OKVideo" data-options="(.+?)"').findall(html)[0]
	j = json.loads(src.replace('&quot;', '"'))
	j = json.loads(j['flashvars']['metadata'])
	sources = j['videos']
	links = []
	for source in sources:
		links.append((source['name'], source['url']))
	link = ChooseRes(links, maxres=11)
	return link

def UrlResolver(url):
	if '/preview' in url:
		url = url.split('/preview')[0]
	try:
		import resolveurl
		link = resolveurl.resolve(url)
		if link == False:
			raise
	except:
		link = PopoutFrame(url)
	return link

def PopoutFrame(url):
	url = str(url.encode('utf-8'))
	rnd = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(500))
	xbmcgui.Dialog().ok('HƯỚNG DẪN / INSTRUCTIONS','Bấm nút PLAY hai lần với con chuột để xem...','Press PLAY button twice with mouse to watch...')
	xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","http://v137.xyz/p/if?r='+rnd+'&src='+url+'")')
	return ''

def ChooseRes(src, maxres=15):
	# Forces order: 0. Label, 1. Link
	src2 = []
	if '//' in str(src[0][0]):
		for link, label in src:
			src2.append((label, link))
	else:
		src2 = src
	# Passes single Link
	if len(src2) == 1:
		return src2[0][1]
	else:
	# Auto chooses maximum resolution from settings
		for res in reversed(range(len(resolution))):
			if res <= maxres:
				for i, (label, link) in enumerate(src2):
					if resolution[res].upper() in str(label).upper():
						return link
	# Prompts user to choose resolution
		labels = [('[COLOR white][B]%s[/B][/COLOR]' % label) for label, link in src2]
		dialog = xbmcgui.Dialog()
		prompt = -1
		prompt = dialog.select('Choose / Chọn:', labels)
		if prompt == -1:
			link = None
		else:
			link = src2[prompt][1]
		return link

def AdultCheck(data):
	if any(keyword in data.lower() for keyword in ['phim 18', '18+', '18 +', 'phim xxx', ' ova ', 'hentai', u'cấp 3', u'cap 3',]):
		if xbmc.getCondVisibility('System.HasLocks'):
			if xbmc.getCondVisibility('System.IsMaster'):
				return True
			else:
				profilesXML = os.path.join(xbmc.translatePath('special://userdata'), 'profiles.xml')
				with open(profilesXML, 'rb') as f:
					profiles = f.read()
				code = re.compile('<lockcode>(.+?)</lockcode>').findall(profiles)[0]
				import hashlib
				maxtries = 3
				tries = 0
				while tries < maxtries:
					tries += 1
					dialog = xbmcgui.Dialog()
					prompt = dialog.input('Enter Master Lock Code', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
					if hashlib.md5(prompt).hexdigest() == code:
						return True
					else:
						if tries == maxtries-1:
							xbmcgui.Dialog().ok('Master Lock Code', 'Access denied', '1 try left')
						elif tries < maxtries:
							xbmcgui.Dialog().ok('Master Lock Code', 'Access denied', '%s tries left' % (maxtries-tries))
				return False
	return True

def Request(url,
	params     = '',
	getstatus  = False,
	getredir   = False,
	post       = False,
	data       = None,
	useragent  = userAgent,
	referer    = '',
	extheaders = None,
	usecookies = True,
	getcookies = False,
	extcookies = False,
	encoding   = 'utf-8',
	minify     = True,
	soup       = False,
	strainer   = None,
	cloudflare = False
	):
	headers    = {
		'User-Agent'      : useragent,
		'Accept'          : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding' : 'gzip, deflate, sdch',
		'Referer'         : referer
	}
	if extheaders:
		headers.update(extheaders)
	try:
		if usecookies:
			s.cookies = cj
		if not getredir and not getstatus:
			xbmc.log('| Getting URL | %s%s%s' % (url, ' | ' + params if params is not '' else '', ' | ' + str(data) if str(data) is not None else ''))
			if cloudflare:
				from resources.lib.modules import cloudflare as CloudFlare
				r = CloudFlare.source(url)
				src = r.decode('utf-8')
			else:
				if post:
					r = s.post(url=url, params=params, headers=headers, data=data, timeout=(3.05, 15))
				else:
					r = s.get(url=url, params=params, headers=headers, cookies=jar, timeout=(3.05, 15))
				r.encoding = encoding
				src = r.text#.encode(encoding)
			if soup:
				src = re.sub('(<!\[CDATA\[.+?\]\]\>)', '', src)
				replacements = [('h"+"tml', 'html'), ('ht"+"ml', 'html'), ('htm"+"l', 'html'), ('b"+"ody', 'body'), ('bo"+"dy', 'body'), ('bod"+"y', 'body'), ("s'+'cript", "script"), ("sc'+'ript", "script"), ("scr'+'ipt", "script"), ("scri'+'pt", "script"), ("scrip'+'t", "script")]
				for rep in replacements: src = src.replace(rep[0], rep[1])
				response = BeautifulSoup(src, 'html5lib', parse_only=strainer)
			else:
				if minify:
					response = Minify(src)
				else:
					response = src
		elif getstatus:
			r = s.get(url=url, headers=headers, stream=True, timeout=(3.05, 3))
			response = r.status_code
			print('| Response | %s' % response)
		elif getredir:
			r = s.get(url=url, headers=headers, stream=True, timeout=(3.05, 3))
			response = r.url
			status = r.history
			if any(s in str(status) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
				print('| %s Redirection | %s' % (status, response))
		if getcookies:
			try:
				cj.save()
			except:
				pass
			return response, r.cookies
		else:
			if usecookies:
				try:
					cj.save()
				except:
					pass
			return response
	except Exception, e:
		xbmc.log('| ERROR | %s' % e)
#		sys.exit()
#		xbmcgui.Dialog().ok('[COLOR deepskyblue][B]ERROR[/B][/COLOR]', '[COLOR white][B]Server is offline. Please try again later.[/B][/COLOR]')

def Minify(src):
	src = ''.join(src.splitlines()).replace('\'', '"')
	src = src.replace('\n', '')
	src = src.replace('\t', '')
	src = re.sub('  +', ' ', src)
	src = src.replace('> <', '><')
	return src

def FormatUrl(url, domain=''):
	if not url:
		return domain
	url = url.strip()
	url = url.replace('\/', '/')
	if url.startswith('http') or url.startswith('rtmp'):
		return url
	elif url.startswith('//'):
		return 'http://%s' % url.lstrip('//')
	elif url.startswith('/'):
		return '%s/%s' % ('%s://%s' % (urlparse.urlparse(domain).scheme, urlparse.urlparse(domain).netloc), url.lstrip('/'))
	else:
		if domain.count('/') > 2:
			return '%s/%s' % (domain.rsplit('/', 1)[0], url.lstrip('/'))
		else:
			return '%s/%s' % (domain, url)

def ParseLink(query):
	return addonBase + '?' + urllib.urlencode(query)

def AddDir(name, url, mode, image, vname='', extra='', id='', context=None, contextReplace=False, folder=True, playable=False):
	liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=image)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo(type="Video", infoLabels={"Title":name})
	if playable:
		liz.setProperty("IsPlayable", "true")
	# ADD CONTEXT MENU ITEMS
	if context:
		liz.addContextMenuItems(context, replaceItems=contextReplace)
	link = ParseLink({'name' : name, 'url': url, 'mode': mode, 'image': image, 'vname': vname, 'extra': extra, 'id': id})
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=liz, isFolder=folder)
	return ok

def EndDir(cache=True, contentType='Files', viewMode=50):
	# SET VIEW MODE
	xbmcplugin.setContent(addonHandle, contentType)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewMode)
	# END DIR
	xbmcplugin.endOfDirectory(addonHandle, cacheToDisc=cache)


# GET PLUGIN PARAMETERS
try:     name  = pluginArgs['name'][0]
except:  name  = ''
try:     url   = pluginArgs['url'][0]
except:  url   = ''
try:     mode  = pluginArgs['mode'][0]
except:  mode  = None
try:     image = pluginArgs['image'][0]
except:  image = ''
try:     vname = pluginArgs['vname'][0]
except:  vname = None
try:     extra = pluginArgs['extra'][0]
except:  extra = None
try:     id    = pluginArgs['id'][0]
except:  id    = None


if   mode == 'index' or mode == 'self':  Index(url)
elif mode == 'categories'    : Categories(name)
elif mode == 'history'       : History(url)
elif mode == 'search'        : Search(url, extra)
elif mode == 'clear'         : Clear(extra)
elif mode == 'mirrors'       :
	if debug:
		if Info(url, image):
			Mirrors(url, image, vname)
	else:
		try:
			prompt = Info(url, image)
		except:
			prompt = False
		if prompt:
			Mirrors(url, image, vname)
elif mode == 'episodes'      : Episodes(url, image, vname, extra)
elif mode == 'loadvideo'     : LoadVideo(url, image, vname)
elif mode == 'BILUTVMIRRORS' : BiluTVMirrors(url, name, image, vname, id)
elif mode == 'BILUTVPLAY'    : BiluTVPlay(url, name, image, id)
else                         : Home()
