#!/usr/bin/python
# -*- coding: utf-8 -*-

OFFLINE            = False
DEBUG              = False

from v137       import v137
from threading  import Thread

def Index(baseUrl):
	try:
		page = int(baseUrl.split('/p')[-1].rstrip('/'))
		
	except:
		page = 1
		baseUrl = '%s/p%s' % (baseUrl.rstrip('/'), page)
	soup = v137.Request(baseUrl, soup=True)
	videos = soup.select('.inner')
	count = 0
	for video in videos:
		if DEBUG:
			vurl, name, vicon, vname = Items(baseUrl, video)                                                                                    # MATCHING DEBUG LINES
			vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]     #
			count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                        #
		else:
			try:
				vurl, name, vicon, vname = Items(baseUrl, video)                                                                                # MATCHING DEBUG LINES
				vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)] #
				count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                    #
			except Exception, e:
				v137.Log('| ITEM ERROR | %s' % e)
	if DEBUG:
		Pagination(baseUrl, page, soup)     # MATCHING DEBUG LINES
	else:
		try:
			Pagination(baseUrl, page, soup) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| PAGINATION ERROR | %s' % e)
	if DEBUG: v137.Log('| %s ITEM(S) |' % count)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Items(baseUrl, soup):
	link  = soup.a['href']
	link  = v137.FormatUrl(link, baseUrl)
	name = soup.a['title'].strip().encode('utf-8')
	try:
		icon  = soup.img['src']
		icon  = v137.FormatUrl(icon, baseUrl)
		if 'Untitled' in name and icon:
			name = icon.split('/')[-1].replace('.png', '').replace('.jpg', '').replace('.gif', '').replace('-', ' ').encode('utf-8')
	except:
		icon  = v137.ICON
	vname = name
	try:
		name = '%s - %s' % (COLOUR1 % name.split(' - ')[0], COLOUR2 % name.split(' - ')[1])
	except:
		name = COLOUR1 % vname
	return link, name, icon, name

def Pagination(baseUrl, page, soup):
	pagination = soup.find('ul', class_='pages')
	if '>&raquo;&raquo;<' in str(pagination) or '»»' in str(pagination):
		plink = v137.Resub('/p%s' % page, '/p%s' % (page+1), baseUrl, count=1)
		pname = COLOUR2 % '%s >>' % v137.language[LANG]['NEXT']
		v137.AddItem('INDEX', plink, pname, v137.icons['LAST_PAGE'])

def Submenus(baseUrl, name, icon):
	soup = v137.Request(baseUrl, soup=True)
	menus = soup.select('.sub-menu')
	links = []
	for menu in menus:
		title = menu.previous.encode('utf-8')
		if title.lower() in name.lower():
			links = menu.select('li')
	count = 0
	for link in links:
		cname = COLOUR1 % (link.text.strip().encode('utf-8'))
		clink = link.a['href'].encode('utf-8')
		count += v137.AddItem('INDEX', clink, cname, icon)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Info(baseUrl, vname, icon):
	html  = v137.Request(baseUrl)
	soup  = v137.Soup(html)
	if DEBUG:
		title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html)     # MATCHING DEBUG LINES
	else:
		try:
			title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| INFO ERROR | %s' % e)
			title = None
	if title:
		prompt = v137.Info(title, thumb, info, plot, fanart, trailer, lang=LANG, offset=-40)
		if prompt == 'PLAY':
			if v137.AdultCheck(info):
				Servers(baseUrl, vname, icon, html)
	else:
		Servers(baseUrl, vname, icon, html)

def InfoData(baseUrl, html):
	soup = v137.Soup(html)
	title = soup.find('meta', property='og:title')['content'].lstrip('Phim' ).strip()
	thumb = soup.find('meta', property='og:image')['content']
	thumb = v137.FormatUrl(thumb, baseUrl)
	info  = ''
	metas = soup.find(class_='phim_details').select('li')
	for meta in metas:
		try:
			info = info + ('%s: %s' % (COLOUR2 % meta.text.split(':')[0].strip(), COLOUR1 % meta.text.split(':')[1].strip())) + '\n'
		except:
			pass
	plot = str(soup.find(class_='film_info'))
	plot = v137.StripTags(plot, before='', after='[CR]', minify=True)
	plot = COLOUR1 % plot
	trailer = None
	return title, thumb, info, plot, FANART, trailer

def Servers(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	slink = baseUrl
	servers = soup.select('.servername')
	count = 0
	for server in servers:
		shtml = str(server.find_next_sibling('ul'))
		sname = server.text.strip().encode('utf-8')
		sname = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['SERVER'], COLOUR1 % sname.replace('Server', ''). replace(':', '').strip().upper())
		smore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % slink)]
		if len(servers) > 1:
			count += v137.AddItem('EPISODES', slink, sname, icon, vname=vname, html=shtml, context=smore)
		else:
			count = 1
	if DEBUG: v137.Log('| %s SERVER(S) |' % count)
	if count == 0:
		Episodes(slink, name, icon, None)
	elif count == 1:
		Episodes(slink, name, icon, shtml)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Episodes(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
		soup = v137.Soup(html)
		soup = soup.find(class_='episodelist-info-page')
	else:
		soup = v137.Soup(html)
	episodes = soup.select('a')
	count = 0
	for episode in episodes:
		ename = episode.text.strip().encode('utf-8')
		ename = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['EPISODE'], COLOUR1 % ename)
		elink = episode['href']
		elink = v137.FormatUrl(elink, SITEURL)
		emore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)]
		if len(episodes) > 1:
			count += v137.AddItem('LOAD', elink, ename, icon, vname=vname, context=emore)
		else:
			count = 1
	if DEBUG: v137.Log('| %s EPISODE(S) |' % count)
	if count == 0:
		Load(baseUrl, vname, icon)
	elif count == 1:
		Load(elink, vname, icon)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Load(baseUrl, vname, icon):
	link = None
	if DEBUG:
		link = Links(baseUrl, vname, icon)     # MATCHING DEBUG LINES
	else:
		try:
			link = Links(baseUrl, vname, icon) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| RESOLVE ERROR | %s' % e)
	if link:
		if link == 'LIST':
			pass
		else:
			Play(link, vname, icon)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['CANNOTPLAY'])

def Links(baseUrl, vname, icon):
	html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	# CHECK IF MULTIPLE MIRRORS
	if DEBUG:
		mirrors = soup.find(class_='mirrors').select('a')
	else:
		try:
			mirrors = soup.find(class_='mirrors').select('a')
		except:
			mirrors = []
	# SINGLE LINK, NO MIRRORS
	if not mirrors:
		src = Mirrors(baseUrl, html)
	# MULTIPLE MIRRORS
	else:
		requestedLinks = []
		for mirror in mirrors:
			mlink = mirror['href']
			mlink = v137.FormatUrl(mlink, baseUrl)
			if DEBUG:
				link = GetMirrors(mlink)        # MATCHING DEBUG LINES
				requestedLinks.append(link)     #
				link.start()                    #
			else:
				try:
					link = GetMirrors(mlink)    # MATCHING DEBUG LINES
					requestedLinks.append(link) #
					link.start()                #
				except Exception, e:
					pass
		receivedLinks = {}
		count = 0
		for link in requestedLinks:
			link.join()
			url = link.get()
			if url:
				server = v137.GetDomain(url).split('.')[-2].upper()
				if any(domain in url.upper() for domain in SERVERRANKING.keys()):
					try:
						receivedLinks.update({'%s||%s' % (SERVERRANKING[server], url) : server})
					except:
						receivedLinks.update({url : server})
				else:
					receivedLinks.update({url : server})
				count += 1
		if not count:
			src = None
		elif count == 1:
			src = receivedLinks.keys()[0]
			try:
				src = src.split('||')[1]
			except:
				pass
		else:
			for link in sorted(receivedLinks):
				server = receivedLinks[link]
				try:
					link = link.split('||')[1]
				except:
					pass
				lname = '%s: %s' % (COLOUR2 % v137.language[LANG]['LINK'], COLOUR1 % server)
				lmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % baseUrl)]
				v137.AddItem('PLAY', link, lname, icon, vname=vname, context=lmore)
			v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)
			src = 'LIST'
	return src

class GetMirrors(Thread):
	def __init__ (self, url):
		Thread.__init__(self)
		self.url = url
		self.src = ''
	def run(self):
		self.src = Mirrors(self.url)
	def get(self):
		return self.src

def Mirrors(baseUrl, html=None):
	if not html:
		html = v137.Request(baseUrl, timeout=TIMEOUT)
	soup = v137.Soup(html)

	DOMAINS = [SITEDOMAIN, 'phim2online.', 'phimlt.']

	url = None
	# 1
	iplayer     = soup.find(id='iplayer')
	# 2
	updateSrc   = True if 'player.updateSrc(' in html else None
	# 3
	mediaplayer = soup.find(id='mediaplayer')
	# 4
	dailymotion = True if 'DM.player(' in html else None
	# 5
	youtube     = True if any(domain in html for domain in ['youtube.', 'youtu.be']) else None

	if not url and iplayer: # 1
		if DEBUG: v137.Log('| IPLAYER...' )
		try:
			iframe = iplayer.iframe
			source = iplayer.source
			if iframe:
				src = iframe['src']
			elif source:
				src = source['src']
			else:
				src = iplayer['src']
			url = v137.FormatUrl(src, baseUrl)
			if any(domain in url for domain in DOMAINS):
				url = Mirrors(url)
		except Exception, e:
			if DEBUG: v137.Log('| %s' % e)
			url = None

	if not url and updateSrc: # 2
		if DEBUG: v137.Log('| UPDATESRC...' )
		try:
			src = v137.Regex('player.updateSrc\((.+?)\);', html)[0]
			url = v137.LinksFinder(src, baseUrl)
		except Exception, e:
			if DEBUG: v137.Log('| %s' % e)
			url = None

	if not url and mediaplayer: # 3
		if DEBUG: v137.Log('| MEDIAPLAYER...' )
		try:
			iframe = mediaplayer.iframe
			source = mediaplayer.source
			if iframe:
				src = iframe['src']
			elif source:
				src = source['src']
			else:
				src = mediaplayer['src']
			url = v137.FormatUrl(src, baseUrl)
		except Exception, e:
			if DEBUG: v137.Log('| %s' % e)
			url = None

	if not url and dailymotion: # 4
		if DEBUG: v137.Log('| DAILYMOTION...' )
		try:
			url =  v137.Regex('DM.player\(.+?video:\s?"(.+?)"', html)[0]
		except Exception, e:
			if DEBUG: v137.Log('| %s' % e)
			url = None

	if not url and youtube: # 5
		if DEBUG: v137.Log('| YOUTUBE...' )
		try:
			url = v137.YouTube(html)
		except Exception, e:
			if DEBUG: v137.Log('| %s' % e)
			url = None

	if url:
		if DEBUG: v137.Log('| MIRROR | %s' % url)
		status = v137.Request(url, getStatus=True, timeout=TIMEOUT)
		if status == 200:
			return url
		else:
			return None
	return None

def Play(baseUrl, vname, icon):
	if any(domain in baseUrl for domain in ['/redirector.php?url=',]):
		baseUrl = v137.Request(baseUrl, getRedirect=True, timeout=(2.05, 5))
	url = v137.Resolver(baseUrl, lang=LANG)
	if url:
		player = v137.Player(url, vname, icon)
		return player

# #################################################################################################### #


if __name__ == '__main__'    :

	if v137.Android: DEBUG = False

	SITENAME           = 'Phim LT'
	SITEDOMAIN         = 'phimlt.com'
	SITEURL            = 'http://phimlt.com'
	SEARCHURL          = '/search/%s'
	FANART             = v137.Path(v137.addonPath, 'phimlt_02.jpg') if DEBUG else 'https://v137.xyz/py/v137/img/phimlt_02.jpg'
	COLOUR1            = '[COLOR white][B]%s[/B][/COLOR]'
	COLOUR2            = '[COLOR aqua][B]%s[/B][/COLOR]'
	COLOUR3            = '[COLOR silver][B]%s[/B][/COLOR]'
	COLOUR9            = '[COLOR yellow][B]%s[/B][/COLOR]'
	LANG               = 'VI'
	DEFAULTVIEW        = v137.listView

	SERVERRANKING      = {
		'YOUTUBE'           : 1,
		'YOUTU'             : 1,
		'BLOGSPOT'          : 2,
		'GOOGLEUSERCONTENT' : 2,
		'RAPIDVIDEO'        : 3,
		'PHIM2ONLINE'       : 5,
	}

	TIMEOUT            = (2.05, 3)

	mode, link, name, icon, vname, extra, extra2, extra3, html = v137.Parameters()
	if DEBUG:
		v137.Log('| Mode   | %s' % mode)
		v137.Log('| Link   | %s' % link)
		v137.Log('| Name   | %s' % name)
		v137.Log('| Icon   | %s' % icon)
		v137.Log('| vName  | %s' % vname)
		v137.Log('| Extra  | %s' % extra)
#		v137.Log('| HTML   | %s' % html)

	if not mode             :
		if OFFLINE:
			v137.Offline(lang=LANG)
		v137.AddItem('INDEX',    SITEURL + '/list/new/',                 COLOUR2 % 'Phim Mới',           v137.icons['FIBER_NEW'],      FANART)
#		v137.AddItem('INDEX',    SITEURL + '/list/top-rate/',            COLOUR2 % 'Phim Hot',           v137.icons['WHATSHOT'],       FANART)
#		v137.AddItem('INDEX',    SITEURL + '/list/phim-xem-nhieu/',      COLOUR2 % 'Phim Xem Nhiều',     v137.icons['REMOVE_RED_EYE'], FANART)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-le/',             COLOUR1 % 'Phim Lẻ',            v137.icons['MOVIE'],          FANART)
		v137.AddItem('INDEX',    SITEURL + '/list/phim-bo/',             COLOUR1 % 'Phim Bộ',            v137.icons['MOVIE_FILTER'],   FANART)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR1 % '+ Phim Thể Loại',    v137.icons['BOOK'],           FANART)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR1 % '+ Phim Bộ Quốc Gia', v137.icons['LANGUAGE'],       FANART)
		v137.AddItem('SEARCH',   SITEURL + SEARCHURL,                    COLOUR2 % '[ Tìm Kiếm ]',       v137.icons['SEARCH'],         FANART)
		v137.EndItems(contentType='Files', viewMode=v137.listView)

		v137.DefineSettings(settingsXML='Bare')

	elif mode == 'INDEX'        : Index(link)
	elif mode == 'SUBMENUS'     : Submenus(link, name, icon)
	elif mode == 'INFO'         : Info(link, vname, icon)
	elif mode == 'SERVERS'      : Servers(link, vname,icon, html)
	elif mode == 'EPISODES'     : Episodes(link, vname, icon, html)
	elif mode == 'LOAD'         : Load(link, vname, icon)
	elif mode == 'PLAY'         : Play(link, vname, icon)
	elif mode == 'SEARCH'       :
		link  =  v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link:
			Index(link)
