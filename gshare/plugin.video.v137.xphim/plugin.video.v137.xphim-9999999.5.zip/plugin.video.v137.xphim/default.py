#!/usr/bin/env python
# -*- coding: utf-8 -*-

maintenance = False

import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import cookielib, HTMLParser, json, os, re, random, requests, string, sys, urllib, urllib2, urlparse
from bs4 import BeautifulSoup
from bs4 import SoupStrainer
requests.packages.urllib3.disable_warnings()
# GET PLUGIN PARAMETERS
domain = 'https://xphim.vn'
siteName = 'xPhim.vn'
addon = xbmcaddon.Addon()
addonId = addon.getAddonInfo('id')
addonBase = sys.argv[0]
addonHandle = int(sys.argv[1])
pluginArgs = urlparse.parse_qs(sys.argv[2][1:])
addonPath = xbmc.translatePath(addon.getAddonInfo('path'))
icon = os.path.join(addonPath, 'icon.png')
# os.path.join(addonPath, 'fanart.jpg')
fanart = 'https://v137.xyz/py/v137/img/xphim_02.jpg'
#fanart        = os.path.join(addonPath, 'fanart.jpg')
icons = {
    'alpha': 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_sort_by_alpha_white_48dp.png',
    'compass': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_explore_white_48dp.png',
    'genres': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_class_white_48dp.png',
    'globe': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_language_white_48dp.png',
    'hd': 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_hd_white_48dp.png',
    'history': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_history_white_48dp.png',
    'hot': 'https://github.com/google/material-design-icons/raw/master/social/drawable-xxxhdpi/ic_whatshot_white_48dp.png',
    'intheatres': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_theaters_white_48dp.png',
    'movies': 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_creation_white_48dp.png',
    'new': 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_fiber_new_white_48dp.png',
    'nextpage': 'https://github.com/google/material-design-icons/raw/master/navigation/drawable-xxxhdpi/ic_last_page_white_48dp.png',
    'pinwheel': 'https://github.com/google/material-design-icons/raw/master/hardware/drawable-xxxhdpi/ic_toys_white_48dp.png',
    'popular': 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_remove_red_eye_white_48dp.png',
    'search': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_search_white_48dp.png',
    'series': 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_filter_white_48dp.png',
    'settings': 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_settings_white_48dp.png',
    'sofa': 'https://github.com/google/material-design-icons/raw/master/content/drawable-xxxhdpi/ic_weekend_white_48dp.png',
    'star': 'https://github.com/google/material-design-icons/raw/master/toggle/drawable-xxxhdpi/ic_star_white_48dp.png',
    'warning': 'https://github.com/google/material-design-icons/raw/master/alert/drawable-xxxhdpi/ic_warning_white_48dp.png'
}
userPath = xbmc.translatePath(addon.getAddonInfo('profile'))

resolution = {
	16: 'FULL',
	15: '1080',
	14: '720',
	13: 'HD',
	12: 'HQ',
	11: '576',
	10: '540',
	9: 'MQ',
	8: '480',
	7: '360',
	6: 'SD',
	5: 'Auto',
	4: '240',
	3: 'LQ',
	2: 'LOW',
	1: 'LOWEST',
	0: 'MOBILE',
}
maxhistory = 25


# ##################################################################################### #

view_mode = '0'
if view_mode == '1':
	if xbmc.getSkinDir() == 'skin.estuary':
		viewmode = '54'
	elif xbmc.getSkinDir() == 'skin.supernova.nova':
		viewmode = '53'
	elif xbmc.getSkinDir() == 'skin.heidi':
		viewmode = '53'
	else:
		viewmode = '50'
	contenttype = 'Movies'
else:
	viewmode = '50'
	contenttype = 'Files'

# ##################################################################################### #


if not os.path.exists(userPath):
	os.makedirs(userPath)


# PERSIST COOKIES ACROSS SESSIONS
cookieJar = os.path.join(userPath, 'cookiejar.lwp')
cj = cookielib.LWPCookieJar(cookieJar)
if not os.path.exists(cookieJar):
	cj.save()
else:
	try:
		cj.load(ignore_discard=True)
	except:
		os.remove(cookieJar)
		cj.save()

s = requests.session()
userAgent = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'
html_parser = HTMLParser.HTMLParser()


# GET PLUGIN PARAMETERS
try:
	mode = pluginArgs['mode'][0]
except:
	mode = None
try:
	url = pluginArgs['url'][0]
except:
	url = ''
try:
	title = pluginArgs['title'][0]
except:
	title = ''
try:
	image = pluginArgs['image'][0]
except:
	image = ''
try:
	extra = pluginArgs['extra'][0]
except:
	extra = None


# ##################################################################################### #


def ParseLink(query):
	return addonBase + '?' + urllib.urlencode(query)


def AddDir(mode, url, title, image, extra=None, folder=True, playable=False, year='', rating='', genre='', plot='', context=None, contextReplace=False):
	try:
		url = url.encode('utf-8')
	except:
		pass
	try:
		title = title.encode('utf-8')
	except:
		pass
	try:
		image = image.encode('utf-8')
	except:
		pass
	try:
		extra = extra.encode('utf-8')
	except:
		pass
	try:
		year = year.encode('utf-8')
	except:
		pass
	try:
		genre = genre.encode('utf-8')
	except:
		pass
	try:
		plot = plot.encode('utf-8')
	except:
		pass
	li = xbmcgui.ListItem(title, iconImage=image, thumbnailImage=image)
	li.setProperty('fanart_image', fanart)
	# SETS PLAYABLE ITEM / NON-FOLDER
	if playable:
		li.setProperty('IsPlayable', 'true')
	li.setInfo(type='video', infoLabels={
	           'year': year, 'rating': rating, 'genre': genre, 'plot': plot})
	# ADD CONTEXT MENU ITEMS
	if context:
		li.addContextMenuItems(context, replaceItems=contextReplace)
	link = ParseLink({'mode': mode, 'url': url, 'title': title,
                   'image': image, 'extra': extra})
	xbmcplugin.addDirectoryItem(
		handle=addonHandle, url=link, listitem=li, isFolder=folder)


def EndDir(cache=True, contentType='Files', viewMode=50):
	# SET VIEW MODE
	xbmcplugin.setContent(addonHandle, contentType)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewMode)
	# END DIR
	xbmcplugin.endOfDirectory(addonHandle, cacheToDisc=cache)


def SetResolved(url, title='', image=''):
	listItem = xbmcgui.ListItem(title, path=url, thumbnailImage=image)
	if any(ext in url for ext in ['.mkv', '.mp4']):
		listItem.setContentLookup(False)
		listItem.setMimeType('video/mp4')
	xbmcplugin.setResolvedUrl(addonHandle, True, listItem)


def Request(url,
            params='',
            getredir=False,
            post=False,
            data=None,
            useragent=userAgent,
            referer='',
            extheaders=None,
            usecookies=True,
            getcookies=False,
            encoding='utf-8',
            minify=False,
            soup=False,
            strainer=None,
            cloudflare=False
            ):
	headers = {
		'User-Agent': useragent,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate, sdch',
		'Referer': referer
	}
	if extheaders:
		headers.update(extheaders)
	try:
		if usecookies:
			s.cookies = cj
		if not getredir:
			xbmc.log('| Getting URL | %s%s%s' % (url, ' | ' +
                                        params if params is not '' else '', ' | ' + data if data is not None else ''))
			if cloudflare:
				from resources.lib.modules import cloudflare as CloudFlare
				r = CloudFlare.source(url)
				src = r.decode('utf-8')
			else:
				if post:
					r = s.post(url=url, params=params, headers=headers, data=data, timeout=(3.05, 15), verify=False)
				else:
					r = s.get(url=url, params=params, headers=headers, timeout=(3.05, 15), verify=False)
				r.encoding = encoding
				src = r.text
				# xbmc.log(src.encode('utf8'), 7)
				
			if soup:
				src = re.sub('(<!\[CDATA\[.+?\]\]\>)', '', src)
				replacements = [('h"+"tml', 'html'), ('ht"+"ml', 'html'), ('htm"+"l', 'html'), ('b"+"ody', 'body'), ('bo"+"dy', 'body'), ('bod"+"y', 'body'),
                                    ("s'+'cript", "script"), ("sc'+'ript", "script"), ("scr'+'ipt", "script"), ("scri'+'pt", "script"), ("scrip'+'t", "script")]
				for rep in replacements:
					src = src.replace(rep[0], rep[1])
				response = BeautifulSoup(src, 'html5lib', parse_only=strainer)
			else:
				if minify:
					response = Minify(src)
				else:
					response = src
		else:
			# Make a head request (no body), allowing redirect and getting the redirected URL
			r = s.get(url=url, headers=headers, stream=True, timeout=(3.05, 15), verify=False)
			response = r.url
			status = r.history
			if any(s in str(status) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
				xbmc.log('| %s Redirection | %s' % (status, response))
		if getcookies:
			try:
				cj.save()
			except:
				pass
			return response, r.cookies
		else:
			if usecookies:
				try:
					cj.save()
				except:
					pass
			return response
	except Exception, e:
		xbmc.log('| ERROR | %s' % e)


def Minify(src):
	src = ''.join(src.splitlines()).replace('\'', '"')
	src = src.replace('\n', '')
	src = src.replace('\t', '')
	src = re.sub('  +', ' ', src)
	src = src.replace('> <', '><')
	return src


# ##################################################################################### #


def Home():
	if maintenance:
		xbmcgui.Dialog().ok('[COLOR deepskyblue][B]CHÚ Ý / ATTENTION[/B][/COLOR]', '[COLOR white][B]Trang web tạm đang có lỗi kỹ thuật.[/B][/COLOR]',
                      '[COLOR white][B]Website is temporarily having technical difficulties.[/B][/COLOR]')
	AddDir('HISTORY', domain + '/keywords/search.html',
	       '[COLOR cyan][B][ Tìm Kiếm ][/B][/COLOR]', icons['search'])
	AddDir('INDEX', domain + '/Theloai/5892df562c47de357c5ce704/P%s/phim-le.html',
	       '[COLOR white][B]Phim Lẻ[/B][/COLOR]', icons['movies'])
	AddDir('INDEX', domain + '/Theloai/5892df522c47de357c5ce703/P%s/phim-bo.html',
	       '[COLOR white][B]Phim Bộ[/B][/COLOR]', icons['series'])
	AddDir('INDEX', domain + '/Theloai/589074822c47de2fa08367d5/P%s/phim-chieu-rap.html',
	       '[COLOR white][B]Phim Chiếu Rạp[/B][/COLOR]', icons['intheatres'])
	AddDir('INDEX', domain, '[COLOR white][B]Phim Mới[/B][/COLOR]', icons['new'])
	AddDir('INDEX', domain + '/Theloai/58906f362c47de2fa08367c1/P%s/hanh-dong.html',
	       '[COLOR white][B]Phim Hành Động[/B][/COLOR]', icons['genres'])
	AddDir('INDEX', domain + '/Theloai/58906f652c47de2fa08367c3/P%s/tam-ly.html',
	       '[COLOR white][B]Phim Tâm Lý[/B][/COLOR]', icons['genres'])
	AddDir('INDEX', domain + '/Theloai/58906f3d2c47de2fa08367c2/P%s/vo-thuat.html',
	       '[COLOR white][B]Phim Võ Thuật[/B][/COLOR]', icons['genres'])
	AddDir('INDEX', domain + '/Theloai/58906fb72c47de2fa08367c7/P%s/phim-ma---kinh-di.html',
	       '[COLOR white][B]Phim Ma - Kinh Dị[/B][/COLOR]', icons['genres'])
	AddDir('INDEX', domain + '/Theloai/58906f6a2c47de2fa08367c4/P%s/phim-hai.html',
	       '[COLOR white][B]Phim Hài Hước[/B][/COLOR]', icons['genres'])
#	AddDir('INDEX', domain + '/Theloai/5895aa9fbb8cba0c30d224bf/P%s/trailer-phim-moi.html', '[COLOR deepskyblue][B]Trailers[/B][/COLOR]', icons['sofa'])
#	AddDir('TOP', domain, '[COLOR deepskyblue][B]Phim Lẻ Xem Nhiều Trong Tuần[/B][/COLOR]', icons['hot'])
#	AddDir('SUBMENUS', domain, '[COLOR deepskyblue][B]+ Phim Theo Quốc Gia[/B][/COLOR]', icons['globe'])
#	AddDir('SUBMENUS', domain, '[COLOR deepskyblue][B]+ Phim Theo Thể Loại[/B][/COLOR]', icons['genres'])
#	AddDir('SETTINGS', '', '[COLOR cyan][B]Settings[/B][/COLOR]', icons['settings'], folder=False)
	EndDir(viewMode=50, cache=True)


def Submenus(url, category, image):
	soup = Request(domain, soup=True)
	submenus = soup.select('.sub')
	for menu in submenus:
		header = menu.parent.find('a').get_text()
		header = header.strip().title()
		if header.lower() in category.lower():
			url = menu.parent.find('a')['href']
			if 'javascript' not in url:
				if url.startswith('http'):
					pass
				elif url.startswith('/'):
					url = domain + url
				else:
					url = domain + '/' + url
				AddDir('INDEX', url,
				       '[COLOR white][B]Tất Cả %s[/B][/COLOR]' % header, image)
			items = menu.select('li')
			for item in items:
				title = item.find('a').text.title()
				url = item.find('a')['href']
				url = domain + url if url.startswith('/') else url
				url = url + ('trang-1.html' if url.endswith('/') else '/trang-1.html')
				AddDir('INDEX', url, '[COLOR white][B]%s[/B][/COLOR]' % title, image)
			EndDir(viewMode=50)


def Top(url, category):
	if 'Phim Lẻ' in category:
		category = 'lew'
	if 'Phim Bộ' in category:
		category = 'bơ'
	if 'Anime' in category:
		category = 'anime'
	soup = Request(domain, soup=True)
	submenus = soup.select('.list-film-simple')
	for menu in submenus:
		try:
			header = str(menu.parent['data-name'])
		except:
			pass
		else:
			if category.lower() in header.lower():
				items = menu.select('.item')
				for item in items:
					pos = item.find(class_='st').text
					title = item.find(class_='name').text.strip()
					image = item.find('img')['src']
					url = item.find('a')['href']
					url = domain + url if url.startswith('/') else url
					AddDir('MIRRORS', url,
					       '[COLOR cyan][B]%s.[/B][/COLOR] [COLOR white][B]%s[/B][/COLOR]' % (pos, title), image)
				EndDir(viewMode=50)


def History(url):
	#	if True: # DEBUG #
	try:
		history = eval(addon.getSetting('history'))
		if len(history) == 0:
			raise
	except:
		history = '[]'
		addon.setSetting('history', history)
		Search(url, history)
	else:
		contextMenu = [('[COLOR white][B]XÓA TẤT CẢ[/B][/COLOR]',
		                'XBMC.Container.Update(plugin://%s?mode=CLEAR)' % addonId)]
		AddDir('SEARCH', url, '[COLOR white][B]TÌM KIẾM MỚI[/B][/COLOR]',
		       icons['search'], extra=history, context=contextMenu)
		for i, searchText in enumerate(reversed(history)):
			num = abs(i+1-len(history))
			searchText = urllib.unquote(searchText)
			contextMenu = [
				('[COLOR white][B]XÓA HÀNG[/B][/COLOR]',
				 'XBMC.Container.Update(plugin://%s?mode=CLEAR&extra=%d)' % (addonId, num)),
				('[COLOR white][B]XÓA TẤT CẢ[/B][/COLOR]',
				 'XBMC.Container.Update(plugin://%s?mode=CLEAR)' % addonId)
			]
			AddDir('INDEX', url.replace('keywords', urllib.quote_plus(searchText)),
			       '[COLOR cyan][B]%s[/B][/COLOR]' % searchText, icons['history'], context=contextMenu)
		EndDir(viewMode=50)


def Search(url, history):
	#	if True: # DEBUG #
	try:
		keyb = xbmc.Keyboard('', '[COLOR white][B]Nhập từ khóa để tìm:[/B][/COLOR]')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote(keyb.getText())
			if not searchText == '':
				try:
					history = eval(history)
					if len(history) >= maxhistory:
						del history[0]
					history.append(searchText)
					addon.setSetting('history', repr(history))
				except:
					pass
				url = url.replace('keywords', urllib.quote_plus(searchText))
				xbmc.log('| Search | %s' % searchText)
				Index(url)
	except:
		pass


def Clear(num):
	if num:
		history = eval(addon.getSetting('history'))
		del history[int(num)]
	else:
		history = []
	addon.setSetting('history', repr(history))
	if len(history) == 0:
		AddDir('SEARCH', url, '[COLOR white][B]TÌM KIẾM MỚI[/B][/COLOR]',
		       icons['search'], extra=history)
		EndDir(viewMode=50)
	else:
		xbmc.executebuiltin('Container.Refresh')


def Index(url):
	if '%s' in url:
		url = url.replace('%s', '1')
	soup = Request(url, soup=True)
	videoList = soup.select('.item-phim-normal')
	for video in videoList:
		#		if True: # DEBUG #
		try:
			vurl = video.find('a')['href']
			vimage = video.find('img')['src']
			vtitle = video.select('.title-phim-viet')[0].text.strip()
			try:
				vtags = video.select('.title-phim-khac')[0].text.strip()
			except:
				vtags = ''
			vtitle2 = ''
			vyear = ''
			vrating = ''
			vgenre = ''
			vplot = ''
#			if True: # DEBUG #
			try:
				vinfo = video['data-title']
				vinfo = BeautifulSoup(vinfo, 'html5lib')
				vtitle2 = vinfo.find(class_='title-tooltip-2').text.strip()
#				vrating = vinfo.find(class_='danhgia-tooltip').find('span').text.strip()
				vplot = vinfo.find(class_='gioithieu-phim-tooltip').text.strip()
				vinfo2 = vinfo.find_all(class_='div_theloai')
				for v in vinfo2:
					values = str(v).decode('utf-8')
					if u'Thể loại' in values:
						vgenre = v.text.strip()
#					if u'Diễn viên' in values:
#						vactors   = v.text.strip()
#					if u'Đạo diễn' in values:
#						vdirector = v.text.strip()
					if u'Năm sản xuất' in values:
						vyear = v.text.strip()
			except:
				pass
			# Encode and reformat
			vtags = vtags.replace(u'Lồng tiếng', u'Lồng Tiếng').replace(u'HD Thuyết Minh', u'Thuyết Minh').replace(u'HD - Thuyết Minh', u'Thuyết Minh').replace(u'HD Thuyết minh', u'Thuyết Minh').replace(u'HD - Thuyết minh', u'Thuyết Minh').replace(u'Thuyết minh',
                                                                                                                                                                                                                                               u'Thuyết Minh').replace(u'Full Vietsub', u'Phụ Đề').replace(u'Full VietSub', u'Phụ Đề').replace(u'HD Vietsub', u'Phụ Đề').replace(u'HD VietSub', u'Phụ Đề').replace(u'Vietsub', u'Phụ Đề').replace(u'VietSub', u'Phụ Đề').replace(u'BẢN ĐẸP', '').strip()
			vtags2 = vtags.replace(u'Lồng Tiếng', u'LT').replace(
				u'Thuyết Minh', u'TM').replace(u'Phụ Đề', u'PD').strip()
			if vtags2:
				vtags2 = ' [COLOR cyan][B](%s)[/B][/COLOR]' % vtags2
				if vtitle2:
					vtitle2 = ' [COLOR grey][B]%s[/B][/COLOR]' % html_parser.unescape(vtitle2)
			else:
				if vtitle2:
					vtitle2 = ' [COLOR cyan][B]/[/B][/COLOR] [COLOR grey][B]%s[/B][/COLOR]' % html_parser.unescape(
						vtitle2)
			vtitle = '[COLOR white][B]%s[/B][/COLOR]%s%s' % (vtitle, vtags2, vtitle2)
			vurl = domain + vurl if vurl.startswith(u'/') else vurl
			try:
				vimage = vimage.decode('utf-8').encode('utf-8')
			except:
				vimage = icon
#			vrating = float(vrating.replace(u' điểm', ''))*2
			vyear = vyear.replace(u'Năm sản xuất : ', '')
			vplot = '%s\n\n[COLOR cyan][B]%s[/B][/COLOR]' % (vplot, vtags)
			AddDir('EPISODES', vurl, vtitle, vimage, year=vyear,
			       rating=vrating, genre=vgenre, plot=vplot, extra=vtitle)
		except:
			pass
	Pagination(url, soup)
	if '/search.html' in url:
		if len(videoList) == 0:
			AddDir('', '', '[COLOR white][B]Tìm kiếm không có kết quả.[/B][/COLOR]',
			       icons['warning'], folder=False)
			AddDir('', '', '[COLOR cyan][B]Vui lòng bấm nút RETURN để quay trở lại.[/B][/COLOR]',
			       icons['warning'], folder=False)
		EndDir(viewMode=50)
	else:
		EndDir(contentType=contenttype, viewMode=viewmode)


def Pagination(url, soup):
	#	if True: # DEBUG #
	try:
		pagination = soup.find(class_='pagination')
		if 'chevron-right' in str(pagination):
			if '/P' in url:
				pageNumber = int(re.compile('/P(\d+)').findall(url)[0])
				url = url.replace('%s' % pageNumber, '%s' % str(pageNumber+1))
			else:
				url = url + 'P2' if url.endswith('/') else url
			url = domain + url if url.startswith(u'/') else url.encode('utf-8')
			AddDir('INDEX', url,
			       '[COLOR cyan][B]Trang kế[/B][/COLOR] [COLOR cyan][B]>>[/B][/COLOR]', icons['nextpage'])
	except:
		pass


def Info(url):
	return True


def Episodes(url, title, image):
	soup = Request(url, soup=True)
#	if True: # DEBUG #
	try:
		episodes = soup.find_all(class_='lst-tap')[-1]
		epList = episodes.find_all('li')
		if len(epList) <= 1:
			raise
		else:
			for episode in epList:
				eurl = episode.find('a')['href']
				etitle = episode.string
				# Encode and reformat
				eurl = domain + eurl if eurl.startswith(u'/') else eurl.encode('utf-8')
				etitle = etitle.replace(u'Tập ', '').encode('utf-8')
				AddDir('MIRRORS', eurl, '[COLOR cyan][B]Tập:[/B][/COLOR] [COLOR white][B]%s[/B][/COLOR]' % etitle, image, extra=title, context=[
				       ('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % eurl)])
			EndDir(contentType='Files', viewMode=50)
	except:
		xbmc.log('| No episodes |')
		Mirrors(url, title, image, src=soup)


def Mirrors(url, title, image, src=None):
	if mode == 'EPISODES':
		soup = src
	else:
		soup = Request(url, soup=True)
#	if True: # DEBUG #
	try:
		mirrors = soup.find_all(class_='lst-tap')[0]
#		xbmc.log(mirrors)
		mList = mirrors.find_all('li')
		if len(mList) > 1:
			xbmc.log('| %s mirrors |' % len(mList))
			for mirror in mList:
				murl = mirror.find('a')['href']
				mtitle = mirror.string.strip()
				# Encode and reformat
				murl = domain + murl if murl.startswith(u'/') else murl.encode('utf-8')
				mtitle = mtitle.replace(u'-', ' - ').replace(u'  ', ' ').encode('utf-8')
				AddDir('PLAY', murl, '[COLOR cyan][B]Nguồn:[/B][/COLOR] [COLOR white][B]%s[/B][/COLOR]' % mtitle, image, extra=title, folder=False, playable=True,
				       context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % murl)])
			EndDir(contentType='Files', viewMode=50)
		else:
			raise
	except:
		xbmc.log('| No mirrors |')
		Play(url, title, image)


def Play(url, title, image, src=None):
	dialog = xbmcgui.DialogProgress()
	dialog.create('[COLOR cyan][B]%s[/B][/COLOR]' %
	              siteName, '[COLOR white][B]Đang tải phim...[/B][/COLOR]')
	if dialog.iscanceled():
		sys.exit()  # KILL #
	if src is not None:
		link = Resolve(src)
	else:
		link = Resolve(url)
	try:
		xbmc.log('| Resolved URL | %s' % link)
	except:
		pass
	title = re.sub('(\[COLOR.+?\])', '', title).replace('[/COLOR]',
                                                     '').replace('[B]', '').replace('[/B]', '')
	if dialog.iscanceled():
		sys.exit()  # KILL #
	if mode == 'PLAY':
		SetResolved(link, title, image)
	else:
		listItem = xbmcgui.ListItem(title, thumbnailImage=image)
		if any(ext in link for ext in ['.mkv', '.mp4']):
			listItem.setContentLookup(False)
			listItem.setMimeType('video/mp4')
		xbmc.Player().play(link, listitem=listItem)
	if dialog.iscanceled():
		sys.exit()  # KILL #
	dialog.close()
	del dialog


def Resolve(url):
	if 'youtube.com' in url:
		return YouTube(url)

	if url.startswith('http'):
		src = Request(url, referer=domain)
	else:
		src = url
#	xbmc.log(soup)
#	if True: # DEBUG #
	try:
		sources = re.compile('lst_sources\s?=\s?(\[.+?\])').findall(src)[0]
		# xbmc.log(sources)
		sources = json.loads(sources)
		links = []
		for source in sources:
			label = source['label']
			link = source['file']
			links.append((label, link))
		src = ChooseRes(links)
		src = src.replace('\/', '/').replace('&amp;', '&')
	except:
		try:
			source = re.compile('var phim\s?=\s?({.+?})').findall(src)[0]
			data = re.compile("chap\s?:\s?'(.+?)'").findall(source)[0]
			data = "{'sIDChap': '%s'}" % data
			extheaders = {'Content-Type': 'application/json; charset=utf-8',
                            'X-Requested-With': 'XMLHttpRequest'}
			sources = Request('%s/WebService.asmx/getContentEmbed' %
			                  domain, post=True, referer=url, extheaders=extheaders, data=data)
#			xbmc.log(sources)
			src = eval(sources)['d'].decode('unicode-escape')
		except:
			xbmcgui.Dialog().ok('[COLOR cyan][B]Xin lỗi[/B][/COLOR]', '[COLOR white][B]Phim hiện không xem được[/B][/COLOR]',
                            '[COLOR white][B]Xin vui lòng thử phim khác[/B][/COLOR]', '[COLOR cyan][B]-- No links parsed --[/B][/COLOR]')
			return ''
	finally:
		src = FormatUrl(src, domain)
		if siteName.lower() in src.lower():
			src = '%s|Referer=%s' % (src, url)
		if 'youtube.googleapis.' in src:
			src = GoogleDocs(src)
		elif 'youtube.com' in src:
			src = YouTube(src)
		elif 'fembed.' in src:
			src = Fembed(src)
		elif 'ok.ru' in src:
			src = OKRU(src)
		elif any(domain in src for domain in ['rapidvideo', ]):
			xbmc.log("Dectected rapidvideo")
			from v137 import v137
			src = v137.Resolver(src)
		elif any(domain in src for domain in ['oload.', 'openload.', 'fembed.', ]):
			src = UrlResolver(src)
		return src


# ##################################################################################### #


def FormatUrl(url, domain=''):
	if not url:
		return domain
	url = url.strip()
	url = url.replace('\/', '/')
	if url.startswith('http') or url.startswith('rtmp'):
		return url
	elif url.startswith('//'):
		return 'http://%s' % url.lstrip('//')
	elif url.startswith('/'):
		return '%s/%s' % ('%s://%s' % (urlparse.urlparse(domain).scheme, urlparse.urlparse(domain).netloc), url.lstrip('/'))
	else:
		if domain.count('/') > 2:
			return '%s/%s' % (domain.rsplit('/', 1)[0], url.lstrip('/'))
		else:
			return '%s/%s' % (domain, url)


def ChooseRes(src, maxres=15):
	# Forces order: 0. Label, 1. Link
	src2 = []
	if '//' in str(src[0][0]):
		for link, label in src:
			src2.append((label, link))
	else:
		src2 = src
	# Passes single Link
	if len(src2) == 1:
		return src2[0][1]
	else:
		# Auto chooses maximum resolution from settings
		for res in reversed(range(len(resolution))):
			if res <= maxres:
				for i, (label, link) in enumerate(src2):
					if resolution[res].upper() in str(label).upper():
						return link
	# Prompts user to choose resolution
		labels = [('[COLOR white][B]%s[/B][/COLOR]' % label) for label, link in src2]
		dialog = xbmcgui.Dialog()
		prompt = -1
		prompt = dialog.select('Choose / Chọn:', labels)
		if prompt == -1:
			link = None
		else:
			link = src2[prompt][1]
		return link


class UnWise:
	def worker(self, str_eval):
		page_value = ""
		try:
			ss = "w,i,s,e=("+str_eval+')'
			exec(ss)
			page_value = self.__unwise(w, i, s, e)
		except:
			return
		return page_value

	def __unwise(self,  w, i, s, e):
		lIll = 0
		ll1I = 0
		Il1l = 0
		ll1l = []
		l1lI = []
		while True:
			if (lIll < 5):
				l1lI.append(w[lIll])
			elif (lIll < len(w)):
				ll1l.append(w[lIll])
			lIll += 1
			if (ll1I < 5):
				l1lI.append(i[ll1I])
			elif (ll1I < len(i)):
				ll1l.append(i[ll1I])
			ll1I += 1
			if (Il1l < 5):
				l1lI.append(s[Il1l])
			elif (Il1l < len(s)):
				ll1l.append(s[Il1l])
			Il1l += 1
			if (len(w) + len(i) + len(s) + len(e) == len(ll1l) + len(l1lI) + len(e)):
				break

		lI1l = ''.join(ll1l)
		I1lI = ''.join(l1lI)
		ll1I = 0
		l1ll = []
		for lIll in range(0, len(ll1l), 2):
			ll11 = -1
			if (ord(I1lI[ll1I]) % 2):
				ll11 = 1
			l1ll.append(chr(int(lI1l[lIll: lIll+2], 36) - ll11))
			ll1I += 1
			if (ll1I >= len(l1lI)):
				ll1I = 0
		ret = ''.join(l1ll)
		if 'eval(function(w,i,s,e)' in ret:
			ret = re.compile('eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0]
			return self.worker(ret)
		else:
			return ret


def UrlResolver(url):
	if '/preview' in url:
		url = url.split('/preview')[0]
	try:
		import urlresolver
		link = urlresolver.resolve(url)
		if link == False:
			raise
	except:
		if any(domain in url for domain in ['oload.', 'openload.']):
			link = PopoutFrame(url)
	return link


def PopoutFrame(url):
	url = str(url.encode('utf-8'))
	rnd = ''.join(random.SystemRandom().choice(
		string.ascii_uppercase + string.digits) for _ in range(500))
	xbmcgui.Dialog().ok('HƯỚNG DẪN / INSTRUCTIONS', 'Bấm nút PLAY hai lần với con chuột để xem...',
                     'Press PLAY button twice with mouse to watch...')
	xbmc.executebuiltin(
		'StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","http://v137.xyz/p/if?r='+rnd+'&src='+url+'")')
	return ''


def OKRU(baseurl):
	baseurl = baseurl.replace('/video/', '/videoembed/')
	try:
		soup = Request(baseurl, soup=True)
		src = soup.find('div', {'data-module': 'OKVideo'})['data-options']
		j = json.loads(json.loads(src)['flashvars']['metadata'])
		sources = j['videos']
		links = []
		for source in sources:
			links.append((source['name'], source['url']))
		link = ChooseRes(links, maxres=11)
		link = '%s|Referer=%s' % (link, baseurl)
		return link
	except:
		return baseurl


def Fembed(baseurl):
	id = re.compile('/v/(.+)').findall(baseurl)[0]
	html = Request('https://www.fembed.com/api/sources/%s' %
	               id, referer=baseurl, post=True)
	try:
		j = json.loads(html)
		sources = j['data']
		links = []
		for source in sources:
			links.append((source['label'], source['file']))
		link = ChooseRes(links)
		link = '%s|Referer=%s' % (link, baseurl)
		return link
	except:
		xbmc.log(html.encode('utf-8'))
		return baseurl


def GoogleDocs(url):
	xbmc.log('| GOOGLE DOCS | %s' % url)
	gd_bug = 0  # 0 = None | 1 = Basic | 2 = Detailed
	gd_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
	gd_session = requests.session()
	gd_headers = {
		'User-Agent': gd_agent,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate, sdch'
	}
	# Resolve redirect if GoogleUserContent
	if 'googleusercontent.' in url:
		# Get final URL
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url, headers=gd_headers, stream=True, verify=False)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			url = r.url
			if gd_bug >= 1:
				xbmc.log('| GD: REDIRECTION | %s' % url)
	# Extract video ID
	if 'open?id=' in url:
		id = re.compile('open\?id=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'docid=' in url:
		id = re.compile('docid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'driveid=' in url:
		id = re.compile('driveid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif '/file/d/' in url:
		id = re.compile('/file/d/(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	else:
		id = None
	if id:
		url = 'https://docs.google.com/leaf?id=%s' % id
	else:
		return url
	# Initial request
	try:
		if gd_bug >= 1:
			xbmc.log('| GD: REQUEST | %s' % url)
		r = gd_session.get(url=url, headers=gd_headers, verify=False)
		r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&', ';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2:
			xbmc.log('| GD: COOKIE | %s' % s)
		if gd_bug >= 2:
			xbmc.log(src)
	except Exception, e:
		xbmc.log('| ERROR | %s' % str(e))
		src = ''
		cookie = ''
	resolved = ''
	# Method 1: parse JSON data
	if 'fmt_stream_map' in src:
		links = re.compile('(\["fmt_stream_map",.+?\])').findall(src)[0]
		links = re.compile('(\d+)\|(.+?)[,|"|\]]').findall(links)
		if gd_bug >= 2:
			xbmc.log(links)
		labels = re.compile('(\["fmt_list",.+?\])').findall(src)[0]
		labels = re.compile('["|,](\d+)/.+?x(.+?)/').findall(labels)
		if gd_bug >= 2:
			xbmc.log(labels)
		links2 = []
		for i, (linkdigit, link) in enumerate(links):
			for labeldigit, label in labels:
				if labeldigit == linkdigit:
					links2.append((label, link))
			resolved = ChooseRes(links2)
		if resolved:
			resolved = resolved.decode('unicode-escape') + '|Cookie=%s' % cookie
	# Method 2: get download link
	if not 'fmt_stream_map'in src or not resolved:
		url2 = 'https://drive.google.com/uc?id=%s&export=download' % id
		if gd_bug >= 1:
			xbmc.log('| GD: REQUEST | %s' % url2)
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url2, headers=gd_headers, verify=False)
		r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&', ';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2:
			xbmc.log('| GD: COOKIE | %s' % s)
		if gd_bug >= 2:
			xbmc.log(src)
		url3 = re.compile('<a id="uc-download-link".+?href="(.+?)">').findall(src)[0]
		url3 = url3.replace('&amp;', '&')
		url3 = 'https://drive.google.com%s' % url3 if not url3.startswith(
			'http') else url3
		# Get final URL
		if gd_bug >= 1:
			xbmc.log('| GD: REDIRECTION | %s' % url3)
		gd_headers.update({'Referer': url2})
		r = gd_session.head(url=url3, headers=gd_headers, allow_redirects=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			resolved = r.url
		else:
			if gd_bug >= 1:
				xbmc.log('| GD: NO REDIRECT |')
			resolved = url3
	if gd_bug >= 1:
		xbmc.log('| GD: RESOLVED | %s' % resolved)
	return resolved


def YouTube(url):
	if 'watch?v=' in url:
		youtubeID = re.compile('watch\?v=(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/embed/' in url:
		youtubeID = re.compile('/embed/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/v/' in url:
		youtubeID = re.compile('/v/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	else:
		if url.startswith('http'):
			return url
		else:
			return ''
	return 'plugin://plugin.video.youtube/play/?video_id=%s' % youtubeID


# ##################################################################################### #


if mode == 'INDEX':
	Index(url)
elif mode == 'SUBMENUS':
	Submenus(url, title, image)
elif mode == 'TOP':
	Top(url, title)
elif mode == 'HISTORY':
	History(url)
elif mode == 'SEARCH':
	Search(url, extra)
elif mode == 'CLEAR':
	Clear(extra)
elif mode == 'EPISODES':
	if Info(url):
		Episodes(url, extra, image)
elif mode == 'MIRRORS':
	Mirrors(url, extra, image)
elif mode == 'PLAY':
	Play(url, extra, image)
elif mode == 'LOADVIDEO':
	LoadVideo(url)
elif mode == 'SETTINGS':
	xbmc.executebuiltin('Addon.OpenSettings(%s)' % addonId)
else:
	Home()
