#!/usr/bin/env python
# -*- coding: utf-8 -*-

# V137: 2017-07-16

# Use Chrome to get values in key
# Use same userAgent as Chrome / FLASK script
# User agent needs to match

maintenance = False

import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import cookielib, HTMLParser, json, os, re, random, requests, string, sys, urllib, urllib2, urlparse
from six.moves.urllib.parse import quote
from bs4 import BeautifulSoup
from bs4 import SoupStrainer

# GET PLUGIN PARAMETERS
domain        = 'http://tvhay.org'
siteName      = 'TV Hay'
addon         = xbmcaddon.Addon()
addonId       = addon.getAddonInfo('id')
addonBase     = sys.argv[0]
addonHandle   = int(sys.argv[1])
pluginArgs    = urlparse.parse_qs(sys.argv[2][1:])
addonPath     = xbmc.translatePath(addon.getAddonInfo('path'))
icon          = os.path.join(addonPath, 'icon.png')
fanart        = 'https://v137.xyz/py/v137/img/tvhay_01.jpg'
#fanart        = os.path.join(addonPath, 'fanart.jpg')
icons         = {
 'alpha'      : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_sort_by_alpha_white_48dp.png',
 'countries'  : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_explore_white_48dp.png',
 'genres'     : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_class_white_48dp.png',
 'hd'         : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_hd_white_48dp.png',
 'history'    : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_history_white_48dp.png',
 'hot'        : 'https://github.com/google/material-design-icons/raw/master/social/drawable-xxxhdpi/ic_whatshot_white_48dp.png',
 'intheatres' : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_theaters_white_48dp.png',
 'movies'     : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_creation_white_48dp.png',
 'new'        : 'https://github.com/google/material-design-icons/raw/master/av/drawable-xxxhdpi/ic_fiber_new_white_48dp.png',
 'nextpage'   : 'https://github.com/google/material-design-icons/raw/master/navigation/drawable-xxxhdpi/ic_last_page_white_48dp.png',
 'popular'    : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_remove_red_eye_white_48dp.png',
 'search'     : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_search_white_48dp.png',
 'series'     : 'https://github.com/google/material-design-icons/raw/master/image/drawable-xxxhdpi/ic_movie_filter_white_48dp.png',
 'settings'   : 'https://github.com/google/material-design-icons/raw/master/action/drawable-xxxhdpi/ic_settings_white_48dp.png',
 'star'       : 'https://github.com/google/material-design-icons/raw/master/toggle/drawable-xxxhdpi/ic_star_white_48dp.png',
 'warning'    : 'https://github.com/google/material-design-icons/raw/master/alert/drawable-xxxhdpi/ic_warning_white_48dp.png'
}
userPath      = xbmc.translatePath(addon.getAddonInfo('profile'))
maxres        = 1080
resolution    = {4:'1080', 3:'720', 2:'540', 1:'480', 0:'360'}
maxhistory    = 25

# ##################################################################################### #

if not os.path.isdir(userPath):
#	prompt = xbmcgui.Dialog().yesno('Chọn / Choose:','Phong cách hiển thị danh sách phim?','How would you like to display movies?','','List view','Poster view')
#	if prompt:
#		addon.setSetting('view_mode', '1')
#	else:
#		addon.setSetting('view_mode', '0')
	addon.setSetting('view_mode', '0')

view_mode = str(addon.getSetting('view_mode'))
if view_mode == '1':
	if xbmc.getSkinDir() == 'skin.estuary':
		viewmode = '500'
	elif xbmc.getSkinDir() == 'skin.heidi':
		viewmode = '53'
	contenttype = 'Movies'
else:
	viewmode = '50'
	contenttype = 'Files'

# ##################################################################################### #

#if not os.path.exists(userPath):
#	os.makedirs(userPath)

# PERSIST COOKIES ACROSS SESSIONS
cookieJar     = os.path.join(userPath, 'cookiejar.lwp')
cj            = cookielib.LWPCookieJar(cookieJar)
if not os.path.exists(cookieJar):
	cj.save()
else:
	try:
		cj.load(ignore_discard=True)
	except:
		os.remove(cookieJar)
		cj.save()

session       = requests.session()
userAgent     = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0'
html_parser   = HTMLParser.HTMLParser()


# GET PLUGIN PARAMETERS
try:    mode  = pluginArgs['mode'][0]
except: mode  = None
try:    url   = pluginArgs['url'][0]
except: url   = ''
try:    title = pluginArgs['title'][0]
except: title = ''
try:    image = pluginArgs['image'][0]
except: image = ''
try:    extra = pluginArgs['extra'][0]
except: extra = None


# ##################################################################################### #


def ParseLink(query):
	return addonBase + '?' + urllib.urlencode(query)

def AddDir(mode, url, title, image, extra=None, folder=True, playable=False, year='', rating='', genre='', plot='', context=None, contextReplace=False):
	li = xbmcgui.ListItem(title, iconImage=image, thumbnailImage=image)
	li.setProperty('fanart_image', fanart)
	# SETS PLAYABLE ITEM / NON-FOLDER
	if playable:
		li.setProperty('IsPlayable', 'true')
	li.setInfo(type='video', infoLabels={'year': year, 'rating': rating, 'genre': genre, 'plot': plot})
	# ADD CONTEXT MENU ITEMS
	if context:
		li.addContextMenuItems(context, replaceItems=contextReplace)
	link = ParseLink({'mode': mode, 'url': url, 'title': title, 'image': image, 'extra': extra})
	xbmcplugin.addDirectoryItem(handle=addonHandle, url=link, listitem=li, isFolder=folder)

def EndDir(cache=True, contentType='Files', viewMode=50):
	# SET VIEW MODE
	xbmcplugin.setContent(addonHandle, contentType)
	xbmc.executebuiltin('Container.SetViewMode(%s)' % viewMode)
	# END DIR
	xbmcplugin.endOfDirectory(addonHandle, cacheToDisc=cache)

def SetResolved(url, title='', image=''):
	item = xbmcgui.ListItem(title, path=url, thumbnailImage=image)
	xbmcplugin.setResolvedUrl(addonHandle, True, item)

def Request(url,
	params     = '',
	getredir   = False,
	post       = False,
	data       = None,
	useragent  = userAgent,
	referer    = '',
	extheaders = None,
	usecookies = True,
	getcookies = False,
	encoding   = 'utf-8',
	minify     = False,
	soup       = False,
	strainer   = None,
	cloudflare = False
	):
	headers    = {
		'User-Agent'      : useragent,
		'Accept'          : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding' : 'gzip, deflate, sdch',
		'Referer'         : referer
	}
	if extheaders:
		headers.update(extheaders)
#	if True: # DEBUG #
	try:
		if usecookies:
			session.cookies = cj
		if not getredir:
			print('| Getting URL | %s%s%s' % (url, ' | %s' % params if params is not '' else '', ' | %s' % data if data is not None else ''))
			if cloudflare:
				from resources.lib.modules import cloudflare as CloudFlare
				r = CloudFlare.source(url)
				src = r.decode('utf-8')
			else:
				if post:
					r = session.post(url=url, params=params, headers=headers, data=data)
				else:
					r = session.get(url=url, params=params, headers=headers)
				r.encoding = encoding
				src = r.text.encode(encoding)
			if soup:
				src = re.sub('(<!\[CDATA\[.+?\]\]\>)', '', src)
				replacements = [('h"+"tml', 'html'), ('ht"+"ml', 'html'), ('htm"+"l', 'html'), ('b"+"ody', 'body'), ('bo"+"dy', 'body'), ('bod"+"y', 'body'), ("s'+'cript", "script"), ("sc'+'ript", "script"), ("scr'+'ipt", "script"), ("scri'+'pt", "script"), ("scrip'+'t", "script"), ('h" + "tml', 'html'), ('ht" + "ml', 'html'), ('htm" + "l', 'html'), ('b" + "ody', 'body'), ('bo" + "dy', 'body'), ('bod" + "y', 'body'), ("s' + 'cript", "script"), ("sc' + 'ript", "script"), ("scr' + 'ipt", "script"), ("scri' + 'pt", "script"), ("scrip' + 't", "script")]
				for rep in replacements: src = src.replace(rep[0], rep[1])
				response = BeautifulSoup(src, 'html.parser', parse_only=strainer)
			else:
				if minify:
					response = Minify(src)
				else:
					response = src
		else:
			# Make a head request (no body), allowing redirect and getting the redirected URL
			r = session.head(url=url, headers=headers, allow_redirects=True)
			response = r.url
			status = r.history
			if any(s in str(status) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
				print('| %s Redirection | %s' % (status, response))
		if getcookies:
			cj.save()
			return response, r.cookies
		else:
			if usecookies:
				cj.save()
			return response
	except Exception, e:
		print('| ERROR | %s' % e)
		sys.exit()
		xbmcgui.Dialog().ok('[COLOR deepskyblue]ERROR[/COLOR]', '[COLOR white]Server is offline. Please try again later.[/COLOR]')

def Minify(src):
	src = ''.join(src.splitlines()).replace('\'', '"')
	src = src.replace('\n', '')
	src = src.replace('\t', '')
	src = re.sub('  +', ' ', src)
	src = src.replace('> <', '><')
	return src


# ##################################################################################### #


def Home():
	if maintenance:
		xbmcgui.Dialog().ok('[COLOR deepskyblue]CHÚ Ý / ATTENTION[/COLOR]', '[COLOR white]Trang web tạm đang có lỗi kỹ thuật.[/COLOR]', '[COLOR white]Website is temporarily having technical difficulties.[/COLOR]')
	AddDir('INDEX', domain + '/phim-moi/page/%s', '[COLOR white]Phim Mới[/COLOR]', icons['new'])
	AddDir('INDEX', domain + '/phim-le/page/%s', '[COLOR deepskyblue]Phim Lẻ[/COLOR]', icons['movies'])
	AddDir('INDEX', domain + '/phim-bo/page/%s', '[COLOR deepskyblue]Phim Bộ[/COLOR]', icons['series'])
	AddDir('SUBMENUS', domain, '[COLOR steelblue]+ Quốc Gia[/COLOR]', icons['countries'])
	AddDir('SUBMENUS', domain, '[COLOR steelblue]+ Thể Loại[/COLOR]', icons['genres'])
	AddDir('TOP', domain, '[COLOR deepskyblue]Xem Nhiều Trong Ngày[/COLOR]', icons['hot'])
	AddDir('TOP', domain, '[COLOR deepskyblue]Xem Nhiều Trong Tuần[/COLOR]', icons['hot'])
	AddDir('TOP', domain, '[COLOR deepskyblue]Xem Nhiều Trong Tháng[/COLOR]', icons['hot'])
	AddDir('HISTORY', domain + '/search/%s', '[COLOR white][ Tìm Kiếm ][/COLOR]', icons['search'])
	AddDir('SETTINGS', '', '[COLOR white]Settings[/COLOR]', icons['settings'])
	EndDir(viewMode=50)

def Submenus(url, category):
	soup = Request(domain, soup=True)
	submenus = soup.select('.sub-menu')
	for menu in submenus:
		header = menu.parent.find('a').get_text()
		header = header.strip().encode('utf-8')
		if header.lower() in category.lower():
			items = menu.select('li')
			for item in items:
				title = item.find('a').text.encode('utf-8')
				url   = item.find('a')['href'].encode('utf-8')
				url   = domain + url if url.startswith('/') else url
				url   = url + ('page/1' if url.endswith('/') else '/page/1')
				AddDir('INDEX', url, '[COLOR white]%s[/COLOR]' % title, icons['genres'])
			EndDir(viewMode=50)

def Top(url, category):
	if 'Ngày'  in category: category = 'day'
	if 'Tuần'  in category: category = 'week'
	if 'Tháng' in category: category = 'month'
	soup = Request(domain, soup=True)
	submenus = soup.find(id='topview').select('.tab')
	for menu in submenus:
		header = str(menu['class'])
		if category.lower() in header.lower():
			items = menu.select('li')
			for item in items:
				pos   = item.find('span').text.encode('utf-8')
				title = item.find('a')['title'].encode('utf-8')
				url   = item.find('a')['href'].encode('utf-8')
				url   = domain + url if url.startswith('/') else url
				url   = url + ('page/1' if url.endswith('/') else '/page/1')
				AddDir('MIRRORS', url, '[COLOR deepskyblue]%s.[/COLOR] [COLOR white]%s[/COLOR]' % (pos, title), icons['hot'])
			EndDir(viewMode=50)

def History(url):
#	if True: # DEBUG #
	try:
		history = eval(addon.getSetting('history'))
		if len(history) == 0:
			raise
	except:
		history = '[]'
		addon.setSetting('history', history)
		Search(url, history)
	else:
		contextMenu = [('[COLOR white]XÓA TẤT CẢ[/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=CLEAR)' % addonId)]
		AddDir('SEARCH', url, '[COLOR white]TÌM KIẾM MỚI[/COLOR]', icons['search'], extra=history, context=contextMenu)
		for i, searchText in enumerate(reversed(history)):
			num = abs(i+1-len(history))
			searchText = urllib.unquote(searchText)
			contextMenu = [
				('[COLOR white]XÓA HÀNG[/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=CLEAR&extra=%d)' % (addonId, num)),
				('[COLOR white]XÓA TẤT CẢ[/COLOR]', 'XBMC.Container.Update(plugin://%s?mode=CLEAR)' % addonId)
			]
			AddDir('INDEX', url % searchText, '[COLOR deepskyblue]%s[/COLOR]' % searchText, icons['history'], context=contextMenu)
		EndDir(viewMode=50)

def Search(url, history):
#	if True: # DEBUG #
	try:
		keyb = xbmc.Keyboard('', '[COLOR white]Nhập từ khóa để tìm:[/COLOR]')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote(keyb.getText())
			if not searchText == '':
				try:
					history = eval(history)
					if len(history) >= maxhistory: del history[0]
					history.append(searchText)
					addon.setSetting('history', repr(history))
				except:
					pass
				url = url % searchText
				print('| Search | %s' % url)
				Index(url)
	except:
		pass

def Clear(num):
	if num:
		history = eval(addon.getSetting('history'))
		del history[int(num)]
	else:
		history = []
	addon.setSetting('history', repr(history))
	if len(history) == 0:
		AddDir('SEARCH', url, '[COLOR white]TÌM KIẾM MỚI[/COLOR]', icons['search'], extra=history)
		EndDir(viewMode=50)
	else:
		xbmc.executebuiltin('Container.Refresh')

def Index(url):
	if '%s' in url: url = url % 1
	soup = Request(url, soup=True)
	videoList = soup.select('.inner')
	for video in videoList:
#		if True: # DEBUG #
		try:
			vurl    = video.find('a')['href']
			vimage  = video.find('img')['data-original']
			vtitle  = video.select('.name')[0].text.strip()
			vtitle2 = video.select('.name2')[0].text.strip()
			try:    vinfo = video.find(class_='status').text.strip()
			except: vinfo = ''
			try:    vyear = video.find(class_='year').text.strip()
			except: vyear = ''
			# Encode and reformat
			vinfo   = vinfo.replace(u'Lồng Tiếng', 'LT').replace(u'Thuyết Minh', 'TM').replace(u'VietSub', 'PD')
			vinfo   = ' [COLOR deepskyblue](%s)[/COLOR]' % vinfo.encode('utf-8') if not vinfo == '' else ''
			vtitle2 = ' [COLOR steelblue]%s[/COLOR]' % html_parser.unescape(vtitle2).encode('utf-8')
			vyear   = '[COLOR deepskyblue]%s[/COLOR]' % vyear.encode('utf-8')
			vtitle  = '[COLOR white]%s %s[/COLOR]' % (vyear, html_parser.unescape(vtitle.replace('Xem phim ', '')).encode('utf-8')) + vinfo + vtitle2
			vimage  = vimage.encode('utf-8')
			vurl    = domain + vurl.encode('utf-8') if vurl.startswith(u'/') else vurl.encode('utf-8')
			AddDir('MIRRORS', vurl, vtitle, vimage)
		except:
			pass
	Pagination(url, soup)
	if '/search/' in url and len(videoList) == 0:
		AddDir('', '', '[COLOR white]Tìm kiếm không có kết quả.[/COLOR]', icons['warning'], folder=False)
		AddDir('', '', '[COLOR deepskyblue]Vui lòng bấm nút RETURN để quay trở lại.[/COLOR]', icons['warning'], folder=False)

	if '/search' in url:
		EndDir(viewMode=50)
	else:
		EndDir(contentType=contenttype, viewMode=viewmode)

def Pagination(url, soup):
#	if True: # DEBUG #
	try:
		pagination = soup.find(class_='wp-pagenavi').encode('utf-8')
		if '»' in pagination:
			pageNumber = int(re.compile('/(\d+)$').findall(url)[0])
			url = url.replace('%s' % pageNumber, '%s' % str(pageNumber+1))
			AddDir('INDEX', url, '[COLOR deepskyblue]Trang kế[/COLOR] [COLOR steelblue]>>[/COLOR]', icons['nextpage'])
	except:
		pass

def Info(url):
#	if True: # DEBUG #
	try:
		src = Request(url, minify=True)
#		strainer = SoupStrainer(class_='info')
#		soup = BeautifulSoup(src, 'html.parser', parse_only=strainer)
#		image = soup.find('img')['src']
#		title = soup.find('h1').text
#		title2 = soup.find('h3').text
		image = re.compile('<img src="([^"]*)"').findall(src)[1]                 # WORK-AROUND
		title = re.compile('<h1 class="title fr">([^<]*)</h1>').findall(src)[0]  # WORK-AROUND
		info = re.compile('<dt[^>]*>(.+?)</dt><dd[^>]*>(.+?)</dd>').findall(src) # WORK-AROUND
		info2 = ''
		for dt, dd in info:
			dd = re.sub('<a[^>]*>', '', dd)
			dd = re.sub('</a>', '', dd)
			info2 = info2 + ('[COLOR steelblue]%s[/COLOR] [COLOR deepskyblue]%s[/COLOR]' % (dt, dd)) + '\n'
#		strainer2 = SoupStrainer(id='info-film')
#		soup2 = BeautifulSoup(src, 'html.parser', parse_only=strainer2)
#		desc = soup2.text
		desc = re.compile('<div class="tab text">(.+?)</div>').findall(src)[0]   # WORK-AROUND
		desc = re.sub('(<.+?>)', '', desc)                                       # WORK-AROUND
		desc = html_parser.unescape(desc.decode('utf-8'))                        # WORK-AROUND
		desc = desc.strip().replace(':', ': ').replace('"', "'")

		ACTION_MOVE_LEFT     = 1
		ACTION_MOVE_RIGHT    = 2
		ACTION_MOVE_UP       = 3
		ACTION_MOVE_DOWN     = 4
		ACTION_PREVIOUS_MENU = 10
		ACTION_BACK          = 92
		class InfoWindow(xbmcgui.WindowDialog):
			def __init__(self):
				# MAIN WINDOW
				self.window = xbmcgui.ControlImage(x=0, y=0, width=1280, height=720, filename=fanart, aspectRatio=0, colorDiffuse='0xFF666666')
				self.addControl(self.window)
				# IMAGE
				self.imageWindow = xbmcgui.ControlImage(x=47, y=47, width=306, height=406, filename=os.path.join(addonPath, 'resources/images/white.png'), aspectRatio=0, colorDiffuse='0x55FFFFFF')
				self.addControl(self.imageWindow)
				self.image = xbmcgui.ControlImage(x=50, y=50, width=300, height=400, filename=image, aspectRatio=1)
				self.addControl(self.image)
				# TEXT
				self.title = xbmcgui.ControlLabel(x=400, y=50, width=830, height=50, label=title, font='Volume', textColor='0xFFFFFFFF', alignment=0)
				self.addControl(self.title)
#				self.title2 = xbmcgui.ControlLabel(x=400, y=100, width=830, height=50, label=title2, font='Volume', textColor='0xFFFFFFFF', alignment=0)
#				self.addControl(self.title2)
				self.textboxWindow = xbmcgui.ControlImage(x=400, y=125, width=830, height=235, filename=os.path.join(addonPath, 'resources/images/black.png'), aspectRatio=0, colorDiffuse='0x88444444')
				self.addControl(self.textboxWindow)
				self.textbox1 = xbmcgui.ControlTextBox(x=425, y=140, width=780, height=185, font='Details', textColor='0xFFFF0000')
				self.addControl(self.textbox1)
				self.textbox1.setText(info2)
				self.textbox1.autoScroll(2500, 2500, 2500)
				self.textbox2 = xbmcgui.ControlTextBox(x=400, y=400, width=830, height=270, font='size22', textColor='0xFFFFFFFF')
				self.addControl(self.textbox2)
				self.textbox2.setText(desc)
				self.textbox2.autoScroll(2500, 2500, 2500)
				# BUTTON
				if xbmc.getSkinDir() == 'skin.estuary':
					self.button1 = xbmcgui.ControlButton(x=50, y=500, width=300, height=50, label='Xem | Watch', focusTexture=os.path.join(addonPath, 'resources/images/white.png'), noFocusTexture=os.path.join(addonPath, 'resources/images/white.png'), font='font36_title', textColor ='0xFF222222', alignment=6, disabledColor='0xFF222222', focusedColor='0xFF222222')
				else:
					self.button1 = xbmcgui.ControlButton(x=50, y=500, width=300, height=50, label='XEM', font='InfoTitle', alignment=6)
				self.addControl(self.button1)
				self.setFocus(self.button1)

			def onAction(self, action):
				if action == ACTION_PREVIOUS_MENU or action == ACTION_BACK:
					self.close()
					self.prompt = False

			def onControl(self, control):
				if control == self.button1:
					self.close()
					self.prompt = True

			def Response(self):
				return self.prompt

		window = InfoWindow()
		window.setCoordinateResolution(2)
		window.doModal()
		prompt = window.Response()
		del window
		return prompt

	except:
		return True

def Mirrors(url, title, image):
	soup   = Request(url, soup=True)
	button = soup.find(class_='btn-watch')
	url2   = button['href']
	url2 = domain + url2.encode('utf-8') if url2.startswith(u'/') else url2.encode('utf-8')
	soup = Request(url2, soup=True)
#	if True: # DEBUG #
	try:
		mirrors = soup.find(id='servers')
#		print mirrors
		mList = mirrors.find_all(class_='server')
		if len(mList) > 1:
			print('| %s mirrors |' % len(mList))
			for mirror in mList:
				mtitle = mirror.find(class_='label').string.encode('utf-8')
				AddDir('EPISODES', mirror, '[COLOR deepskyblue]Nguồn:[/COLOR] [COLOR white]%s[/COLOR]' % mtitle, image, extra=title)
			EndDir(contentType='Files', viewMode=50)
		else:
			raise
	except:
		print('| No mirrors |')
		Episodes(url2, title, image, src=soup)

def Episodes(url, title, image, src=None):
	if url.startswith('http'):
		soup = src
	else:
		soup = BeautifulSoup(url, 'html.parser')
#	if True: # DEBUG #
	try:
		episodes = soup.find(class_='episodelist')
#		print episodes
		epList  = episodes.find_all('a')
		if len(epList) <= 1:
			raise
		else:
			for episode in epList:
				eurl    = episode['href'].encode('utf-8')
				etitle  = episode.string.encode('utf-8')
				AddDir('PLAY', eurl, '[COLOR deepskyblue]Tập:[/COLOR] [COLOR white]%s[/COLOR]' % etitle, image, extra=title, folder=False, playable=True)
		EndDir(contentType='Files', viewMode=50)
	except:
		print('| No episodes |')
		Play(url, title, image)

def Play(url, title, image):
	dialog = xbmcgui.DialogProgress()
	dialog.create('[COLOR deepskyblue]%s[/COLOR]' % siteName, '[COLOR white]Đang tải phim...[/COLOR]')
	if dialog.iscanceled(): sys.exit() # KILL #
	link = Resolve(url)
	print('| Resolved URL | %s' % link)
	title = re.sub('(\[COLOR.+?\])', '', title).replace('[/COLOR]', '')
	if dialog.iscanceled(): sys.exit() # KILL #
	if mode == 'PLAY':
		SetResolved(link, title, image)
	else:
		listItem = xbmcgui.ListItem(title, thumbnailImage=image)
		xbmc.Player().play(link, listitem=listItem)
	if dialog.iscanceled(): sys.exit() # KILL #
	dialog.close()
	del dialog

def Resolve(url):
#	if True: # DEBUG #
	try:
		
		html = Request(url, referer=domain)
		if '/xac-nhan/' in html:
			print('| GEO CHECK |')
			data = {'lanhtu': 'HO+CHI+MINH', 'thudo': 'HA+NOI', 'lanhtho': 'S', 'sohuu': 'VIET+NAM', 'ref': url}
			headers    = {
				'User-Agent'      : userAgent,
				'Content-Type'    : 'application/x-www-form-urlencoded; charset=UTF-8'
			}
			html = Request(post=True, url='http://tvhay.org/xac-nhan/', extheaders=headers, data=data)
#		print(html)
		js = re.compile("}[(]('.+?' *, *'.+?' *, *'.+?' *, *'.+?')[)]").findall(html)[-1]
		src = UnWise().worker(js)
		if 'gkp' in src:
			link = re.compile('link:"([^"]*)"').findall(src)[0]
		else:
			raise
		#
		key = Request(url='https://fl.v137.xyz/tvhay?key=True')
		#
		gkp = 'http://tvhay.org/playergk/plugins/gkpluginsphp.php'
		headers    = {
			'User-Agent'      : userAgent,
			'Content-Type'    : 'application/x-www-form-urlencoded',
			'Referer'         : url
		}
		data = 'link=%s%s' % (link, key)
		src = Request(post=True, url=gkp, extheaders=headers, data=data)
		print('| SRC | %s' % src)
		if len(src) < 7:
			raise
	except:
		src = Request('https://fl.v137.xyz/tvhay?link=%s' % url)
	#
	try:
		# RESOLVE
		print('| SRC | %s' % src)
		src = src.replace('\/', '/')
		try:
			if '"link"' in src:
				sources = re.compile('(\[.+?\])').findall(src)[0]
				sources = json.loads(sources)
				links = []
				for source in sources:
					try:
						label = source['label']
					except:
						label = 'Auto'
					link  = source['link']
					links.append((label, link))
				src = ChooseRes(links)
		except:
			src = re.compile('"link":"(.+?)"').findall(src)[0]
		if 'youtube.com' in src:
			src = YouTube(src)
		return src
	except:
		xbmcgui.Dialog().ok('[COLOR deepskyblue]Xin lỗi[/COLOR]', '[COLOR white]Phim hiện không xem được[/COLOR]', '[COLOR white]Xin vui lòng thử phim khác[/COLOR]', '[COLOR steelblue]-- No links parsed --[/COLOR]')
		return ''

# ##################################################################################### #


def ChooseRes(src):
	# Forces order: 0. Label, 1. Link
	src2 = []
	if len(str(src[0][0])) > 7:
		for link, label in src:
			src2.append((label, link))
	else:
		src2 = src
	# Passes single Link
	if len(src2) == 1:
		return src2[0][1]
	else:
	# Auto chooses maximum resolution from settings
		for res in reversed(range(len(resolution))):
			if res <= maxres:
				for i, (label, link) in enumerate(src2):
					if resolution[res] in str(label):
						return link
	# Prompts user to choose resolution
		labels = [('[COLOR white]%s[/COLOR]' % label) for label, link in src2]
		dialog = xbmcgui.Dialog()
		prompt = -1
		prompt = dialog.select('Choose / Chọn:', labels)
		if prompt == -1:
			link = None
		else:
			link = src2[prompt][1]
		return link

def UrlResolver(url):
	if '/preview' in url:
		url = url.split('/preview')[0]
	try:
		try: import urlresolver9 as urlresolver
		except: import urlresolver
		link = urlresolver.resolve(url)
		if link == False:
			raise
	except:
		link = PopoutFrame(url)
	return link

def YouTube(url):
	if not url.startswith('http'):
		try:
			url = re.compile('"(http.+?youtube\.com/watch\?v=.+?)"').findall(url)[0]
		except:
			url = re.compile('"(http.+?youtube\.com[^\?]*)\?.+?"').findall(url)[0]
		else:
			return ''
	print('| YouTube | %s' % url)
	try:
		ytID  = url.split('watch?v=')[1]
	except:
		ytID  = url.split('/v/')[1]
	link  = 'plugin://plugin.video.youtube/play/?video_id=%s' % ytID
	return link

def PopoutFrame(url):
	url = str(url.encode('utf-8'))
	rnd = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(500))
	xbmcgui.Dialog().ok('HƯỚNG DẪN / INSTRUCTIONS','Bấm nút PLAY hai lần với con chuột để xem...','Press PLAY button twice with mouse to watch...')
	xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","http://v137.xyz/p/if?r='+rnd+'&src='+url+'")')
	return ''

class UnWise:
	def worker(self, str_eval):
		page_value=""
		try:
#			ss="w,i,s,e=("+str_eval+')'
			global w,i,s,e                              # EXEC HACK DUE TO DIFF BETWEEN PY2 AND PY3
			ss='global w,i,s,e; w,i,s,e=('+str_eval+')' # http://stackoverflow.com/questions/15086040/behavior-of-exec-function-in-python-2-and-python-3
			exec (ss)
			page_value=self.__unwise(w,i,s,e)
		except: return
		return page_value

	def __unwise(self,  w, i, s, e):
		lIll = 0;
		ll1I = 0;
		Il1l = 0;
		ll1l = [];
		l1lI = [];
		while True:
			if (lIll < 5):
				l1lI.append(w[lIll])
			elif (lIll < len(w)):
				ll1l.append(w[lIll]);
			lIll+=1;
			if (ll1I < 5):
				l1lI.append(i[ll1I])
			elif (ll1I < len(i)):
				ll1l.append(i[ll1I])
			ll1I+=1;
			if (Il1l < 5):
				l1lI.append(s[Il1l])
			elif (Il1l < len(s)):
				ll1l.append(s[Il1l]);
			Il1l+=1;
			if (len(w) + len(i) + len(s) + len(e) == len(ll1l) + len(l1lI) + len(e)):
				break;
		lI1l = ''.join(ll1l)
		I1lI = ''.join(l1lI)
		ll1I = 0;
		l1ll = [];
		for lIll in range(0,len(ll1l),2):
			ll11 = -1;
			if ( ord(I1lI[ll1I]) % 2):
				ll11 = 1;
			l1ll.append(chr(    int(lI1l[lIll: lIll+2], 36) - ll11));
			ll1I+=1;
			if (ll1I >= len(l1lI)):
				ll1I = 0;
		ret=''.join(l1ll)
		if 'eval(function(w,i,s,e)' in ret:
			ret=re.compile('eval\(function\(w,i,s,e\).*}\((.*?)\)').findall(ret)[0] 
			return self.worker(ret)
		else:
			return ret

# ##################################################################################### #


if   mode == 'INDEX'     : Index(url)
elif mode == 'SUBMENUS'  : Submenus(url, title)
elif mode == 'TOP'       : Top(url, title)
elif mode == 'HISTORY'   : History(url)
elif mode == 'SEARCH'    : Search(url, extra)
elif mode == 'CLEAR'     : Clear(extra)
elif mode == 'MIRRORS'   :
	if Info(url):
		Mirrors(url, title, image)
elif mode == 'EPISODES'  : Episodes(url, extra, image)
elif mode == 'PLAY'      : Play(url, extra, image)
elif mode == 'LOADVIDEO' : LoadVideo(url)
elif mode == 'SETTINGS'  : xbmc.executebuiltin('Addon.OpenSettings(%s)' % addonId)
else                     : Home()
