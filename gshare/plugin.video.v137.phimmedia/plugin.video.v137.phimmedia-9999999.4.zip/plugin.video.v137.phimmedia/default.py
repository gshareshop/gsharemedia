#!/usr/bin/python
# -*- coding: utf-8 -*-

OFFLINE            = False
DEBUG              = False

from v137       import v137
from threading  import Thread

def Index(baseUrl):
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		videos = soup.find(class_='list-film')     # MATCHING DEBUG LINES
		videos = videos.select('li')               #
	else:
		try:
			videos = soup.find(class_='list-film') # MATCHING DEBUG LINES
			videos = soup.select('li')             #
		except:
			videos = []
	count = 0
	for video in videos:
		if DEBUG:
			vurl, name, vicon, vname = Items(baseUrl, video)     # MATCHING DEBUG LINES
		else:
			try:
				vurl, name, vicon, vname = Items(baseUrl, video) # MATCHING DEBUG LINES
			except Exception, e:
				v137.Log('| ITEM ERROR | %s' % e)
				vurl = None
		if vurl and vname:
			vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]
			count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)
	if DEBUG: v137.Log('| %s ITEM(S) |' % count)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
		v137.EndItems(contentType=DEFAULTTYPE, viewMode=v137.listView)
	else:
		if DEBUG:
			Pagination(baseUrl, soup)     # MATCHING DEBUG LINES
		else:
			try:
				Pagination(baseUrl, soup) # MATCHING DEBUG LINES
			except Exception, e:
				v137.Log('| PAGINATION ERROR | %s' % e)
		v137.EndItems(contentType=DEFAULTTYPE, viewMode=DEFAULTVIEW)

def Items(baseUrl, soup):
	link  = soup.a['href'].strip()
	link  = v137.FormatUrl(link, baseUrl)
	name1 = soup.a['title'].strip().encode('utf-8')
	name  = COLOUR1 % name1
	vname = name1
	try:
		icon   = soup.find('img')['src'].strip()
		icon   = v137.FormatUrl(icon, baseUrl)
	except:
		icon   = v137.ICON
	return link, name, icon, vname

def Pagination(baseUrl, soup):
	pagination = soup.find(class_='Paging')
	plink = None
	for label in [' Next', 'Next']:
		try:
			plink = pagination.find(text=label).parent['href']
			break
		except:
			continue
	if plink:
		plink = v137.FormatUrl(plink, baseUrl, cleanUrl=False)
		pname = COLOUR2 % '%s >>' % v137.language[LANG]['NEXT'].upper()
		v137.AddItem('INDEX', plink, pname, v137.icons['LAST_PAGE'])

def Toplists(baseUrl, index, icon):
	index = str(index)
	if index == '0': period = 'topviewday'
	if index == '1': period = 'topviewweek'
	if index == '2': period = 'topviewmonth'
	soup = v137.Request(baseUrl, soup=True)
	lists = soup.find(class_='top-movie').find_all('ul')
	items = []
	count = 0
	for list in lists:
		if period in list['id'].lower():
			items = list.select('li')
	for item in items:
		tpos  = item.span.string.strip().encode('utf-8')
		tlink = item.a['href']
		tlink = v137.FormatUrl(tlink)
		tname = item.p.text.strip().encode('utf-8')
		tname = '%s. %s' % (COLOUR2 % tpos, COLOUR1 % (tname))
		count += v137.AddItem('INFO', tlink, tname, icon)
	v137.EndItems(contentType='Files', viewMode=v137.listView)

def Submenus(baseUrl, index, icon):
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		menus = soup.find_all(class_='dropdown-menu')     # MATCHING DEBUG LINES
		items = menus[int(index)].select('a')
	else:
		try:
			menus = soup.find_all(class_='dropdown-menu') # MATCHING DEBUG LINES
			items = menus[int(index)].select('a')
		except:
			items = []
	count = 0
	for item in items:
		slink = item['href']
		slink = v137.FormatUrl(slink)
		sname = COLOUR1 % (item.text.strip().encode('utf-8'))
		count += v137.AddItem('INDEX', slink, sname, icon)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=v137.listView)

def Info(baseUrl, vname, icon):
	html  = v137.Request(baseUrl)
	soup  = v137.Soup(html)
	if DEBUG:
		title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html)     # MATCHING DEBUG LINES
	else:
		try:
			title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| INFO ERROR | %s' % e)
			title = None
			info  = ''
	if title:
		prompt = v137.Info(title, thumb, info, plot, fanart, trailer, lang=LANG, offset=-75)
		if prompt == 'PLAY':
			if v137.AdultCheck(info):
				Servers(baseUrl, vname, icon, html)

def InfoData(baseUrl, html):
	soup = v137.Soup(html)
	title = soup.find('meta', property='og:title')['content'].rstrip(' - Xem Online').strip()
	thumb = soup.find('meta', property='og:image')['content']
	thumb = v137.FormatUrl(thumb, baseUrl)
	info  = ''
	metas = soup.find(class_='movie-meta-info').find_all(class_='movie-dt')
	for meta in metas:
		info = info + ('%s %s' % (COLOUR2 % meta.text, COLOUR1 % meta.find_next_sibling().text)) + '\n'
	plot = soup.find(id='info-film')
	plot = v137.StripTags(plot, before='', after='\n')
	plot = COLOUR1 % plot
#	try:
#		trailer = soup.find(id='btn-film-trailer')['href']
#		trailer = 'resolve://youtube@%s' % trailer
#		if DEBUG: v137.Log(trailer)
#	except:
	trailer = None
	return title, thumb, info, plot, FANART, trailer

def Servers(baseUrl, vname, icon, html=None):
	soup = v137.Soup(html)
	try:
		slink = soup.find(id='btn-film-watch')['href']
		slink = v137.FormatUrl(slink, baseUrl)
	except Exception, e:
		v137.Log('| WATCH BUTTON ERROR | %s' % e)
		slink = None
	if slink:
		html = v137.Request(slink)
		soup = v137.Soup(html)
		if DEBUG:
			servers = soup.select('.page-tap')     # MATCHING DEBUG LINES
		else:
			try:
				servers = soup.select('.page-tap') # MATCHING DEBUG LINES
			except:
				servers = []
		count = 0
		for server in servers:
			shtml = str(server)
			sname = server.parent.h4.text.strip().encode('utf-8')
			sname = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['SERVER'], COLOUR1 % sname.replace(v137.language[LANG]['SERVER'], ''). replace(':', '').strip().upper())
			smore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % slink)]
			if len(servers) > 1:
				count += v137.AddItem('EPISODES', slink, sname, icon, vname=vname, html=shtml, context=smore)
			else:
				count = 1
		if DEBUG: v137.Log('| %s SERVER(S) |' % count)
		if count == 0:
			Episodes(slink, name, icon, None)
		elif count == 1:
			Episodes(slink, name, icon, shtml)
		else:
			v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['COMINGSOON'])

def Episodes(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
		soup = v137.Soup(html)
		soup = soup.select('.page-tap')
	else:
		soup = v137.Soup(html)
	if DEBUG:
		episodes = soup.select('a')     # MATCHING DEBUG LINES
	else:
		try:
			episodes = soup.select('a') # MATCHING DEBUG LINES
		except:
			episodes = []
	count = 0
	for episode in episodes:
		elink  = episode['href']
		elink  = v137.FormatUrl(elink)
		ename  = episode['title'].strip().encode('utf-8')
		ename2 = '%s - %s' % (COLOUR2 % ename, COLOUR1 % vname)
		vname2 = '%s - %s' % (vname, ename)
		if elink:
			emore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)]
			if len(episodes) > 1:
				count += v137.AddItem('LOAD', elink, ename2, icon, vname=vname2, context=emore)
			else:
				count = 1
	if DEBUG: v137.Log('| %s EPISODE(S) |' % count)
	if count == 0:
		Load(baseUrl, vname, icon)
	elif count == 1:
		Load(elink, vname, icon)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Load(baseUrl, vname, icon, html=None):
	link = None
	if DEBUG:
		link = Links(baseUrl, vname, icon, html)     # MATCHING DEBUG LINES
	else:
		try:
			link = Links(baseUrl, vname, icon, html) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| RESOLVE ERROR | %s' % e)
	if link:
		Play(link, vname, icon)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['CANNOTPLAY'])

def Links(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)

	if DEBUG:
		data = soup.find(class_='info')                                                                 # MATCHING DEBUG LINES
		link = v137.LinksFinder(data, baseUrl, forcePreJSON=True, chooseRes=True, formatUrl=False)     #
	else:
		try:
			data = soup.find(class_='info')                                                             # MATCHING DEBUG LINES
			link = v137.LinksFinder(data, baseUrl, forcePreJSON=True, chooseRes=True, formatUrl=False) #
		except Exception, e:
			v137.Log('| LINKSFINDER ERROR | %s' % e)
			link = []
	if link:
		url = None
		link2 = v137.Regex('%s\s?=\s?(.+?);' % link, data)[0]
		if DEBUG: v137.Log('| FUN | %s' % link2)
		requestedJS = {}
		scripts = soup.find_all('script')
		for script in scripts:
			try:
				src = script['src']
				if SITEDOMAIN in src:
					js = GetJS(src)
					requestedJS.update({src:js})
					js.start()
			except:
				pass
		receivedJS = {}
		for src in requestedJS:
			js = requestedJS[src]
			js.join()
			receivedJS.update({src:js.get()})
		js1 = ''
		js2 = ''
		for src in receivedJS:
			v137.Log('| Received Script | %s' % src)
			js = receivedJS[src]
			if 'p,a,c,k,e,d' in js:
				js1 = v137.Regex('(eval\(function\(p,a,c,k,e,d\).*)', js)[0]
				js2 = link2
		if js1 and js2:
			url = v137.EvalJS(js1, js2)
		return url
	return

class GetJS(Thread):
	def __init__ (self, url):
		Thread.__init__(self)
		self.url = url
		self.js = ''
	def run(self):
		self.js = v137.Request(self.url, SITEURL)
	def get(self):
		return self.js

def Play(baseUrl, vname, icon):
	url = v137.Resolver(baseUrl, lang=LANG)
	player = v137.Player(url, vname, icon)
	return player

# #################################################################################################### #


if __name__ == '__main__'    :

	if v137.Android: DEBUG = False

	SITENAME           = 'Phim Media'
	SITEDOMAIN         = 'www.phimmedia.tv'
	SITEURL            = 'https://www.phimmedia.tv'
	SEARCHURL          = '/index.php?keyword=%s&do=phim&act=search'
	FANART             = v137.FANART if DEBUG else 'https://v137.xyz/py/v137/img/phimmedia_02.jpg'
	COLOUR1            = '[COLOR white][B]%s[/B][/COLOR]'
	COLOUR2            = '[COLOR orangered][B]%s[/B][/COLOR]'
	COLOUR3            = '[COLOR grey][B]%s[/B][/COLOR]'
	COLOUR9            = '[COLOR lime][B]%s[/B][/COLOR]'
	LANG               = 'VI'
	DEFAULTTYPE        = 'Movies'
	DEFAULTVIEW        = v137.posterView

	mode, link, name, icon, vname, extra, extra2, extra3, html = v137.Parameters()
	if DEBUG:
		v137.Log('| Mode   | %s' % mode)
		v137.Log('| Link   | %s' % link)
		v137.Log('| Name   | %s' % name)
		v137.Log('| Icon   | %s' % icon)
		v137.Log('| vName  | %s' % vname)
#		v137.Log('| Extra  | %s' % extra)
#		v137.Log('| Extra2 | %s' % extra2)
#		v137.Log('| Extra3 | %s' % extra3)
#		v137.Log('| HTML   | %s' % html)

	if not mode             :
		if OFFLINE:
			v137.Offline(lang=LANG)
		v137.AddItem('INDEX',    SITEURL + '/phim-moi/',  COLOUR1 % 'Phim Đề Cử',                v137.icons['THUMB_UP'],   FANART)
		v137.AddItem('INDEX',    SITEURL + '/phim-le/',   COLOUR1 % 'Phim Lẻ Mới',               v137.icons['FIBER_NEW'],  FANART)
		v137.AddItem('INDEX',    SITEURL + '/phim-bo/',   COLOUR1 % 'Phim Bộ Mới',               v137.icons['FIBER_NEW'],  FANART)
		v137.AddItem('TOPLISTS', 0,                       COLOUR1 % 'Top Xem Nhiều Trong Ngày',  v137.icons['WHATSHOT'],   FANART)
		v137.AddItem('TOPLISTS', 1,                       COLOUR1 % 'Top Xem Nhiều Trong Tuần',  v137.icons['WHATSHOT'],   FANART)
		v137.AddItem('TOPLISTS', 2,                       COLOUR1 % 'Top Xem Nhiều Trong Tháng', v137.icons['WHATSHOT'],   FANART)
		v137.AddItem('SUBMENUS', 0,                       COLOUR1 % '+ Thể Loại',                v137.icons['BOOK'],       FANART)
		v137.AddItem('SUBMENUS', 1,                       COLOUR1 % '+ Quốc Gia',                v137.icons['LANGUAGE'],   FANART)
		v137.AddItem('SUBMENUS', 2,                       COLOUR1 % '+ Phim Lẻ Theo Năm',        v137.icons['DATE_RANGE'], FANART)
		v137.AddItem('SUBMENUS', 3,                       COLOUR1 % '+ Phim Bộ Theo Năm',        v137.icons['DATE_RANGE'], FANART)
		v137.AddItem('SUBMENUS', 4,                       COLOUR1 % '+ Phim Tiếng Việt',         v137.icons['CHAT'],       FANART)
		v137.AddItem('SEARCH',   SITEURL + SEARCHURL,     COLOUR2 % '[ Tìm Kiếm ]',              v137.icons['SEARCH'],     FANART)
		v137.EndItems(contentType='Files', viewMode=v137.listView)

		v137.DefineSettings(settingsXML='Bare')

	elif mode == 'INDEX'    : Index(link)
	elif mode == 'TOPLISTS' : Toplists(SITEURL, link, icon)
	elif mode == 'SUBMENUS' : Submenus(SITEURL, link, icon)
	elif mode == 'INFO'     : Info(link, vname, icon)
	elif mode == 'SERVERS'  : Servers(link, vname,icon)
	elif mode == 'EPISODES' : Episodes(link, vname, icon, html)
	elif mode == 'LOAD'     : Load(link, vname, icon)
	elif mode == 'PLAY'     : Play(link, vname, icon)
	elif mode == 'SEARCH'       :
		link2  =  v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link2:
			if link2.startswith('http://') or link2.startswith('https://'):
				Index(link2)
			else:
				Index(link)
