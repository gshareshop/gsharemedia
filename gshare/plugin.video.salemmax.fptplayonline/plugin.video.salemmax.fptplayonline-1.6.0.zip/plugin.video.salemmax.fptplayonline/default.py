#!/usr/bin/python
#coding=utf-8
import urllib , httplib2 , re , json , HTMLParser , os , uuid , random
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
ii = xbmc . translatePath ( os . path . join ( oo000 , ".cache" ) )
oOOo = httplib2 . Http ( ii , disable_ssl_certificate_validation = True )
O0 = Plugin ( )
o0O = HTMLParser . HTMLParser ( )
iI11I1II1I1I = "plugin://plugin.video.salemmax.fptplayonline"
if 71 - 71: iiiIIii1IIi
o0OO00 = "https://fptplay.vn/show/getlinklivetv"
oo = "https://fptplay.vn/tro-giup/bao-loi"
i1iII1IiiIiI1 = "https://fptplay.vn/show/getlink"
iIiiiI1IiI1I1 = 30
if 87 - 87: OoOoOO00
I11i = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept" : "application/json, text/javascript, */*; q=0.01" ,
 "X-Requested-With" : "XMLHttpRequest" ,
 "Referer" : "https://fptplay.vn/livetv" ,
 "Cookie" : "" ,
 "Accept-Encoding" : "gzip, deflate"
 }
if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
if 8 - 8: Oo / iII11iiIII111 % iiiIIii1I1Ii . O00oOoOoO0o0O
if 43 - 43: Oo0 * OO - oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
def iiI1iIiI ( ) :
 OOo , Ii1IIii11 = oOOo . request ( "https://docs.google.com/spreadsheets/d/13VzQebjGYac5hxe1I-z1pIvMiNB0gSG7oWJlFHWnqsA/export?format=tsv&gid=659263944" )
 Oooo0000 = Ii1IIii11 . strip ( ) . splitlines ( )
 random . shuffle ( Oooo0000 )
 return Oooo0000
 if 22 - 22: OOo000 . O0I11i1i11i1I
def Iiii ( items ) :
 OOO0O = set ( )
 oo0ooO0oOOOOo = [ ]
 for oO000OoOoo00o in items :
  iiiI11 = tuple ( oO000OoOoo00o . items ( ) )
  if iiiI11 not in OOO0O :
   OOO0O . add ( iiiI11 )
   oo0ooO0oOOOOo . append ( oO000OoOoo00o )
 return oo0ooO0oOOOOo
 if 91 - 91: oOOOO / i1iiIII111ii + ii1IiI1i . O00oOoOoO0o0O
def oOo0Oo ( s ) :
 s = '' . join ( s . decode ( "utf8" ) . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return o0O . unescape ( s )
 if 66 - 66: II1Ii1iI1i
@ O0 . route ( '/eps/<sid>' )
def oo0Ooo0 ( sid ) :
 I1I11I1I1I ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 OOo , Ii1IIii11 = oOOo . request ( "https://fptplay.vn/xem-video/-%s.html" % sid , headers = I11i )
 OooO0OO = oOo0Oo ( Ii1IIii11 ) . encode ( "utf8" )
 iiiIi = 1
 IiIIIiI1I1 = re . compile ( 'Số tập\: </span>(\d+) tập</p>' ) . findall ( OooO0OO )
 OoO000 = [ ]
 if len ( IiIIIiI1I1 ) > 0 :
  iiiIi = int ( IiIIIiI1I1 [ 0 ] )
 IIiiIiI1 = re . compile ( '<title>FPT Play - Xem video (.+?)</title>' ) . findall ( OooO0OO ) [ 0 ]
 if iiiIi == 1 :
  iiIiIIi = { }
  iiIiIIi [ "label" ] = "Xem %s" % IIiiIiI1
  iiIiIIi [ "path" ] = "%s/play/%s/%s" % ( iI11I1II1I1I , sid , "1" )
  iiIiIIi [ "is_playable" ] = True
  OoO000 . append ( iiIiIIi )
 else :
  for ooOoo0O in range ( 1 , iiiIi + 1 ) :
   iiIiIIi = { }
   iiIiIIi [ "label" ] = "Xem %s - Tập %s" % ( IIiiIiI1 , ooOoo0O )
   iiIiIIi [ "path" ] = "%s/play/%s/%s" % ( iI11I1II1I1I , sid , ooOoo0O )
   iiIiIIi [ "is_playable" ] = True
   OoO000 . append ( iiIiIIi )
 return O0 . finish ( OoO000 )
 if 76 - 76: OoOoOO00 / Oo0 . Oo * II1Ii1iI1i - ooO0oo0oO0
@ O0 . route ( '/list/<order>/<s_id>/<page>' )
def list ( order = "new" , s_id = "" , page = "1" ) :
 I1I11I1I1I ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s" % ( order , s_id , page ) )
 Oooo = {
 'type' : order ,
 'stucture_id' : s_id ,
 'page' : page ,
 'keyword' : 'undefined'
 }
 OOo , Ii1IIii11 = oOOo . request ( "https://fptplay.vn/show/more" , method = "POST" , headers = I11i , body = urllib . urlencode ( Oooo ) )
 OooO0OO = oOo0Oo ( Ii1IIii11 ) . encode ( "utf8" )
 IiIIIiI1I1 = re . compile ( '<a href=".+?-(\w+).html" ><img[^>]*src="(.+?)"[^>]*alt="(.+?)"' ) . findall ( OooO0OO )
 OoO000 = [ ]
 for O00o , O00 , IIiiIiI1 in IiIIIiI1I1 :
  iiIiIIi = { }
  iiIiIIi [ "label" ] = IIiiIiI1
  iiIiIIi [ "path" ] = "%s/eps/%s" % ( iI11I1II1I1I , O00o )
  iiIiIIi [ "thumbnail" ] = O00
  OoO000 . append ( iiIiIIi )
 if len ( OoO000 ) == iIiiiI1IiI1I1 :
  iiIiIIi = { }
  iiIiIIi [ "label" ] = "Next >>"
  iiIiIIi [ "path" ] = "%s/list/%s/%s/%s" % ( iI11I1II1I1I , order , s_id , int ( page ) + 1 )
  iiIiIIi [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  OoO000 . append ( iiIiIIi )
 if O0 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return O0 . finish ( OoO000 , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return O0 . finish ( OoO000 , view_mode = 52 )
  else :
   return O0 . finish ( OoO000 )
 else :
  return O0 . finish ( OoO000 )
  if 11 - 11: Oo
@ O0 . route ( '/live' )
def O0o0Oo ( ) :
 I1I11I1I1I ( "Browse Live Channels" , "/live" )
 Oo00OOOOO = "https://fptplay.vn/livetv"
 OOo , Ii1IIii11 = oOOo . request ( Oo00OOOOO , headers = I11i )
 OooO0OO = oOo0Oo ( Ii1IIii11 )
 IiIIIiI1I1 = re . compile ( 'onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)"[^>]*>(.*?)<img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"' ) . findall ( OooO0OO )
 OoO000 = [ ]
 for o0OO00 , O0O , O00 , IIiiIiI1 in IiIIIiI1I1 :
  if 83 - 83: i111I + IIIiiIIii * Oo0 % iiiIIii1I1Ii + i111I
  iiIiIIi = { }
  iiIiIIi [ "label" ] = IIiiIiI1
  iiIiIIi [ "path" ] = "%s/play/%s" % ( iI11I1II1I1I , urllib . quote_plus ( o0OO00 . encode ( "utf8" ) ) )
  iiIiIIi [ "is_playable" ] = True
  iiIiIIi [ "thumbnail" ] = O00
  OoO000 . append ( iiIiIIi )
 OoO000 = Iiii ( OoO000 )
 if O0 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return O0 . finish ( OoO000 , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return O0 . finish ( OoO000 , view_mode = 52 )
  else :
   return O0 . finish ( OoO000 )
 else :
  return O0 . finish ( OoO000 )
  if 27 - 27: OoOoOO00 % ii1IiI1i * oooO0oo0oOOOO + iiiIIii1IIi + i1 * ii1IiI1i
@ O0 . route ( '/play/<url>' , name = "play_firsteps" )
@ O0 . route ( '/play/<url>/<eps>' )
def o0oo0o0O00OO ( url , eps = "1" ) :
 I1I11I1I1I ( "Play %s" % url , "/play/%s/%s" % ( url , eps ) )
 o0oO = xbmcgui . DialogProgress ( )
 o0oO . create ( 'FPTPlay.vn' , 'Loading video. Please wait...' )
 O0 . set_resolved_url ( I1i1iii ( url , eps ) , subtitles = "https://docs.google.com/spreadsheets/d/1SrBjJCIUTZyaMsN1-qwi_HzW7fMk8uRA1BWv7TSgkcg/export?format=tsv&gid=702890530" )
 o0oO . close ( )
 del o0oO
 if 20 - 20: Oo0
def I1i1iii ( url , ep_id = "1" ) :
 oO00 = None
 ooo = "|User-Agent=ffmpeg"
 if "/livetv" in url or "/event" in url :
  OOo , Ii1IIii11 = oOOo . request ( url , headers = I11i )
  OooO0OO = oOo0Oo ( Ii1IIii11 )
  ii1I1i1I = re . compile ( 'showAlert\("(.+?)"' ) . findall ( OooO0OO ) [ 0 ]
  OOoo0O0 = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( OooO0OO ) [ 0 ]
  I11i [ "X-Key" ] = OOoo0O0
  Oooo = {
 'id' : ii1I1i1I ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web'
 }
  Oooo0000 = iiI1iIiI ( )
  for OooO0OO in Oooo0000 :
   I11i [ "Cookie" ] = "laravel_session=" + OooO0OO . decode ( "base64" )
   OOo , Ii1IIii11 = oOOo . request ( o0OO00 , method = "POST" , headers = I11i , body = urllib . urlencode ( Oooo ) )
   iiiIi1i1I = json . loads ( Ii1IIii11 )
   if "ttlogin" not in iiiIi1i1I [ "stream" ] :
    oO00 = iiiIi1i1I [ "stream" ] + ooo
    break
 else :
  OOo , Ii1IIii11 = oOOo . request (
 "https://fptplay.vn/xem-video/-%s.html" % url ,
 headers = I11i )
  OooO0OO = oOo0Oo ( Ii1IIii11 )
  OOoo0O0 = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( OooO0OO ) [ 0 ]
  I11i [ "X-Key" ] = OOoo0O0
  Oooo = {
 'id' : url ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web' ,
 'episode' : ep_id
 }
  Oooo0000 = iiI1iIiI ( )
  for OooO0OO in Oooo0000 :
   I11i [ "Cookie" ] = "laravel_session=" + OooO0OO . decode ( "base64" )
   OOo , Ii1IIii11 = oOOo . request ( i1iII1IiiIiI1 , method = "POST" , headers = I11i , body = urllib . urlencode ( Oooo ) )
   iiiIi1i1I = json . loads ( Ii1IIii11 )
   if "ttlogin" not in iiiIi1i1I [ "stream" ] . strip ( ) :
    oO00 = iiiIi1i1I [ "stream" ] . strip ( ) + ooo
    break
 return oO00
 if 80 - 80: O00oOoOoO0o0O - iiiIIii1I1Ii
 if 87 - 87: oooO0oo0oOOOO / i111I - ii1IiI1i * ooO0oo0oO0 / i1 . OoOoOO00
def I1I11I1I1I ( title = "Home" , page = "/" ) :
 try :
  iii11I111 = "http://www.google-analytics.com/collect"
  OOOO00ooo0Ooo = open ( OOOooOooo00O0 ) . read ( )
  Oo0OO = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : OOOO00ooo0Ooo ,
 't' : 'pageview' ,
 'dp' : "FPTPlay" + page ,
 'dt' : title
 }
  oOOo . request ( iii11I111 , method = "POST" , body = urllib . urlencode ( Oo0OO ) )
 except : pass
 if 92 - 92: oooO0oo0oOOOO - O00oOoOoO0o0O
i11i1 = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( i11i1 ) == False :
 os . mkdir ( i11i1 )
OOOooOooo00O0 = os . path . join ( i11i1 , 'cid' )
if 29 - 29: OO % Oo + i1iiIII111ii / Oo0 + ooO0oo0oO0 * Oo0
if os . path . exists ( OOOooOooo00O0 ) == False :
 with open ( OOOooOooo00O0 , "w" ) as i1I1iI :
  i1I1iI . write ( str ( uuid . uuid1 ( ) ) )
  if 93 - 93: OOooo000oo0 % oooO0oo0oOOOO * ii1IiI1i
if __name__ == '__main__' :
 O0 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
