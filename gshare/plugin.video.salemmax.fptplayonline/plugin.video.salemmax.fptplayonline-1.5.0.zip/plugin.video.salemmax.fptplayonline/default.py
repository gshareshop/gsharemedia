#!/usr/bin/python
#coding=utf-8
import urllib , requests , re , json , HTMLParser , os , uuid , random
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
ii = HTMLParser . HTMLParser ( )
oOOo = "plugin://plugin.video.salemmax.fptplayonline"
if 59 - 59: Oo0Ooo . OO0OO0O0O0 * iiiIIii1IIi . iII111iiiii11 % I1IiiI
IIi1IiiiI1Ii = "https://fptplay.vn/show/getlinklivetv"
I11i11Ii = "https://fptplay.vn/tro-giup/bao-loi"
oO00oOo = "https://fptplay.vn/show/getlink"
OOOo0 = 30
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = {
 "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36" ,
 "Content-Type" : "application/x-www-form-urlencoded; charset=UTF-8" ,
 "Accept" : "application/json, text/javascript, */*; q=0.01" ,
 "X-Requested-With" : "XMLHttpRequest" ,
 "Referer" : "https://fptplay.vn/livetv" ,
 "Cookie" : "" ,
 "Accept-Encoding" : "gzip, deflate"
 }
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
def O0oOO0o0 ( ) :
 i1ii1iIII = requests . get ( "https://docs.google.com/spreadsheets/d/13VzQebjGYac5hxe1I-z1pIvMiNB0gSG7oWJlFHWnqsA/export?format=tsv&gid=659263944" ) . text . strip ( )
 Oo0oO0oo0oO00 = i1ii1iIII . splitlines ( )
 random . shuffle ( Oo0oO0oo0oO00 )
 return Oo0oO0oo0oO00
 if 8 - 8: OOo00O0Oo0oO / ooO
def IiIiI11iIi ( items ) :
 Ii1IIii11 = set ( )
 Oooo0000 = [ ]
 for i11 in items :
  I11 = tuple ( i11 . items ( ) )
  if I11 not in Ii1IIii11 :
   Ii1IIii11 . add ( I11 )
   Oooo0000 . append ( i11 )
 return Oooo0000
 if 98 - 98: I1111 * o0o0Oo0oooo0 / I1I1i1 * I1I1i1 / i1
def iiIIIIi1i1 ( s ) :
 s = '' . join ( s . splitlines ( ) ) . replace ( '\'' , '"' )
 s = s . replace ( '\n' , '' )
 s = s . replace ( '\t' , '' )
 s = re . sub ( '  +' , ' ' , s )
 s = s . replace ( '> <' , '><' )
 return ii . unescape ( s )
 if 54 - 54: ooOoO0o % OO0OO0O0O0 + o0 - ooO / o00O0oo
@ oo000 . route ( '/eps/<sid>' )
def iIiiI1 ( sid ) :
 OoOooOOOO ( "Browse eps by id %s" % sid , "/eps/%s" % sid )
 i1ii1iIII = requests . get ( "https://fptplay.vn/xem-video/-%s.html" % sid , headers = o0O )
 i1ii1iIII . encoding = "utf-8"
 i11iiII = iiIIIIi1i1 ( i1ii1iIII . text ) . encode ( "utf8" )
 I1iiiiI1iII = 1
 IiIi11i = re . compile ( 'Số tập\: </span>(\d+) tập</p>' ) . findall ( i11iiII )
 iIii1I111I11I = [ ]
 if len ( IiIi11i ) > 0 :
  I1iiiiI1iII = int ( IiIi11i [ 0 ] )
 OO00OooO0OO = re . compile ( '<title>FPT Play - Xem video (.+?)</title>' ) . findall ( i11iiII ) [ 0 ]
 if I1iiiiI1iII == 1 :
  iiiIi = { }
  iiiIi [ "label" ] = "Xem %s" % OO00OooO0OO
  iiiIi [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , "1" )
  iiiIi [ "is_playable" ] = True
  iIii1I111I11I . append ( iiiIi )
 else :
  for IiIIIiI1I1 in range ( 1 , I1iiiiI1iII + 1 ) :
   iiiIi = { }
   iiiIi [ "label" ] = "Xem %s - Tập %s" % ( OO00OooO0OO , IiIIIiI1I1 )
   iiiIi [ "path" ] = "%s/play/%s/%s" % ( oOOo , sid , IiIIIiI1I1 )
   iiiIi [ "is_playable" ] = True
   iIii1I111I11I . append ( iiiIi )
 return oo000 . finish ( iIii1I111I11I )
 if 86 - 86: Oo0Ooo + OOo00O0Oo0oO + I1I1i1 * o00O0oo + iII111i
@ oo000 . route ( '/list/<order>/<s_id>/<page>' )
def list ( order = "new" , s_id = "" , page = "1" ) :
 OoOooOOOO ( "Browse new videos by id %s" % s_id , "/list/%s/%s/%s" % ( order , s_id , page ) )
 Oo0oO0oo0oO00 = requests . Session ( )
 oOoO = {
 'type' : order ,
 'stucture_id' : s_id ,
 'page' : page ,
 'keyword' : 'undefined'
 }
 i1ii1iIII = Oo0oO0oo0oO00 . post ( "https://fptplay.vn/show/more" , headers = o0O , data = oOoO )
 i1ii1iIII . encoding = "utf-8"
 i11iiII = iiIIIIi1i1 ( i1ii1iIII . text ) . encode ( "utf8" )
 IiIi11i = re . compile ( '<a href=".+?-(\w+).html" ><img[^>]*src="(.+?)"[^>]*alt="(.+?)"' ) . findall ( i11iiII )
 iIii1I111I11I = [ ]
 for oOo , oOoOoO , OO00OooO0OO in IiIi11i :
  iiiIi = { }
  iiiIi [ "label" ] = OO00OooO0OO
  iiiIi [ "path" ] = "%s/eps/%s" % ( oOOo , oOo )
  iiiIi [ "thumbnail" ] = oOoOoO
  iIii1I111I11I . append ( iiiIi )
 if len ( iIii1I111I11I ) == OOOo0 :
  iiiIi = { }
  iiiIi [ "label" ] = "Next >>"
  iiiIi [ "path" ] = "%s/list/%s/%s/%s" % ( oOOo , order , s_id , int ( page ) + 1 )
  iiiIi [ "thumbnail" ] = "http://icons.iconarchive.com/icons/rafiqul-hassan/blogger/128/Arrow-Next-icon.png"
  iIii1I111I11I . append ( iiiIi )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( iIii1I111I11I , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( iIii1I111I11I , view_mode = 52 )
  else :
   return oo000 . finish ( iIii1I111I11I )
 else :
  return oo000 . finish ( iIii1I111I11I )
  if 6 - 6: o0 / i1oOo0OoO % OOo00O0Oo0oO
@ oo000 . route ( '/live' )
def oo ( ) :
 OoOooOOOO ( "Browse Live Channels" , "/live" )
 OO0O00 = "https://fptplay.vn/livetv"
 i1ii1iIII = requests . get ( OO0O00 , headers = o0O )
 if 20 - 20: iII111iiiii11
 i1ii1iIII . encoding = "utf-8"
 i11iiII = iiIIIIi1i1 ( i1ii1iIII . text )
 IiIi11i = re . compile ( 'onclick="getLivetv\(\$\(this\)\)" data-href="(.+?)"[^>]*>(.*?)<img class="lazy" data-original="(.+?)"[^>]*title="(.+?)"' ) . findall ( i11iiII )
 iIii1I111I11I = [ ]
 for IIi1IiiiI1Ii , Ii11iI1i , oOoOoO , OO00OooO0OO in IiIi11i :
  if 82 - 82: Oo0Ooo . ooOoO0o / i1oOo0OoO * OO0OO0O0O0 % I1Ii111 % iiiIIii1IIi
  iiiIi = { }
  iiiIi [ "label" ] = OO00OooO0OO
  iiiIi [ "path" ] = "%s/play/%s" % ( oOOo , urllib . quote_plus ( IIi1IiiiI1Ii . encode ( "utf8" ) ) )
  iiiIi [ "is_playable" ] = True
  iiiIi [ "thumbnail" ] = oOoOoO
  iIii1I111I11I . append ( iiiIi )
 iIii1I111I11I = IiIiI11iIi ( iIii1I111I11I )
 if oo000 . get_setting ( 'thumbview' , bool ) :
  if xbmc . getSkinDir ( ) in ( 'skin.confluence' , 'skin.eminence' ) :
   return oo000 . finish ( iIii1I111I11I , view_mode = 500 )
  elif xbmc . getSkinDir ( ) == 'skin.xeebo' :
   return oo000 . finish ( iIii1I111I11I , view_mode = 52 )
  else :
   return oo000 . finish ( iIii1I111I11I )
 else :
  return oo000 . finish ( iIii1I111I11I )
  if 78 - 78: iiiIIii1IIi - OOo00O0Oo0oO * iIIIiiIIiiiIi + iII111i + ooO + ooO
@ oo000 . route ( '/play/<url>' , name = "play_firsteps" )
@ oo000 . route ( '/play/<url>/<eps>' )
def I11I11i1I ( url , eps = "1" ) :
 OoOooOOOO ( "Play %s" % url , "/play/%s/%s" % ( url , eps ) )
 ii11i1iIII = xbmcgui . DialogProgress ( )
 ii11i1iIII . create ( 'FPTPlay.vn' , 'Loading video. Please wait...' )
 oo000 . set_resolved_url ( Ii1I ( url , eps ) , subtitles = "https://docs.google.com/spreadsheets/d/1SrBjJCIUTZyaMsN1-qwi_HzW7fMk8uRA1BWv7TSgkcg/export?format=tsv&gid=702890530" )
 ii11i1iIII . close ( )
 del ii11i1iIII
 if 89 - 89: Oo0Ooo / OO0OO0O0O0 * Oo % ooOoO0o % I1Ii111
def Ii1I ( url , ep_id = "1" ) :
 Ii1 = None
 III1i1i = "|User-Agent=ffmpeg"
 if "/livetv" in url or "/event" in url :
  i1ii1iIII = requests . get ( url , headers = o0O )
  i1ii1iIII . encoding = "utf-8"
  i11iiII = iiIIIIi1i1 ( i1ii1iIII . text ) . encode ( "utf8" )
  iiI1 = re . compile ( 'showAlert\("(.+?)"' ) . findall ( i11iiII ) [ 0 ]
  i11Iiii = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( i11iiII ) [ 0 ]
  o0O [ "X-Key" ] = i11Iiii
  oOoO = {
 'id' : iiI1 ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web'
 }
  Oo0oO0oo0oO00 = O0oOO0o0 ( )
  for i11iiII in Oo0oO0oo0oO00 :
   o0O [ "Cookie" ] = "laravel_session=" + i11iiII . decode ( "base64" )
   iI = requests . post ( IIi1IiiiI1Ii , headers = o0O , data = oOoO ) . json ( )
   if "ttlogin" not in iI [ "stream" ] :
    Ii1 = iI [ "stream" ] + III1i1i
    break
 else :
  i1ii1iIII = requests . get (
 "https://fptplay.vn/xem-video/-%s.html" % url ,
 headers = o0O )
  i1ii1iIII . encoding = "utf-8"
  i11iiII = iiIIIIi1i1 ( i1ii1iIII . text ) . encode ( "utf8" )
  i11Iiii = re . compile ( '"X-KEY", ?"(.+?)"' ) . findall ( i11iiII ) [ 0 ]
  o0O [ "X-Key" ] = i11Iiii
  oOoO = {
 'id' : url ,
 'type' : 'newchannel' ,
 'quality' : '3' ,
 'mobile' : 'web' ,
 'episode' : ep_id
 }
  Oo0oO0oo0oO00 = O0oOO0o0 ( )
  for i11iiII in Oo0oO0oo0oO00 :
   o0O [ "Cookie" ] = "laravel_session=" + i11iiII . decode ( "base64" )
   iI = requests . post ( oO00oOo , headers = o0O , data = oOoO ) . json ( )
   if "ttlogin" not in iI [ "stream" ] . strip ( ) :
    Ii1 = iI [ "stream" ] . strip ( ) + III1i1i
    break
 return Ii1
 if 28 - 28: ooOoO0o - I1111 . I1111 + Oo - iII111iiiii11 + OO0OO0O0O0
 if 95 - 95: iIIIiiIIiiiIi % I1Ii111 . OO0OO0O0O0
def OoOooOOOO ( title = "Home" , page = "/" ) :
 try :
  I1i1I = "http://www.google-analytics.com/collect"
  oOO00oOO = open ( OoOo ) . read ( )
  iIo00O = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : oOO00oOO ,
 't' : 'pageview' ,
 'dp' : "FPTPlay" + page ,
 'dt' : title
 }
  requests . post ( I1i1I , data = urllib . urlencode ( iIo00O ) )
 except : pass
 if 69 - 69: I1Ii111 % o0o0Oo0oooo0 - iII111i + o0o0Oo0oooo0 - OO0OO0O0O0 % iII111iiiii11
Iii111II = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( Iii111II ) == False :
 os . mkdir ( Iii111II )
OoOo = os . path . join ( Iii111II , 'cid' )
if 9 - 9: iIIIiiIIiiiIi
if os . path . exists ( OoOo ) == False :
 with open ( OoOo , "w" ) as i11O0oo0OO0oOOOo :
  i11O0oo0OO0oOOOo . write ( str ( uuid . uuid1 ( ) ) )
  if 35 - 35: I1111 % o0
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
