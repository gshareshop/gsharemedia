#!/usr/bin/python
# -*- coding: utf-8 -*-

OFFLINE            = False
DEBUG              = False

from v137 import v137

def Index(baseUrl, viewMode, page=1):
	soup = v137.Request(baseUrl, soup=True)
	soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
	if DEBUG:
		videos = soup.find_all(class_='poster')     # MATCHING DEBUG LINES
	else:
		try:
			videos = soup.find_all(class_='poster') # MATCHING DEBUG LINES
		except:
			videos = []
	count = 0
	for video in videos:
		if DEBUG:
			vurl, name, vicon, vname = Items(baseUrl, video)                                                                                          # MATCHING DEBUG LINES
			vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]     #
			count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                              #
		else:
			try:
				vurl, name, vicon, vname = Items(baseUrl, video)                                                                                      # MATCHING DEBUG LINES
				vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)] #
				count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                          #
			except Exception, e:
				v137.Log('| ITEM ERROR | %s' % e)
	if DEBUG:
		Pagination(baseUrl, soup, viewMode)     # MATCHING DEBUG LINES
	else:
		try:
			Pagination(baseUrl, soup, viewMode) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| PAGINATION ERROR | %s' % e)
	if DEBUG: v137.Log('| %s ITEM(S) |' % count)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType=DEFAULTTYPE, viewMode=viewMode)

def Items(baseUrl, soup):
	link  = soup.a['href']
	link  = v137.FormatUrl(link, baseUrl)
	name1 = soup.img['alt'].strip().encode('utf-8')
	try:
		name2 = soup.a['title'].strip().encode('utf-8')
		name2 = name2.lstrip('Phim ')
		name2 = name2.replace(name1, '').strip()
		vname = '%s - %s' % (name1, name2)
	except:
		name2 = ''
		vname = name1
	try:
		info = soup.find(class_='process').text.strip().encode('utf-8')
		info = info.replace(' / ', '/').replace('Thuyết Minh', 'TM').replace('VietSub', 'PD')
	except:
		info = ''
	try:
		year = v137.Regex('\d\d\d\d', name2)[0]
		name1 = name1.replace(year, '').strip()
		name2 = name2.replace(year, '').strip()
		year = year.replace('(', '').replace(')', '').strip()
	except:
		year = '###'
	name = '%s %s %s %s' % (COLOUR3 % year, COLOUR1 % v137.CleanText(name1), COLOUR2 % ('(%s)' % info), COLOUR3 % v137.CleanText(name2)) if info else '%s %s / %s' % (COLOUR3 % year, COLOUR1 % v137.CleanText(name1), COLOUR3 % v137.CleanText(name2))
	try:
		icon = soup.img['src']
		icon = v137.FormatUrl(icon, baseUrl)
	except:
		icon = v137.ICON
	return link, name, icon, vname

def Pagination(baseUrl, soup, viewMode):
	pagination = soup.find(class_='pagination')
	if any(s in str(pagination) for s in ['»', '&raquo;']):
		try:
			page = int(v137.Regex('/(\d+).html', baseUrl)[0])
			plink = v137Resub('/(\d+).html', '/%s.html' % page+1, baseUrl)[0]
		except:
			page = 1
			plink = '%s/%s.html' % (baseUrl.rstrip('/').rstrip('.html'), page+1)
		plink = v137.FormatUrl(plink, baseUrl)
		pname = COLOUR2 % '%s >>' % v137.language[LANG]['NEXT']
		v137.AddItem('INDEX', plink, pname, v137.icons['LAST_PAGE'], extra3=viewMode)

def Submenus(baseUrl, name, icon, viewMode):
	soup = v137.Request(baseUrl, soup=True)
	soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
	if DEBUG:
		menus = soup.select('.sub-main-menu-nav')     # MATCHING DEBUG LINES
	else:
		try:
			menus = soup.select('.sub-main-menu-nav') # MATCHING DEBUG LINES
		except:
			menus = links = []
	count = 0
	for menu in menus:
		title = menu.parent.parent.find('a').get_text().strip().encode('utf-8')
		if title.lower() in name.lower():
			links = menu.select('li')
	for link in links:
		cname = link.text.strip().encode('utf-8')
		cname = COLOUR1 % cname
		clink = link.a['href'].encode('utf-8')
		clink = v137.FormatUrl(clink, baseUrl)
		count += v137.AddItem('INDEX', clink, cname, icon, extra3=viewMode)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Info(baseUrl, vname, icon):
	soup = v137.Request(baseUrl, soup=True)
	soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
	html = v137.String(soup)
	if DEBUG:
		info, plot, trailer = InfoData(baseUrl, html)     # MATCHING DEBUG LINES
	else:
		try:
			info, plot, trailer = InfoData(baseUrl, html) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| INFO ERROR | %s' % e)
			info = None
	if info:
		prompt = v137.Info(vname, icon, info, plot, FANART, trailer, lang=LANG, offset=0)
		if prompt == 'PLAY':
			if v137.AdultCheck(info):
				Episodes(baseUrl, vname, icon, html)
	else:
		Episodes(baseUrl, vname, icon, html)

def InfoData(baseUrl, html):
	soup = v137.Soup(html)
	info = ''
	metas = soup.find(class_='info_film').find_all('li')
	for meta in metas:
		try:
			info = info + '%s' % COLOUR2 % v137.Minify(meta.text.replace(':', ': ', 1)) + '\n'
		except:
			pass
	try:
		info = info.decode('utf-8')
	except:
		pass
	plot = soup.find(id='info-film').find(class_='content').text
	plot = COLOUR1 % v137.StripTags(plot)
	trailer = None
	return info, plot, trailer

def Episodes(baseUrl, vname, icon, html=None):
	if not html:
		soup = v137.Request(baseUrl, soup=True)
		soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
		html = v137.String(soup)
	else:
		soup = v137.Soup(html)
	try:
		url = soup.find(class_='btn-watch')['href']
		url = v137.FormatUrl(url, baseUrl)
		click  = soup.find(class_='btn-watch')['onclick']
		if not 'alert' in click and not 'javascript:' in url:
			soup = v137.Request(url, referer=baseUrl, soup=True)
			soup = v137.GeoChallenge(soup, url, lang=LANG)
			html = v137.String(soup)
	except Exception, e:
		v137.Log('| WATCH BUTTON ERROR | %s' % e)
		url = baseUrl
	if DEBUG:
		episodes = soup.find(class_='listtap')     # MATCHING DEBUG LINES
		episodes = episodes.select('.chapter')     #
	else:
		try:
			episodes = soup.find(class_='listtap') # MATCHING DEBUG LINES
			episodes = episodes.select('.chapter') #
		except:
			episodes = []
	count = 0
	for episode in episodes:
		ename = episode.text.strip().encode('utf-8')
		ename = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['EPISODE'], COLOUR1 % ename.replace('Tập', '').strip())
		elink = episode['href'].strip()
		elink = v137.FormatUrl(elink, SITEURL)
		emore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)]
		if len(episodes) > 1:
			count += v137.AddItem('SERVERS', elink, ename, icon, vname=vname, html=v137.String(html), context=emore)
		else:
			count = 1
	if DEBUG: v137.Log('| %s EPISODE(S) |' % count)
	if count == 0:
		Servers(url, vname, icon, html)
	elif count == 1:
		Servers(elink, vname, icon, html)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Servers(baseUrl, vname, icon, html=None):
	if not html:
		soup = v137.Request(baseUrl, soup=True)
		soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
		html = v137.String(soup)
	else:
		soup = v137.Soup(html)
	if DEBUG:
		servers = soup.find(class_='listserver').select('.logo-server')     # MATCHING DEBUG LINES
	else:
		try:
			servers = soup.find(class_='listserver').select('.logo-server') # MATCHING DEBUG LINES
		except:
			servers = []
	count = 0
	for server in servers:
		subservers  = server.parent.parent.select('a')
		for subserver in subservers:
			sname1 = server.text.strip().encode('utf-8')
			sname2 = subserver.text.strip().encode('utf-8')
			sname = '%s %s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['SERVER'], COLOUR1 % sname1.replace(':', '').strip().upper(), COLOUR3 % '(%s)' % sname2.strip().upper())
			slink = subserver['onclick']
			slink = v137.Regex("PlayEpisode\('(.+?)','.+?'\)", slink)[0]
			slink = '%s|%s' % (slink, baseUrl)
			smore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % slink)]
			count += v137.AddItem('LOAD', slink, sname, icon, vname=vname, context=smore)
	if DEBUG: v137.Log('| %s SERVER(S) |' % count)
	if count == 0:
		Load(baseUrl, name, icon)
	elif count == 1:
		Load(slink, name, icon)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Load(baseUrl, vname, icon):
	link = None
	if DEBUG:
		link = Links(baseUrl)     # MATCHING DEBUG LINES
	else:
		try:
			link = Links(baseUrl) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| RESOLVE ERROR | %s' % e)
	if link:
		Play(link, vname, icon)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['CANNOTPLAY'])

def Links(baseUrl):
	if baseUrl.startswith('http'):
		soup = v137.Request(baseUrl, referer=SITEURL, soup=True)
		soup = v137.GeoChallenge(soup, baseUrl, lang=LANG)
	else:
		id, url = baseUrl.split('|')
		v137.Log('| EP_ID: %s | %s' % (id, url))
		soup = v137.Request(SITEURL + '/index.php', referer=url, post=True, data='play_episode=1&episode_id=%s' % v137.Quote(id), soup=True)
	html = v137.String(soup)

	link = None

	javascripts = soup.find_all('script')
	js = False
	for script in javascripts:
		if any(s in str(script) for s in ['jwplayer', 'videojs5']):
			js = script
	if js:
		js_api = v137.Regex('url\s*:\s*"(.+?)"', js)[0]
		js_url = v137.Regex('"url"\s*:\s*"(.+?)"', js)[0]
		js_name = v137.Regex('"name"\s*:\s*"(.+?)"', js)[0]
		url2 = '%s?url=%s&name=%s' % (js_api, js_url, js_name) # %s?url=%s&name=%s&sub=%s&_=%s
		soup = v137.Request(url2, referer=url, soup=True)
		soup = v137.GeoChallenge(soup, url2)
		html = v137.String(soup)

	if 'decodeLink' in html:
		mini = v137.Minify(html)
		sources = v137.Regex("decodeLink\('(.+?)',\s+(\d+).+?label:\s+'(.+?)'", mini)
		links = []
		for link, i, label in sources:
			v137.Log('| %s | %s | %s' % (label, i, link))
			links.append((label, [link, i]))
		if len(links) > 0:
			link = v137.ChooseRes(links)
			secret, password = link
			link = v137.Decode(secret, password, SITEURL)
			v137.Log('| Decoded | %s' % link)
	elif '<iframe' in html:
		link = soup.find('iframe')['src']
		v137.Log('| iFrame | %s' % link)
	elif '<source' in src:
		link = soup.find('source')['src']
		v137.Log('| Source | %s' % link)
	elif 'youtube.com' in html:
		link = v137.YouTube(html, getLink=True)
		v137.Log('| YouTube | %s' % link)
	return link

def Play(baseUrl, vname, icon):
	if 'api.phimbathu.' in baseUrl:
		url = Request(baseUrl, getRedirect=True, referer='http://phimbathu.com/')
		url = '%s|Referer=http://phimbathu.com/' % url
	elif 'api.bilutv.' in baseUrl:
		url = Request(baseUrl, getRedirect=True, referer='http://bilutv.com/')
		url = '%s|Referer=http://bilutv.com/' % url
	else:
		url = v137.Resolver(baseUrl, lang=LANG)
	player = v137.Player(url, vname, icon)
	return player

# #################################################################################################### #


if __name__ == '__main__'    :

	if v137.Android: DEBUG = False

	SITENAME           = 'Bom Tấn'
	SITEDOMAIN         = 'bomtan.org'
	SITEURL            = 'http://bomtan.org'
	SEARCHURL          = '/full-hd/%s'
	FANART             = v137.Path(v137.addonPath, 'bomtan_02.jpg') if DEBUG else 'https://v137.xyz/py/v137/img/bomtan_02.jpg'
	COLOUR1            = '[COLOR white][B]%s[/B][/COLOR]'
	COLOUR2            = '[COLOR red][B]%s[/B][/COLOR]'
	COLOUR3            = '[COLOR grey][B]%s[/B][/COLOR]'
	COLOUR9            = '[COLOR yellow][B]%s[/B][/COLOR]'
	LANG               = 'VI'
	DEFAULTVIEW        = v137.listView
	THUMBVIEW          = v137.posterView
	DEFAULTTYPE        = 'Movies'

	mode, link, name, icon, vname, extra, extra2, extra3, html = v137.Parameters()
	if DEBUG:
		v137.Log('| Mode   | %s' % mode)
		v137.Log('| Link   | %s' % link)
		v137.Log('| Name   | %s' % name)
		v137.Log('| Icon   | %s' % icon)
		v137.Log('| vName  | %s' % vname)
		v137.Log('| Extra  | %s' % extra)
		v137.Log('| Extra3 | %s' % extra3)
#		v137.Log('| HTML   | %s' % html)

	if not mode             :
		if OFFLINE:
			v137.Offline(lang=LANG)
		v137.AddItem('INDEX',    SITEURL + '/phim-hot/phim-le.html',           COLOUR1 % 'Phim Lẻ',                 v137.icons['MOVIE'],        FANART, extra3=THUMBVIEW)
		v137.AddItem('INDEX',    SITEURL + '/phim-hot/phim-bo.html',           COLOUR1 % 'Phim Bộ',                 v137.icons['MOVIE_FILTER'], FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/phim-hot/phim-moi-cap-nhat.html', COLOUR2 % 'Phim Mới',                v137.icons['FIBER_NEW'],    FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/phim-hot/phim-hd.html',           COLOUR2 % 'Phim HD',                 v137.icons['HD'],           FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                      COLOUR1 % '+ Thể Loại',              v137.icons['BOOK'],         FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                      COLOUR1 % '+ Quốc Gia',              v137.icons['LANGUAGE'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                      COLOUR1 % '+ Phim Bộ Theo Quốc Gia', v137.icons['LANGUAGE'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL + '/phim-hot/phim-moi-cap-nhat.html', COLOUR1 % '+ Phim Mới Theo Năm',     v137.icons['DATE_RANGE'],   FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SEARCH',   SITEURL + SEARCHURL,                          COLOUR2 % '[ Tìm Kiếm ]',            v137.icons['SEARCH'],       FANART, extra3=DEFAULTVIEW)
		v137.EndItems(contentType='Files', viewMode=v137.listView)

		v137.DefineSettings(settingsXML='Bare')
		# SET COOKIES, ID:
		soup = v137.Request(SITEURL, soup=True)
		soup = v137.GeoChallenge(soup, SITEURL, lang=LANG)

	elif mode == 'INDEX'        : Index(link, extra3)
	elif mode == 'SUBMENUS'     : Submenus(link, name, icon, extra3)
	elif mode == 'INFO'         : Info(link, vname, icon)
	elif mode == 'EPISODES'     : Episodes(link, vname, icon, html)
	elif mode == 'SERVERS'      : Servers(link, vname,icon)
	elif mode == 'LOAD'         : Load(link, vname, icon)
	elif mode == 'PLAY'         : Play(link, vname, icon)
	elif mode == 'SEARCH'       :
		link  =  v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link:
			Index(link, extra3)
