#!/usr/bin/env python
# -*- coding: utf-8 -*-

maintenance = False

import xbmc, xbmcaddon, xbmcplugin, xbmcgui
import base64, json, os, random, re, requests, shutil, string, sys, urllib, urllib2
#from bs4 import BeautifulSoup
import HTMLParser

html_parser = HTMLParser.HTMLParser()
from threading import Thread

# ##################################################################################### #

"""
    urlresolver XBMC Addon
    Copyright (C) 2013 Bstrdsmkr

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    Adapted for use in xbmc from:
    https://github.com/einars/js-beautify/blob/master/python/jsbeautifier/unpackers/packer.py
    
    usage:

    if detect(some_string):
        unpacked = unpack(some_string)


Unpacker for Dean Edward's p.a.c.k.e.r
"""

import re

def detect(source):
    """Detects whether `source` is P.A.C.K.E.R. coded."""
    source = source.replace(' ', '')
    if re.search('eval\(function\(p,a,c,k,e,(?:r|d)', source): return True
    else: return False

def unpack(source):
    """Unpacks P.A.C.K.E.R. packed js code."""
    payload, symtab, radix, count = _filterargs(source)

    if count != len(symtab):
        raise UnpackingError('Malformed p.a.c.k.e.r. symtab.')

    try:
        unbase = Unbaser(radix)
    except TypeError:
        raise UnpackingError('Unknown p.a.c.k.e.r. encoding.')

    def lookup(match):
        """Look up symbols in the synthetic symtab."""
        word = match.group(0)
        return symtab[unbase(word)] or word

    source = re.sub(r'\b\w+\b', lookup, payload)
    return _replacestrings(source)

def _filterargs(source):
    """Juice from a source file the four args needed by decoder."""
    argsregex = (r"}\('(.*)', *(\d+), *(\d+), *'(.*?)'\.split\('\|'\)")
    args = re.search(argsregex, source, re.DOTALL).groups()

    try:
        return args[0], args[3].split('|'), int(args[1]), int(args[2])
    except ValueError:
        raise UnpackingError('Corrupted p.a.c.k.e.r. data.')

def _replacestrings(source):
    """Strip string lookup table (list) and replace values in source."""
    match = re.search(r'var *(_\w+)\=\["(.*?)"\];', source, re.DOTALL)

    if match:
        varname, strings = match.groups()
        startpoint = len(match.group(0))
        lookup = strings.split('","')
        variable = '%s[%%d]' % varname
        for index, value in enumerate(lookup):
            source = source.replace(variable % index, '"%s"' % value)
        return source[startpoint:]
    return source


class Unbaser(object):
    """Functor for a given base. Will efficiently convert
    strings to natural numbers."""
    ALPHABET = {
        62: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
        95: (' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ'
             '[\]^_`abcdefghijklmnopqrstuvwxyz{|}~')
    }
    
    def __init__(self, base):
        self.base = base

        # If base can be handled by int() builtin, let it do it for us
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
        else:
            if base < 62:
                self.ALPHABET[base] = self.ALPHABET[62][0:base]
            elif 62 < base < 95:
                self.ALPHABET[base] = self.ALPHABET[95][0:base]
            # Build conversion dictionary cache
            try:
                self.dictionary = dict((cipher, index) for index, cipher in enumerate(self.ALPHABET[base]))
            except KeyError:
                raise TypeError('Unsupported base encoding.')

            self.unbase = self._dictunbaser

    def __call__(self, string):
        return self.unbase(string)

    def _dictunbaser(self, string):
        """Decodes a  value to an integer."""
        ret = 0
        for index, cipher in enumerate(string[::-1]):
            ret += (self.base ** index) * self.dictionary[cipher]
        return ret

class UnpackingError(Exception):
    """Badly packed source or general error. Argument is a
    meaningful description."""
    pass

# ##################################################################################### #


addonID      = 'plugin.video.v137.kenh88'
addon        = xbmcaddon.Addon(addonID)
addondir     = xbmc.translatePath(addon.getAddonInfo('path') ) 
icon         = os.path.join(addondir, 'icon.png')
fanart       = 'https://v137.xyz/py/v137/img/kenh88_02.jpg'
pluginhandle = int(sys.argv[1])
skin_used    = xbmc.getSkinDir()
tempDir      = xbmc.translatePath('special://home/temp/'+addonID)
domain       = 'http://kenh88.com'
userAgent   = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'

resolution    = {
	16 : 'FULL',
	15 : '1080',
	14 : '720',
	13 : 'HD',
	12 : 'HQ',
	11 : '576',
	10 : '540',
	9  : 'MQ',
	8  : '480',
	7  : '360',
	6  : 'SD',
	5  : 'Auto',
	4  : '240',
	3  : 'LQ',
	2  : 'LOW',
	1  : 'LOWEST',
	0  : 'MOBILE',
}


if xbmc.getSkinDir() == 'skin.estuary':
	thumbview = '52'
elif xbmc.getSkinDir() == 'skin.supernova.nova':
	thumbview = '53'
elif xbmc.getSkinDir() == 'skin.heidi':
	thumbview = '53'
else:
	thumbview = '50'

def Home():
	addLink('[COLOR yellow][B]HƯỚNG DẪN MỞ OPENLOAD / HOW TO VIEW OPENLOAD[/B][/COLOR]', 'plugin://plugin.video.youtube/play/?video_id=iVROhogj_YQ', 'play', icon, '')
	addDir('[COLOR white][B]Phim mới[/B][/COLOR]', 'http://kenh88.com/phim-online-moi', 'index', icon, '')
	addDir('[COLOR white][B]Top trong ngày[/B][/COLOR]', 'http://kenh88.com/', 'topdaily', icon, '')
	addDir('[COLOR white][B]Top trong tuần[/B][/COLOR]', 'http://kenh88.com/', 'topweekly', icon, '')
	addDir('[COLOR white][B]Top trong tháng[/B][/COLOR]', 'http://kenh88.com/', 'topmonthly', icon, '')
	addDir('[COLOR cyan][B]+ Thể loại[/B][/COLOR]', 'http://kenh88.com/', 'genres', icon, '')
	addDir('[COLOR cyan][B]+ Quốc gia[/B][/COLOR]', 'http://kenh88.com/', 'countries', icon, '')
	addDir('[COLOR cyan][B]+ Năm[/B][/COLOR]', 'http://kenh88.com/', 'years', icon, '')
	addDir('[COLOR cyan][B]Phim bộ[/B][/COLOR]', 'http://kenh88.com/phim-bo-online', 'series', icon, '')
	addDir('[COLOR cyan][B]Phim lẻ[/B][/COLOR]', 'http://kenh88.com/phim-le-online', 'index', icon, '')
	addDir('[COLOR white][B][ Tìm kiếm ][/B][/COLOR]', 'http://kenh88.com/film/search?keyword=%s', 'search', icon, '')
	xbmcplugin.endOfDirectory(int(sysarg))
#	if skin_used == 'skin.heidi':
#		xbmc.executebuiltin('Container.SetViewMode(%s)' % thumbview)

def Top(url, interval):
	html = GetUrl(url, domain)
	if interval == 'daily':
		match = re.compile('<div id="sidebarlist-1">(.+?)<div id="sidebarlist-2">').findall(html)[0]
	elif interval == 'weekly':
		match = re.compile('<div id="sidebarlist-2">(.+?)<div id="sidebarlist-3">').findall(html)[0]
	elif interval == 'monthly':
		match = re.compile('<div id="sidebarlist-3">(.+?)<div class="clear">').findall(html)[0]
	vlist = re.compile('<img.+?src="(.+?)"[^>]*>.+?<a href="(.+?)">([^>]*)</a>').findall(match)
	threads = []
	for v in vlist:
		image = domain + v[0]
		thread = GetImages(image)
		threads.append(thread)
		thread.start()
	for i, thread in enumerate(threads):
		thread.join()
		vthumb = thread.Images()
		vrank = str(i+1)
		vurl   = domain + vlist[i][1].strip().encode('utf-8')
		vname  = html_parser.unescape(vlist[i][2]).strip().encode('utf-8').replace('"', "'")
		addDir('[COLOR cyan][B]' + vrank + '.[/B][/COLOR] [COLOR white][B]' + vname + '[/B][/COLOR]', vurl, 'mirrors', vthumb, vname)
	xbmcplugin.endOfDirectory(int(sysarg))

def Genres():
	addDir('[COLOR white][B]Hành động[/B][/COLOR]', 'http://kenh88.com/phim-online-hanh-dong', 'index', icon, '')
	addDir('[COLOR white][B]Võ thuật[/B][/COLOR]', 'http://kenh88.com/phim-online-vo-thuat', 'index', icon, '')
	addDir('[COLOR white][B]Thần thoại[/B][/COLOR]', 'http://kenh88.com/phim-online-than-thoai', 'index', icon, '')
	addDir('[COLOR white][B]Phiêu lưu[/B][/COLOR]', 'http://kenh88.com/phim-online-phieu-luu', 'index', icon, '')
	addDir('[COLOR white][B]Hài hước[/B][/COLOR]', 'http://kenh88.com/phim-online-hai-huoc', 'index', icon, '')
	addDir('[COLOR white][B]Cổ trang[/B][/COLOR]', 'http://kenh88.com/phim-online-co-trang', 'index', icon, '')
	addDir('[COLOR white][B]Kinh dị[/B][/COLOR]', 'http://kenh88.com/phim-online-kinh-di', 'index', icon, '')
	addDir('[COLOR white][B]Hình sự[/B][/COLOR]', 'http://kenh88.com/phim-online-hinh-su', 'index', icon, '')
	addDir('[COLOR white][B]Chiến tranh[/B][/COLOR]', 'http://kenh88.com/phim-online-chien-tranh', 'index', icon, '')
	addDir('[COLOR white][B]Tình cảm[/B][/COLOR]', 'http://kenh88.com/phim-online-tinh-cam', 'index', icon, '')
	addDir('[COLOR white][B]Tâm lý[/B][/COLOR]', 'http://kenh88.com/phim-online-tam-ly', 'index', icon, '')
	addDir('[COLOR white][B]Âm nhạc[/B][/COLOR]', 'http://kenh88.com/phim-online-am-nhac', 'index', icon, '')
	addDir('[COLOR white][B]Hoạt hình[/B][/COLOR]', 'http://kenh88.com/phim-online-hoat-hinh', 'index', icon, '')
	addDir('[COLOR white][B]Viễn tưởng[/B][/COLOR]', 'http://kenh88.com/phim-online-vien-tuong', 'index', icon, '')
	addDir('[COLOR white][B]Anime[/B][/COLOR]', 'http://kenh88.com/phim-online-anime', 'index', icon, '')
	addDir('[COLOR white][B]Hài kịch[/B][/COLOR]', 'http://kenh88.com/phim-online-hai-kich', 'index', icon, '')
	addDir('[COLOR white][B]Thể loại khác[/B][/COLOR]', 'http://kenh88.com/phim-online-the-loai-khac', 'index', icon, '')
	xbmcplugin.endOfDirectory(int(sysarg))

def Countries():
	addDir('[COLOR cyan][B]Đang cập nhật[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/dang-cap-nhat/', 'index', icon, '')
	addDir('[COLOR white][B]Việt Nam[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/viet-nam/', 'index', icon, '')
	addDir('[COLOR white][B]Trung Quốc[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/trung-quoc/', 'index', icon, '')
	addDir('[COLOR white][B]Thái Lan[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/thai-lan/', 'index', icon, '')
	addDir('[COLOR white][B]Hàn Quốc[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/han-quoc/', 'index', icon, '')
	addDir('[COLOR white][B]Hồng Kông[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/hong-kong/', 'index', icon, '')
	addDir('[COLOR white][B]Đài Loan[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/dai-loan/', 'index', icon, '')
	addDir('[COLOR white][B]Mỹ[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/my/', 'index', icon, '')
	addDir('[COLOR white][B]Nhật Bản[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/nhat-ban/', 'index', icon, '')
	addDir('[COLOR white][B]Ấn Độ[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/an-do/', 'index', icon, '')
	addDir('[COLOR white][B]Philippines[/B][/COLOR]', 'http://kenh88.com/the-loai-phim/philippines/', 'index', icon, '')
	xbmcplugin.endOfDirectory(int(sysarg))

def Years():
	addDir('[COLOR white][B]2016[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2016', 'index', icon, '')
	addDir('[COLOR white][B]2015[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2015', 'index', icon, '')
	addDir('[COLOR white][B]2014[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2014', 'index', icon, '')
	addDir('[COLOR white][B]2013[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2013', 'index', icon, '')
	addDir('[COLOR white][B]2012[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2012', 'index', icon, '')
	addDir('[COLOR white][B]2011[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2011', 'index', icon, '')
	addDir('[COLOR white][B]2010[/B][/COLOR]', 'http://kenh88.com/phim-online-nam/2010', 'index', icon, '')
	xbmcplugin.endOfDirectory(int(sysarg))

def Series():
	addDir('[COLOR cyan][B]Tất cả phim bộ[/B][/COLOR]', 'http://kenh88.com/phim-bo-online', 'index', icon, '')
	addDir('[COLOR cyan][B]Phim bộ đang cập nhật[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=1&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Việt Nam[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=1&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Trung Quốc[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=6&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Thái Lan[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=3&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Hàn Quốc[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=4&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Hồng Kông[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=5&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Đài Loan[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=7&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Mỹ[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=8&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Nhật Bản[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=9&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Ấn Độ[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=10&film_year=0', 'index', icon, '')
	addDir('[COLOR white][B]Phim bộ Philippines[/B][/COLOR]', 'http://kenh88.com/phim-bo-online?film_order=0&film_type=0&film_national=11&film_year=0', 'index', icon, '')
	xbmcplugin.endOfDirectory(int(sysarg))

def Search(url):
#	if True: # DEBUG
	try:
		if '/search' in url:
			keyb = xbmc.Keyboard('', 'Nhập từ khóa để tìm:')
			keyb.doModal()
			if (keyb.isConfirmed()):
				searchText = urllib.quote_plus(keyb.getText())
		elif '/page' in url:
			keyb = xbmcgui.Dialog()
			searchText = keyb.input('Nhập số trang:', type=xbmcgui.INPUT_NUMERIC)
		url = url % searchText
		print('| Search | %s' % url)
		Index(url)
	except: pass

def Index(url):
	print('| Index | %s' % url)
	html = GetUrl(url, domain)
	if '/search' in url:
		vlist = re.compile('<div class="">(.+?)</div>|<div class="last">(.+?)</div>').findall(html)
	else:
		vlist = re.compile('<div class="content"><p><strong>(.+?)</h2>|<div class="">(.+?)</h2>').findall(html)
	number  = 0
	threads = []
	videos  = []
	for v in vlist:
		v = ''.join(v) # regex creates tuple instead of list due to OR operator
#		if True: # DEBUG POINT
		try:
			video = re.compile('src="(.+?)".+?href="(.+?)">([^>]*)<').findall(v)[0]
			try:
				vname2 = re.compile('<h2>.*>([^>]*)').findall(v)[0]
			except: vname2 = ''
			video = video + (vname2,)
		except:
			pass
		else:
			image = domain + video[0]
			thread = GetImages(image)
			threads.append(thread)
			thread.start()
			videos.append(video)
	for i, thread in enumerate(threads):
		thread.join()
		vthumb = thread.Images()
		vurl   = domain + videos[i][1].strip().encode('utf-8')
		vname  = html_parser.unescape(videos[i][2]).strip().encode('utf-8').replace('"', "'")
		vname2 = html_parser.unescape(videos[i][3]).strip().encode('utf-8').replace('"', "'")
		addDir('[COLOR white][B]' + vname + '[/B][/COLOR] | [COLOR cyan][B]' + vname2 + '[/B][/COLOR]', vurl, 'mirrors', vthumb, vname2 + ' | ' + vname)
		number += 1
	popup = xbmcgui.Dialog()
	popup.notification('[COLOR cyan][B]LOADED [/B][/COLOR][COLOR white][B]%s' % str(number) + '[/B][/COLOR] [COLOR cyan][B]ITEMS[/B][/COLOR]', '', '', 5000, False)

	try:
		pagelist = re.compile('<ul class="pagination">(.+?)</ul>').findall(html)[0]
	except:
		pass
	else:
		navmatch = re.compile('<li([^>]*)>(.+?)<\/li>').findall(pagelist)
		if len(navmatch) > 1:
			for pclass, pblock in navmatch:
				if 'current' in pclass:
					pname = pblock
					addDir('[COLOR teal][B]Trang ' + pname.strip().encode("utf-8") + '[/B][/COLOR]', url, 'self', '', '')
				elif pclass == '':
					pblock = re.compile('<a.+?href="(.+?)">(.+?)<\/a>').findall(pblock)
					for plink, pname in pblock:
						plink = domain + plink.encode('utf-8')
						pname = pname.encode('utf-8')
						if 'Trước' in pname:
							addDir('[COLOR cyan][B]<< Trang trước[/B][/COLOR]', plink, 'index', '', '')
						elif 'Sau' in pname:
							addDir('[COLOR cyan][B]Trang sau >>[/B][/COLOR]', plink, 'index', '', '')
						elif '...' in pname:
							addDir('[COLOR teal][B]...[/B][/COLOR]', url, 'self', '', '')
						else: # All available pages
							addDir('[COLOR cyan][B]Trang ' + pname + '[/B][/COLOR]', plink, 'index', '', '')
			try:
				addDir('[COLOR white][B][ Nhập số trang ][/B][/COLOR]', re.sub('/page/([0-9]+)', '/page/%s', plink), 'search', '', '')
			except:
				pass
	xbmcplugin.endOfDirectory(int(sysarg))

def Mirrors(url, name, iconimage, vname):
	url = url.replace('/phim/', '/xem-phim-online/')
	print('| Mirrors | %s' % url)
	html = GetUrl(url, domain)
	mlist = re.compile('<div class="server"><div class="label">.+?>([^>]*)</div>').findall(html)
	if len(mlist) > 1:
		for mirror in mlist:
			mname = '[COLOR cyan][B]Nguồn:[/B][/COLOR] [COLOR white][B]' + mirror.encode('utf-8').replace(':', '').replace('Server', '') + '[/B][/COLOR]'
			mlink = mirror + '@' + url
			addDir(mname, mlink, 'episodes', iconimage, vname, context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % mlink)])
		xbmcplugin.endOfDirectory(int(sysarg))
	else:
		mirror = mlist[0]
		mlink = mirror + '@' + url
		Episodes(mlink, mirror, iconimage, vname)

def Episodes(url, name, iconimage, vname):
	mirror, url = re.compile('(.*)@(.*)').findall(url)[0]
	print('| Episodes | %s' % url)
	html = GetUrl(url, domain)
	elist = re.compile('<div class="label">.*%s[^>]*</div><ul class="episodelist">(.+?)</ul>' % mirror).findall(html)[0]
	elist = re.compile('<a href="(.+?)"[^>]*>([^>]*)</a>').findall(elist)
	for elink, ename in elist:
		ename = ename.strip().encode('utf-8')
		elink = domain + elink.encode('utf-8')
		try:
			vname1 = vname.split(' | ')[1]
		except:
			vname1 = vname
		if len(elist) == 1:
			PlayVideo(elink, iconimage, vname + ' | ' + ename)
		else:
			addLink('[COLOR cyan][B]Tập ' + ename + ':[/B][/COLOR] [COLOR white][B]' + vname1 + '[/B][/COLOR]', elink, 'loadvideo', iconimage, vname + ' - [COLOR cyan][B]Tập ' + ename + '[/B][/COLOR]', context=[('[COLOR white][B]TRY LINK IN BROWSER[/B][/COLOR]', 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)])
	if len(elist) > 1:
		xbmcplugin.endOfDirectory(int(sysarg))

def GetVideo(url):
	print('| Video | %s' % url)
	html = GetUrl(url, domain)
	if 'https://video.google.com/get_player' in html :
		src = re.compile('get_player\?(docid=.+?)&').findall(html)[0]
		src = GoogleDocs(src)
	elif '{link:' in html:
		link = re.compile('\{link:[^"]*"(.+?)"}').findall(html)[0]
#		script_js = re.compile('"(player.*)"').findall(html)[0]
#		print('| GKP.JS | %s' % script_js.encode('utf-8'))
#		js = GetUrl(domain + script_js)
#		script_php = re.compile('urlphp="(.+?)"').findall(js)[0]
#		print('| GKP.PHP | %s' % script_php.encode('utf-8'))
		script_php = 'http://www.kenh88.com/gkphp/plugins/gkpluginsphp.php'
		gkp = requests.post(script_php, data={'link': link, 'f': 'true'}).json()
		if u'File invalid or deleted' in str(gkp):
			try:
				src = base64.b64decode(link)
				print('| Decoded B64 | %s' % src)
			except:
				src = ''
		else:
			print('| JSON | %s' % str(gkp))
			if str(gkp).count('link', 0, len(str(gkp))) > 1:
				links = []
				for item in gkp["link"]:
					link  = item["link"]
					label = '[COLOR white][B]' + item["label"] + '[/B][/COLOR] | [COLOR cyan][B]' + item["type"] + '[/B][/COLOR]'
					links.append((label, link))
				src = ChooseRes(links)
			else:
				src = gkp["link"]
		if '//get.google.com' in src or '//picasaweb.google.com/' in src:
			id = src.split('#')[1]
			url = GetRedirect(src, src)
			url = url.replace('/pwa/', '/pwaf/').replace('?', '/photo/%s?' % id)
			print('| Transcription | %s' % url)
			url = GetRedirect(url, url)
			html = GetUrl(url, url)
			links = re.compile(',true,"(\d+)".+?"(url.+?)"').findall(html)
			for i, l in links:
				if id == i:
					src = l
			src = urllib.unquote_plus(src).decode('unicode-escape')
			links = re.compile('url=(.+?); .+?quality=(.+?),').findall(src)
#			print links
			if len(links) > 1:
				labels = [('[COLOR white][B]' + label + '[/B][/COLOR] | [COLOR cyan][B]' + label + '[/B][/COLOR]') for url, label in links]
				dialog = xbmcgui.Dialog()
				prompt = -1
				prompt = dialog.select('Choose / Chọn:', labels)
				if prompt == -1:
					src = ''
				else:
					src = links[prompt][0]
			else:
				src = links[0]
			src = src.split('&')[0]
		elif any(domain in src for domain in ['docs.google.', 'drive.google.', 'video.google.', 'googleusercontent.', 'googlevideo.', 'youtube.googleapis.']):
			src = GoogleDocs(src)
		elif any(domain in src for domain in ['ok.ru']):
			src = OKRU(src)
		elif src.endswith('.mp4'):
			pass
		else:
			src = UrlResolver(src)
	elif 'sources: {' in html or 'sources: [' in html:
		links = re.compile('{"file":"([^"]*)".+?"label":"([^"]*)"').findall(html)
		src = ChooseRes(links)
	elif '<iframe' in html:
#		html = re.compile('<div class="play">(.+?)</div>').findall(html)[0]
		iframe = re.compile('<iframe src="(.+?)"[^>]*>').findall(html)[0]
		print('| IFRAME | %s' % iframe)
		if 'openload' in iframe:
			print('| OPENLOAD | %s' % iframe)
			html = GetUrl(iframe, iframe)
			if 'We are sorry!' in html:
				print('| OPENLOAD NO GOOD! | %s' % iframe)
				src = ''
			else:
				src = iframe
		elif 'xtubeid.' in iframe:
			src = GetUrl(iframe, iframe)
			url2 = re.compile('iframe src="(.+?)"').findall(src)[0]
			url2 = 'http:' + url2 if url2.startswith('//') else url2
			print('| IFRAME | %s' % url2)
			src, cookie = GetUrl2(url2)
#			print(src)
			j = json.loads(re.compile('sources :(\[.+?\])').findall(src)[0])
			links = []
			for item in j:
				label = item['label']
				file = item['file']
				links.append((label, file))
				src = ChooseRes(links)
				src = src + '|Referer=%s&Cookie=%s' % (url2, cookie)
		elif any(domain in iframe for domain in ['ok.ru']):
			src = OKRU(iframe)
		else:
			pageContent = GetUrl(iframe, url)
#			print pageContent.encode('utf-8')
			if 'eval(function(p,a,c,k,e,d)' in pageContent:
				jspacked = re.compile('<script type="text/[^"]*">(eval\(function\(p,a,c,k,e,d\).+?(?=</script))', re.DOTALL | re.IGNORECASE).findall(pageContent)[0]
				res = unpack(jspacked)
#				print str(jspacked)
				res = res.replace('\\','').replace("'",'"')
#				print str(res)
				vids = re.compile('{"file":"(.+?)","type":".+?","label":"(.+?)"', re.DOTALL | re.IGNORECASE).findall(res)
#				vids = re.compile('{"label":"(.+?)","file":"(.+?)",', re.DOTALL | re.IGNORECASE).findall(res)
#				vids = re.compile('{"?file"?:"(http.+?)".+?label"?:"(.+?)"', re.DOTALL | re.IGNORECASE).findall(res)
				if len(vids)==1:
					src = vids[0]
				else:
					vlinks = []
					for vlink, vlabel in vids:
						if len(vlink)>20 and '.srt' not in vlink:
							vlinks.append(vlink)
					src = vlinks[-1]
			else:
				links = re.compile('{file: "(.+?)".+?label: "(.+?)"}').findall(pageContent)
				if len(links) > 1:
					labels = [('[COLOR white][B]' + label + '[/B][/COLOR]') for link, label in links]
					dialog = xbmcgui.Dialog()
					prompt = -1
					prompt = dialog.select('Choose / Chọn:', labels)
					if prompt == -1:
						src = ''
					else:
						src = links[prompt][0]
				else:
					src = links[0][0]
	else:
		src = ''
		xbmcgui.Dialog().ok('Báo Lỗi / Error','Video này không còn xem được.', 'This video is no longer available.')

	src = src.replace('\/', '/').encode('utf-8')
	return src

def YouTube(url):
	if 'watch?v=' in url:
		youtubeID = re.compile('watch\?v=(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/embed/' in url:
		youtubeID = re.compile('/embed/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	elif '/v/' in url:
		youtubeID = re.compile('/v/(.+?[^"|\s|\'|\?]*)').findall(url)[0]
	else:
		if url.startswith('http'):
			return url
		else:
			return ''
	return 'plugin://plugin.video.youtube/play/?video_id=%s' % youtubeID

def LoadVideo(url, vname, resolve=True):
#	if True: # DEBUG POINT
	try:
		if resolve:
			url = GetVideo(url)
			print('| Resolved | %s' % url)
			if url == '':
					raise
			elif 'openload' in url:
				url = str(url.encode('utf-8'))
				url = UrlResolver(url)
			else:
				pass
		video = xbmcgui.ListItem(vname)
		if '.m3u8' in url:
			video.setContentLookup(False)
			video.setMimeType('application/vnd.apple.mpegurl')
		elif '.mp4' in url:
			video.setContentLookup(False)
			video.setMimeType('video/mp4')
		video.setProperty('IsPlayable', 'true')
		video.setPath(str(url))
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, video)
	except:
		xbmcgui.Dialog().ok('Xin lỗi', 'Phim hiện không xem được', 'Xin vui lòng thử phim khác')

def PlayVideo(url, iconimage, vname):
	dialogWait = xbmcgui.DialogProgress()
	dialogWait.create('[B]Kenh88[/B]', '[B]Đang tải. Xin chờ...[/B]')
#	if True: # DEBUG POINT - UNCOMMENT HERE
	try:
		url = GetVideo(url)
		print('| Resolved | %s' % url)
		if url == '':
			pass
		elif 'openload' in url:
			url = str(url.encode('utf-8'))
			url = UrlResolver(url)
		else:
			pass
		video = xbmcgui.ListItem(vname, thumbnailImage=iconimage)
		if '.m3u8' in url:
			video.setContentLookup(False)
			video.setMimeType('application/vnd.apple.mpegurl')
		elif '.mp4' in url:
			video.setContentLookup(False)
			video.setMimeType('video/mp4')
		xbmc.Player().play(url, listitem=video)
	except:
		xbmcgui.Dialog().ok('Xin lỗi', 'Phim hiện không xem được', 'Xin vui lòng thử phim khác')
	dialogWait.close()
	del dialogWait
	addLink('[COLOR white][B]Bấm RETURN để quay trở lại.[/B][/COLOR]', '', '', '', '')
	addLink('[COLOR white][B]Press RETURN to go back.[/B][/COLOR]', '', '', '', '')

def GoogleDocs(url):
	print('| GOOGLE DOCS | %s' % url)
	gd_bug     = 0 # 0 = None | 1 = Basic | 2 = Detailed
	gd_agent   = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36'
	gd_session = requests.session()
	gd_headers = {
		'User-Agent': gd_agent,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
		'Accept-Encoding': 'gzip, deflate, sdch'
	}
	# Resolve redirect if GoogleUserContent
	if 'googleusercontent.' in url:
		# Get final URL
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url, headers=gd_headers, stream=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			url = r.url
			if gd_bug >= 1: print('| GD: REDIRECTION | %s' % url)
	# Extract video ID
	if 'open?id=' in url:
		id = re.compile('open\?id=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'docid=' in url:
		id = re.compile('docid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif 'driveid=' in url:
		id = re.compile('driveid=(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	elif '/file/d/' in url:
		id = re.compile('/file/d/(.+?[^"|\s|\'|\?|&|/]*)').findall(url)[0]
	else:
		id = None
	if id:
		url = 'https://docs.google.com/leaf?id=%s' % id
	else:
		return url
	# Initial request
	try:
		if gd_bug >= 1: print('| GD: REQUEST | %s' % url)
		r = gd_session.get(url=url, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: print('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: print(src)
	except Exception, e:
		print('| ERROR | %s' % str(e))
		src = ''
		cookie = ''
	resolved = ''
	# Method 1: parse JSON data
	if 'fmt_stream_map' in src:
		links  = re.compile('(\["fmt_stream_map",.+?\])').findall(src)[0]
		links  = re.compile('(\d+)\|(.+?)[,|"|\]]').findall(links)
		if gd_bug >= 2: print(links)
		labels = re.compile('(\["fmt_list",.+?\])').findall(src)[0]
		labels = re.compile('["|,](\d+)/.+?x(.+?)/').findall(labels)
		if gd_bug >= 2: print(labels)
		links2 = []
		for i, (linkdigit, link) in enumerate(links):
			for labeldigit, label in labels:
				if labeldigit == linkdigit:
					links2.append((label, link))
			resolved = ChooseRes(links2)
		if resolved:
			resolved = resolved.decode('unicode-escape') + '|Cookie=%s' % cookie
	# Method 2: get download link
	if not 'fmt_stream_map'in src or not resolved:
		url2 = 'https://drive.google.com/uc?id=%s&export=download' % id
		if gd_bug >= 1: print('| GD: REQUEST | %s' % url2)
		gd_headers.update({'Referer': url})
		r = gd_session.get(url=url2, headers=gd_headers); r.encoding = 'utf-8'
		cookie = urllib.urlencode(dict(r.cookies)).replace('&',';')
		src = r.text.encode('utf-8')
		if gd_bug >= 2: print('| GD: COOKIE | %s' %s)
		if gd_bug >= 2: print(src)
		url3 = re.compile('<a id="uc-download-link".+?href="(.+?)">').findall(src)[0]
		url3 = url3.replace('&amp;', '&')
		url3 = 'https://drive.google.com%s' % url3 if not url3.startswith('http') else url3
		# Get final URL
		if gd_bug >= 1: print('| GD: REDIRECTION | %s' % url3)
		gd_headers.update({'Referer': url2})
		r = gd_session.head(url=url3, headers=gd_headers, allow_redirects=True)
		if any(s in str(r.history) for s in ['300', '301', '302', '303', '304', '305', '306', '307', '308']):
			resolved = r.url
		else:
			if gd_bug >= 1: print('| GD: NO REDIRECT |')
			resolved = url3
	if gd_bug >= 1: print('| GD: RESOLVED | %s' % resolved)
	return resolved

def OKRU(url):
	url = url.replace('/video/', '/videoembed/')
	html = requests.get(url, headers={'User-Agent': userAgent}).text
	print(html.encode('utf-8'))
	src = re.compile('<div data-module="OKVideo" data-options="(.+?)"').findall(html)[0]
	j = json.loads(src.replace('&quot;', '"'))
	j = json.loads(j['flashvars']['metadata'])
	sources = j['videos']
	links = []
	for source in sources:
		links.append((source['name'], source['url']))
	link = ChooseRes(links, maxres=11)
	return link

def UrlResolver(url):
	if '/preview' in url:
		url = url.split('/preview')[0]
	try:
		import resolveurl
		link = resolveurl.resolve(url)
		if link == False:
			raise
	except:
		link = PopoutFrame(url)
	return link

def PopoutFrame(url):
	url = str(url.encode('utf-8'))
	rnd = ''.join(random.SystemRandom().choice(string.ascii_uppercase + string.digits) for _ in range(500))
	xbmcgui.Dialog().ok('HƯỚNG DẪN / INSTRUCTIONS','Bấm nút PLAY hai lần với con chuột để xem...','Press PLAY button twice with mouse to watch...')
	xbmc.executebuiltin('StartAndroidActivity("com.android.chrome","android.intent.action.VIEW","","http://v137.xyz/p/if?r='+rnd+'&src='+url+'")')
	return ''

def ChooseRes(src, maxres=15):
	# Forces order: 0. Label, 1. Link
	src2 = []
	if 'http' in str(src[0][0]):
#	if '//' in str(src[0][0]):
		for link, label in src:
			src2.append((label, link))
	else:
		src2 = src
	# Passes single Link
	if len(src2) == 1:
		return src2[0][1]
	else:
	# Auto chooses maximum resolution from settings
		for res in reversed(range(len(resolution))):
			if res <= maxres:
				for i, (label, link) in enumerate(src2):
					if resolution[res].upper() in str(label).upper():
						return link
	# Prompts user to choose resolution
		labels = [('[COLOR white][B]%s[/B][/COLOR]' % label) for label, link in src2]
		dialog = xbmcgui.Dialog()
		prompt = -1
		prompt = dialog.select('Choose:', labels)
		if prompt == -1:
			link = None
		else:
			link = src2[prompt][1]
		return link

def GetUrl(url, referer):
	try:
		headers = {'User-Agent': userAgent, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate, sdch', 'Referer': referer}
		r = s.get(url=url, headers=headers)
		r.encoding = 'UTF-8'
		response = r.text
		if 'eval(function(p,a,c,k,e,d)' in response:
			pass
		else:
			response = ''.join(response.splitlines()).replace('\'', '"')
			response = response.replace('\n', '')
			response = response.replace('\t', '')
			response = re.sub('  +', ' ', response)
			response = response.replace('> <', '><')
		return response
	except Exception, e:
		print('| ERROR | %s' % e)
		xbmcgui.Dialog().ok('ERROR', 'Server is offline. Please try again later.')
		sys.exit()

def GetUrl2(url):
	try:
		headers = {'User-Agent': userAgent, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate, sdch'}
		r = s.get(url=url, headers=headers)
		r.encoding = 'utf-8'
		response = r.text
		response = ''.join(response.splitlines()).replace('\'', '"')
		response = response.replace('\n', '')
		response = response.replace('\t', '')
		response = re.sub('  +', ' ', response)
		response = response.replace('> <', '><')
		return response.encode('utf-8'), urllib.urlencode(dict(r.cookies)).replace('&',';')
	except Exception, e:
		print('| ERROR | %s' % e)
		xbmcgui.Dialog().ok('ERROR', 'Server is offline. Please try again later.')
		sys.exit()

def GetRedirect(url, referer):
	headers = {'User-Agent': userAgent, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate, sdch', 'Referer': referer}
	r = s.get(url=url, headers=headers, allow_redirects=False) # Make a full request, disallowing redirect and getting the redirected URL
	newurl = r.headers['location']
	status = r.status_code
	if status >= 300 and status < 400:
		print('| %s' % status + ' Redirection | %s' % newurl)
	return newurl

class GetImages(Thread):
	def __init__ (self, url):
		Thread.__init__(self)
		self.url = url
		self.img = '.'
	def run(self):
		self.img = GetImage(self.url, domain)
	def Images(self):
		return self.img

def GetImage(url, referer):
	if not os.path.exists(tempDir):
		os.makedirs(tempDir)
	file = os.path.join(tempDir, re.compile('[^/]+$').findall(url)[0])
	if not os.path.isfile(file):
		response = requests.get(url=url, headers={'User-Agent': userAgent, 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 'Accept-Encoding': 'gzip, deflate, sdch', 'Referer': referer}, stream=True)
		with open(file, 'wb') as out_file:
			shutil.copyfileobj(response.raw, out_file)
		del response
	return file

def addLink(name, url, mode, iconimage, vname, context=None, contextReplace=False):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&vname=" + urllib.quote_plus(vname)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo(type="Video", infoLabels={"Title":vname})
	liz.setProperty("IsPlayable", "true")
	# ADD CONTEXT MENU ITEMS
	if context:
		liz.addContextMenuItems(context, replaceItems=contextReplace)
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
	return ok

def addDir(name, url, mode, iconimage, vname, context=None, contextReplace=False):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&vname=" + urllib.quote_plus(vname)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setInfo(type="Video", infoLabels={"Title":name})
	# ADD CONTEXT MENU ITEMS
	if context:
		liz.addContextMenuItems(context, replaceItems=contextReplace)
	ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
	return ok

def parameters_string_to_dict(parameters):
	paramDict = {}
	if parameters:
		paramPairs = parameters[1:].split("&")
		for paramsPair in paramPairs:
			paramSplits = paramsPair.split('=')
			if len(paramSplits) == 2:
				paramDict[paramSplits[0]] = paramSplits[1]
	return paramDict

params    = parameters_string_to_dict(sys.argv[2])
url       = params.get('url')
mode      = params.get('mode')
name      = params.get('name')
iconimage = params.get('iconimage')
vname     = params.get('vname')

if type(url) == type(str()):
	url = urllib.unquote_plus(url)
if type(name) == type(str()):
	name = urllib.unquote_plus(name)
if type(iconimage) == type(str()):
	iconimage = urllib.unquote_plus(iconimage)
if type(vname) == type(str()):
	vname = urllib.unquote_plus(vname)

sysarg = str(sys.argv[1])
s = requests.session()

if mode == 'index' or mode == 'self':
	Index(url)
elif mode == 'topdaily':
	Top(url, 'daily')
elif mode == 'topweekly':
	Top(url, 'weekly')
elif mode == 'topmonthly':
	Top(url, 'monthly')
elif mode == 'genres':
	Genres()
elif mode == 'countries':
	Countries()
elif mode == 'years':
	Years()
elif mode == 'series':
	Series()
elif mode == 'search':
	Search(url)
elif mode=='mirrors':
	Mirrors(url, name, iconimage, vname)
elif mode=='episodes':
	Episodes(url, name, iconimage, vname)
elif mode=='loadvideo':
	dialogWait = xbmcgui.DialogProgress()
	dialogWait.create('Kenh88', 'Đang tải. Xin chờ...')
	LoadVideo(url, vname)
	dialogWait.close()
	del dialogWait
elif mode =='play':
	LoadVideo(url, vname, resolve=False)
else:
	if maintenance: xbmcgui.Dialog().ok('CHÚ Ý / ATTENTION', 'Trang web tạm đang có lỗi kỹ thuật.', 'Website is temporarily having technical difficulties.')
	Home()
