#!/usr/bin/python
# -*- coding: utf-8 -*-
OFFLINE            = False
DEBUG              = False

from v137 import v137

def Index(baseUrl, viewMode, page=1):
	if not '/page/' in baseUrl:
		baseUrl = '%s/page/%s' % (baseUrl.rstrip('/'), page)
	elif '%s' in baseUrl:
		baseUrl = baseUrl % page
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		videos = soup.select('.inner')     # MATCHING DEBUG LINES
	else:
		try:
			videos = soup.select('.inner') # MATCHING DEBUG LINES
		except:
			videos = []
	count = 0
	for video in videos:
		if DEBUG:
			vurl, name, vicon, vname = Items(baseUrl, video)                                                                                          # MATCHING DEBUG LINES
			vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)]     #
			count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                              #
		else:
			try:
				vurl, name, vicon, vname = Items(baseUrl, video)                                                                                      # MATCHING DEBUG LINES
				vmore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % vurl)] #
				count += v137.AddItem('INFO', vurl, name, vicon, vname=vname, context=vmore)                                                          #
			except Exception, e:
				v137.Log('| ITEM ERROR | %s' % e)
	if DEBUG:
		Pagination(baseUrl, page, soup, viewMode)     # MATCHING DEBUG LINES
	else:
		try:
			Pagination(baseUrl, page, soup, viewMode) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| PAGINATION ERROR | %s' % e)
	if DEBUG: v137.Log('| %s ITEM(S) |' % count)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType=DEFAULTTYPE, viewMode=viewMode)

def Items(baseUrl, soup):
	link  = soup.find('a')['href']
	link  = v137.FormatUrl(link, baseUrl)
	name1 = soup.select('.name')[0].text.strip().encode('utf-8')
	name1 = name1.replace('Xem phim', '').strip()
	name2 = soup.select('.name2')[0].text.strip().encode('utf-8')
	vname = '%s - %s' % (name1, name2)
	name1 = COLOUR1 % v137.CleanText(name1)
	name2 = COLOUR3 % v137.CleanText(name2)
	try:
		year = soup.find(class_='year').text.strip().encode('utf-8')
		year = ' %s' % (COLOUR3 % year)
	except: year = ''
	try:
		info = soup.find(class_='status').text.strip().encode('utf-8')
		info = info.replace('Lồng Tiếng', 'LT').replace('Thuyết Minh', 'TM').replace('VietSub', 'PD')
		info = ' %s ' % (COLOUR2 % info)
	except: info = ''
	name = '%s %s%s %s' % (year, name1, info, name2)
	try:
		icon  = soup.find('img')['data-original']
		icon  = v137.FormatUrl(icon, baseUrl)
	except:
		icon  = v137.ICON
	return link, name, icon, vname

def Pagination(baseUrl, page, soup, viewMode):
	pagination = soup.find(class_='wp-pagenavi')
	if '&raquo;' in str(pagination) or '»' in str(pagination):
		page = int(v137.Regex('/page/(\d+)', baseUrl)[0])
		plink = v137.Resub('/page/%s' % str(page), '/page/%s' % str(page+1), baseUrl, count=1)
		pname = COLOUR2 % '%s >>' % v137.language[LANG]['NEXT']
		v137.AddItem('INDEX', plink, pname, v137.icons['LAST_PAGE'], extra3=viewMode)

def Submenus(baseUrl, name, icon):
	soup = v137.Request(baseUrl, soup=True)
	if DEBUG:
		menus = soup.select('.sub-menu')     # MATCHING DEBUG LINES
	else:
		try:
			menus = soup.select('.sub-menu') # MATCHING DEBUG LINES
		except:
			menus = links = []
	for menu in menus:
		title = menu.parent.find('a').get_text().strip().encode('utf-8')
		if title.lower() in name.lower():
			links = menu.select('li')
	count = 0
	for link in links:
		cname = COLOUR1 % (link.text.strip().encode('utf-8'))
		clink = link.a['href'].encode('utf-8')
		clink = v137.FormatUrl(clink, baseUrl)
		count += v137.AddItem('INDEX', clink, cname, icon)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Top(baseUrl, name, icon):
	if 'Ngày'  in name: name = 'day'
	if 'Tuần'  in name: name = 'week'
	if 'Tháng' in name: name = 'month'
	soup = v137.Request(baseUrl, soup=True)
	menus = soup.find(id='topview').select('.tab')
	for menu in menus:
		title = str(menu['class'])
		if name.lower() in title.lower():
			links = menu.select('li')
	count = 0
	for link in links:
		cpos  = link.find('span').text.encode('utf-8')
		cname = link.find('a')['title'].encode('utf-8')
		cname = '%s. %s' % (COLOUR2 % cpos, COLOUR1 % cname)
		clink = link.find('a')['href'].encode('utf-8')
		clink = v137.FormatUrl(clink, baseUrl)
		count += v137.AddItem('INFO', clink, cname, icon)
	if not count:
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND'], v137.icons['WARNING'], folder=False)
		v137.AddItem(None, None, COLOUR1 % v137.language[LANG]['NOTFOUND2'], v137.icons['WARNING'], folder=False)
	v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Info(baseUrl, vname, icon):
	html  = v137.Request(baseUrl)
	soup  = v137.Soup(html)
	if DEBUG:
		title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html)     # MATCHING DEBUG LINES
	else:
		try:
			title, thumb, info, plot, fanart, trailer = InfoData(baseUrl, html) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| INFO ERROR | %s' % e)
			title = None
	if title:
		prompt = v137.Info(title, thumb, info, plot, fanart, trailer, lang=LANG, offset=-75)
		if prompt == 'PLAY':
			if v137.AdultCheck(info):
				Servers(baseUrl, vname, icon, html)
	else:
		Servers(baseUrl, vname, icon, html)

def InfoData(baseUrl, html):
	soup = v137.Soup(html)
	title = soup.find('meta', property='og:title')['content'].lstrip('Phim' ).strip().encode('utf-8')
	thumb = soup.find(class_='poster').img['src']
	thumb = v137.FormatUrl(thumb, baseUrl)
	info  = ''
	metas = soup.find(class_='dinfo').find_all('dt')
	for meta in metas:
		info = info + ('%s %s' % (COLOUR2 % meta.text, COLOUR1 % meta.find_next_sibling('dd').text)) + '\n'
	plot = soup.find(id='info-film').text
	plot = COLOUR1 % v137.StripTags(plot)
#	try:
#		trailer = None
#		trailer = v137.LinkFinder(trailer)
#	except:
	trailer = None
	return title, thumb, info, plot, FANART, trailer

def Servers(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	try:
		slink = soup.find(class_='btn-watch')['href']
		slink = v137.FormatUrl(slink, baseUrl)
		html  = v137.Request(slink, referer=baseUrl)
		soup  = v137.Soup(html)
	except Exception, e:
		v137.Log('| WATCH BUTTON ERROR | %s' % e)
		slink = baseUrl
	if DEBUG:
		servers = soup.find(id='servers').select('.server')     # MATCHING DEBUG LINES
	else:
		try:
			servers = soup.find(id='servers').select('.server') # MATCHING DEBUG LINES
		except:
			servers = []
	count = 0
	for server in servers:
		shtml = v137.String(server)
		sname = server.find(class_='label').text.strip().encode('utf-8')
		sname = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['SERVER'], COLOUR1 % sname.replace('Server', ''). replace(':', '').strip().upper())
		smore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % slink)]
		if len(servers) > 1:
			count += v137.AddItem('EPISODES', slink, sname, icon, vname=vname, html=shtml, context=smore)
		else:
			count = 1
	if DEBUG: v137.Log('| %s SERVER(S) |' % count)
	if count == 0:
		Episodes(slink, name, icon, None)
	elif count == 1:
		Episodes(slink, name, icon, shtml)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Episodes(baseUrl, vname, icon, html=None):
	if not html:
		html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	if DEBUG:
		if 'episodelist' in str(soup):
			episodes = soup.find(class_='episodelist')     # MATCHING DEBUG LINES
		else:                                              #
			episodes = soup.find(class_='listserver')      #
		episodes = episodes.find_all('a')                  #
	else:
		try:
			if 'episodelist' in str(soup):                 # MATCHING DEBUG LINES
				episodes = soup.find(class_='episodelist') #
			else:                                          #
				episodes = soup.find(class_='listserver')  #
			episodes = episodes.find_all('a')              #
		except:
			episodes = []
	count = 0
	for episode in episodes:
		ename = episode.text.strip().encode('utf-8')
		if not 'download' in ename.lower():
			ename = '%s %s' % (COLOUR2 % '%s:' % v137.language[LANG]['EPISODE'], COLOUR1 % ename)
			elink = episode['href'].strip()
			elink = v137.FormatUrl(elink, SITEURL)
			emore = [(COLOUR1 % v137.language[LANG]['TRYBROWSER'], 'StartAndroidActivity("","android.intent.action.VIEW","","%s")' % elink)]
			if len(episodes) > 1:
				count += v137.AddItem('LOAD', elink, ename, icon, vname=vname, context=emore)
			else:
				count = 1
	if DEBUG: v137.Log('| %s EPISODE(S) |' % count)
	if count == 0:
		Load(baseUrl, vname, icon)
	elif count == 1:
		Load(elink, vname, icon)
	else:
		v137.EndItems(contentType='Files', viewMode=DEFAULTVIEW)

def Load(baseUrl, vname, icon):
	link = None
	if DEBUG:
		link = Links(baseUrl)     # MATCHING DEBUG LINES
	else:
		try:
			link = Links(baseUrl) # MATCHING DEBUG LINES
		except Exception, e:
			v137.Log('| RESOLVE ERROR | %s' % e)
	if link:
		Play(link, vname, icon)
	else:
		v137.OK(v137.language[LANG]['SORRY'], v137.language[LANG]['CANNOTPLAY'])

def Links(baseUrl):
	html = v137.Request(baseUrl)
	soup = v137.Soup(html)
	#
	if '/xac-nhan/' in html:
		url = SITEURL + '/xac-nhan/'
		if DEBUG: v137.Log('| GEO CHECK |')
		data = {'lanhtu': 'HO+CHI+MINH', 'thudo': 'HA+NOI', 'lanhtho': 'S', 'sohuu': 'VIET+NAM', 'ref': baseUrl}
		html = v137.Request(url, post=True, data=data)
	#
	media = soup.find(id='media')
	js = v137.UnWise(str(media))
	if DEBUG: v137.Log('| JS | %s' % js)
	if 'link:' in js:
		link = v137.Regex('link:"([^"]*)"', js)[0]
		KT, TKK, TK = GetKeys()
		url = SITEURL + '/playergk/plugins/gkpluginsphp.php'
		data = {
			'link' : link,
			'kt'   : KT,
			'tkk'  : TKK,
			'tk'   : TK,
		}
		links = v137.Request(url, userAgent=userAgent, referer=baseUrl, post=True, data=data)
		if DEBUG: v137.Log('| LINKS | %s' % links)
		try:
			src = v137.LinksFinder(links)
		except:
			try:
				src = v137.LinkFinder(links)
			except:
				src = None
	elif '<iframe' in js:
		soup = v137.Soup(js)
		src = soup.iframe['src']
		try:
			src = src.split('embed.php?link=')[1]
		except:
			pass
	return src

def GetKeys():
	script      = SITEURL + '/playergk/hza.php'
	#
	src = v137.Request(script, userAgent=userAgent)
	var, vars = v137.Regex('var ([^\s|=]*)\s?=(\[.+?\])', src)[0]
	vars2 = eval(vars)
	src2 = src
	for i, v in enumerate(vars2):
		src2 = src2.replace('%s[%s]' % (var, i), '"%s"' % v.decode('unicode-escape'))
	src2 = src2.replace(vars, '')
	#
	KT  = '%s%s' % (fingerPrint, sorted(vars2, key=len)[-2].decode('unicode-escape'))
	TKK = sorted(vars2, key=len)[-1].decode('unicode-escape')
	a   = v137.Regex('var a=(-?\d+)', TKK)[0]
	b   = v137.Regex('var b=(-?\d+)', TKK)[0]
	c   = v137.Regex('return -?(\d+)', TKK)[0]
	TKK = '%s.%s' % (c, int(a) + int(b))
	#
	js1 = 'X5O2t=[];function sM(a){if(null!==yr)b=yr;else{b=wr(String["fromCharCode"](84));var c=wr(String["fromCharCode"](75));b=[b(),b()];b[1]=c();b=(yr=X5O2t[b["join"](c())]||"")||""}var d=wr(String["fromCharCode"](116)),c=wr(String["fromCharCode"](107)),d=[d(),d()];d[1]=c();c="&"+d["join"]("")+"=";d=b["split"](".");b=Number(d[0])||0;for(var e=[],f=0,g=0;g<a["length"];g++){var l=a["charCodeAt"](g);128>l?e[f++]=l:(2048>l?e[f++]=l>>6|192:(55296==(l&64512)&&g+1<a["length"]&&56320==(a["charCodeAt"](g+1)&64512)?(l=65536+((l&1023)<<10)+(a["charCodeAt"](++g)&1023),e[f++]=l>>18|240,e[f++]=l>>12&63|128):e[f++]=l>>12|224,e[f++]=l>>6&63|128),e[f++]=l&63|128)}a=b;for(f=0;f<e["length"];f++)a+=e[f],a=xr(a,"+-a^+6");a=xr(a,"+-3^+b+-f");a^=Number(d[1])||0;0>a&&(a=(a&2147483647)+2147483648);a%=1E6;return c+(a["toString"]()+"."+(a^b))}var yr=null,wr=function(a){return function(){return a}},xr=function(a,b){for(var c=0;c<b["length"]-2;c+=3){var d=b["charAt"](c+2),d="a"<=d?d["charCodeAt"](0)-87:Number(d),d="+"==b["charAt"](c+1)?a>>>d:a<<d;a="+"==b["charAt"](c)?a+d&4294967295:a^d}return a};'
	js2 = 'yr = "%s"; sM("%s")' % (TKK, fingerPrint)
	src = v137.EvalJS(js1, js2)
	TK  = src.split('=')[1]
	#
	if DEBUG: v137.Log('| KT  | %s' % KT)
	if DEBUG: v137.Log('| TKK | %s' % TKK)
	if DEBUG: v137.Log('| TK  | %s' % TK)
	return KT, TKK, TK

def Play(baseUrl, vname, icon):
	url = v137.Resolver(baseUrl, lang=LANG)
	player = v137.Player(url, vname, icon)
	return player

# #################################################################################################### #


if __name__ == '__main__'    :

	if v137.Android: DEBUG = False

	SITENAME           = 'TV Hay'
	SITEDOMAIN         = 'tvhay.org'
	SITEURL            = 'http://tvhay.org'
	userAgent          = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
	fingerPrint        = '41f5812679f97c83e27c539ac68c0dc6' # CHANGES WITH CHANGE TO userAgent
	SEARCHURL          = '/search/%s'
	FANART             = v137.Path(v137.addonPath, 'fanart.jpg') if DEBUG else 'https://v137.xyz/py/v137/img/tvhay_02.jpg'
	COLOUR1            = '[COLOR white][B]%s[/B][/COLOR]'
	COLOUR2            = '[COLOR deepskyblue][B]%s[/B][/COLOR]'
	COLOUR3            = '[COLOR grey][B]%s[/B][/COLOR]'
	COLOUR9            = '[COLOR yellow][B]%s[/B][/COLOR]'
	LANG               = 'VI'
	DEFAULTVIEW        = v137.listView
	THUMBVIEW          = v137.posterView
	DEFAULTTYPE        = 'Movies'

	mode, link, name, icon, vname, extra, extra2, extra3, html = v137.Parameters()
	if DEBUG:
		v137.Log('| Mode   | %s' % mode)
		v137.Log('| Link   | %s' % link)
		v137.Log('| Name   | %s' % name)
		v137.Log('| Icon   | %s' % icon)
		v137.Log('| vName  | %s' % vname)
		v137.Log('| Extra  | %s' % extra)
		v137.Log('| Extra3 | %s' % extra3)
#		v137.Log('| HTML   | %s' % html)

	if not mode             :
		if OFFLINE:
			v137.Offline(lang=LANG)
		v137.AddItem('INDEX',    SITEURL + '/phim-moi/',                 COLOUR2 % 'Phim Mới',              v137.icons['FIBER_NEW'],    FANART, extra3=DEFAULTVIEW)
		v137.AddItem('INDEX',    SITEURL + '/phim-le/',                  COLOUR1 % 'Phim Lẻ',               v137.icons['MOVIE'],        FANART, extra3=THUMBVIEW)
		v137.AddItem('INDEX',    SITEURL + '/phim-bo/',                  COLOUR1 % 'Phim Bộ',               v137.icons['MOVIE_FILTER'], FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR2 % '+ Quốc Gia',            v137.icons['LANGUAGE'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SUBMENUS', SITEURL,                                COLOUR2 % '+ Thể Loại',            v137.icons['BOOK'],         FANART, extra3=DEFAULTVIEW)
		v137.AddItem('TOP',      SITEURL,                                COLOUR1 % 'Xem Nhiều Trong Ngày',  v137.icons['WHATSHOT'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('TOP',      SITEURL,                                COLOUR1 % 'Xem Nhiều Trong Tuần',  v137.icons['WHATSHOT'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('TOP',      SITEURL,                                COLOUR1 % 'Xem Nhiều Trong Tháng', v137.icons['WHATSHOT'],     FANART, extra3=DEFAULTVIEW)
		v137.AddItem('SEARCH',   SITEURL + SEARCHURL,                    COLOUR2 % '[ Tìm Kiếm ]',          v137.icons['SEARCH'],       FANART, extra3=DEFAULTVIEW)
		v137.EndItems(contentType='Files', viewMode=v137.listView)

		v137.DefineSettings(settingsXML='Bare')

	elif mode == 'INDEX'        : Index(link, extra3)
	elif mode == 'SUBMENUS'     : Submenus(link, name, icon)
	elif mode == 'TOP'          : Top(link, name, icon)
	elif mode == 'INFO'         : Info(link, vname, icon)
	elif mode == 'SERVERS'      : Servers(link, vname,icon)
	elif mode == 'EPISODES'     : Episodes(link, vname, icon, html)
	elif mode == 'LOAD'         : Load(link, vname, icon)
	elif mode == 'PLAY'         : Play(link, vname, icon)
	elif mode == 'SEARCH'       :
		link  =  v137.Search(link, extra, extra2, colour=COLOUR2, lang=LANG)
		if link:
			Index(link, extra3)
