#!/usr/bin/python
# coding=utf-8
import urllib , requests , re , json , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
requests . packages . urllib3 . disable_warnings ( )
oo000 = Plugin ( )
if 9 - 9: Ii . o0o00Oo0O - iI11I1II1I1I
@ oo000 . route ( '/play/<args_json>' )
def oooo ( args_json = { } ) :
 iIIii1IIi = json . loads ( args_json )
 o0OO00 (
 "[Play] %s" % (
 iIIii1IIi [ "title" ] . encode ( "utf8" ) if "title" in iIIii1IIi else "Unknow Title"
 ) ,
 '/play/%s/%s' % (
 iIIii1IIi [ "url" ] ,
 json . dumps ( iIIii1IIi [ "payloads" ] ) if "payloads" in iIIii1IIi else "{}"
 )
 )
 oo = xbmcgui . DialogProgress ( )
 oo . create ( 'HPlus.vn' , 'Đang tải, Xin quý khách vui lòn đợi trong giây lát...' )
 oo000 . set_resolved_url ( i1iII1IiiIiI1 ( iIIii1IIi [ "url" ] ) , subtitles = "https://docs.google.com/spreadsheets/u/0/d/1SrBjJCIUTZyaMsN1-qwi_HzW7fMk8uRA1BWv7TSgkcg/export?format=tsv&gid=0" )
 oo . close ( )
 del oo
 if 40 - 40: ooOoO0O00 * IIiIiII11i
def i1iII1IiiIiI1 ( url ) :
 o0oOOo0O0Ooo = None
 I1ii11iIi11i = "|User-Agent=Mozilla%2F5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F58.0.3029.110%20Safari%2F537.36&Referer=http%3A%2F%2Fhplus.com.vn%2F"
 try :
  I1IiI = requests . Session ( )
  if 73 - 73: OOooOOo / ii11ii1ii
  O00ooOO = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36' ,
 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8' ,
 'X-Requested-With' : 'XMLHttpRequest' ,
 'Referer' : url ,
 'Accept-Encoding' : 'gzip, deflate'
 }
  if 47 - 47: oO0ooO % iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
  I1IiI . headers . update ( O00ooOO )
  if 68 - 68: o00ooo0 / Oo00O0
  ooO0oooOoO0 = I1IiI . get ( url )
  II11i = re . search ( 'value="(https*\://.+?m3u8.+?)"' , ooO0oooOoO0 . text ) . group ( 1 )
  i1 = {
 'url' : II11i ,
 'type' : '1' ,
 'is_mobile' : '1'
 }
  ooO0oooOoO0 = I1IiI . post ( "http://hplus.com.vn/content/getlinkvideo/" , data = i1 )
  o0oOOo0O0Ooo = ooO0oooOoO0 . text . encode ( "utf8" )
 except : pass
 return o0oOOo0O0Ooo + I1ii11iIi11i
 if 64 - 64: ooO0Oooo00 % Ooo0
def o0OO00 ( title = "Home" , page = "/" ) :
 oo00000o0 = "http://www.google-analytics.com/collect"
 I11i1i11i1I = open ( Iiii ) . read ( )
 i1 = {
 'v' : '1' ,
 'tid' : 'UA-52209804-5' ,
 'cid' : I11i1i11i1I ,
 't' : 'pageview' ,
 'dp' : "HPlus" + page ,
 'dt' : "[HPlus] - %s" % title
 }
 requests . post ( oo00000o0 , data = urllib . urlencode ( i1 ) )
 if 87 - 87: oO0o0o0ooO0oO / I1i1I - OoOoo0 % iIiiI1 % OoOoo0 % o00ooo0
IiIIIiI11ii = xbmc . translatePath ( 'special://userdata' )
if os . path . exists ( IiIIIiI11ii ) == False :
 os . mkdir ( IiIIIiI11ii )
Iiii = os . path . join ( IiIIIiI11ii , 'cid' )
if 52 - 52: oO0o0o0ooO0oO + Oo00O0 % ooOoO0O00 / Ii
if os . path . exists ( Iiii ) == False :
 with open ( Iiii , "w" ) as iiIIi1IiIi11 :
  iiIIi1IiIi11 . write ( str ( uuid . uuid1 ( ) ) )
  if 11 - 11: iIiiI1 / o0o00Oo0O - IIiIiII11i
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
